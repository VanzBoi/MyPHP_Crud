# Purple starter

Extract the whole archive and open index.html in your browser. Edit the HTML with VS Code. Bootstrap 5.3.8 loads from jsDelivr; an internet connection is required. These are original editable examples, not the Bootstrap distribution. You may use, modify, and redistribute these original examples freely. Bootstrap itself is subject to its MIT license: https://github.com/twbs/bootstrap/blob/main/LICENSE .
