CREATE DATABASE IF NOT EXISTS dental_clinic_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dental_clinic_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS dentists (
  dentistID INT AUTO_INCREMENT PRIMARY KEY,
  dentistName VARCHAR(100) NOT NULL,
  specialization VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL,
  licenseNumber VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS patients (
  patientID INT AUTO_INCREMENT PRIMARY KEY,
  patientName VARCHAR(100) NOT NULL,
  age INT NOT NULL,
  gender VARCHAR(20) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS appointments (
  appointmentID INT AUTO_INCREMENT PRIMARY KEY,
  dentistID INT NOT NULL,
  patientID INT NOT NULL,
  appointmentDate DATE NOT NULL,
  appointmentTime VARCHAR(20) NOT NULL,
  serviceRendered VARCHAR(100) NOT NULL,
  totalFee DECIMAL(10,2) NOT NULL,
  status VARCHAR(50) DEFAULT 'Scheduled',
  FOREIGN KEY (dentistID) REFERENCES dentists(dentistID) ON DELETE CASCADE,
  FOREIGN KEY (patientID) REFERENCES patients(patientID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO dentists (dentistName, specialization, contactNumber, licenseNumber) VALUES
('Dr. Alicia Ramos', 'Orthodontics', '09171234567', 'PRC-0045123'),
('Dr. Mark Santos', 'Oral Surgery', '09189876543', 'PRC-0056789'),
('Dr. Elena Cruz', 'General Dentistry', '09224567890', 'PRC-0067890');

INSERT INTO patients (patientName, age, gender, contactNumber) VALUES
('Christian Bautista', 24, 'Male', '09171112233'),
('Sarah Geronimo', 28, 'Female', '09182223344'),
('Gary Valenciano', 45, 'Male', '09223334455');

INSERT INTO appointments (dentistID, patientID, appointmentDate, appointmentTime, serviceRendered, totalFee, status) VALUES
(1, 1, '2026-10-25', '09:00 AM', 'Braces Adjustment', 1500.00, 'Completed'),
(2, 2, '2026-10-26', '10:30 AM', 'Tooth Extraction', 2500.00, 'Completed'),
(3, 3, '2026-10-27', '02:00 PM', 'Oral Prophylaxis', 1200.00, 'Scheduled');

SET FOREIGN_KEY_CHECKS=1;