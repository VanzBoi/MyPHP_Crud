﻿<?php
require_once 'database.php';

$totalPositions = $conn->query("SELECT COUNT(*) FROM positions")->fetch_row()[0];
$totalEmployees = $conn->query("SELECT COUNT(*) FROM employees")->fetch_row()[0];
$totalPayrolls = $conn->query("SELECT COUNT(*) FROM payroll")->fetch_row()[0];
$totalNetPay = $conn->query("SELECT IFNULL(SUM(netPay), 0) FROM payroll")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payroll Management System - Dashboard</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="p-4 mb-4 bg-white rounded-3 border">
            <h1 class="display-6 fw-bold">Payroll Management System</h1>
            <p class="lead text-muted mb-0">Institutional Personnel & Salary Processing</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Job Positions</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalPositions; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Registered Employees</span>
                    <h3 class="mb-0 text-success"><?php echo $totalEmployees; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Processed Payrolls</span>
                    <h3 class="mb-0 text-dark"><?php echo $totalPayrolls; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Total Net Disbursed</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalNetPay, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Positions Directory</h5>
                    <p class="text-muted small">Define job titles, standardized monthly basic pay, and departmental allowances.</p>
                    <a href="<?php echo $baseUrl; ?>positions/index.php" class="btn btn-outline-primary mt-auto">Open Positions &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Employee Directory</h5>
                    <p class="text-muted small">Maintain personnel files, assigned positions, hiring dates, and contact information.</p>
                    <a href="<?php echo $baseUrl; ?>employees/index.php" class="btn btn-outline-success mt-auto">Open Employees &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Salary Processing & Monitoring</h5>
                    <p class="text-muted small">Compute monthly earnings, calculate statutory deductions, and analyze department payroll costs.</p>
                    <a href="<?php echo $baseUrl; ?>monitoring/index.php" class="btn btn-outline-dark mt-auto">Open Monitoring &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>