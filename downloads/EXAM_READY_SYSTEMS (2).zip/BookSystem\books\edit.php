<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM books WHERE bookID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = is_string($_POST['title'] ?? null) ? trim($_POST['title']) : '';
$author = is_string($_POST['author'] ?? null) ? trim($_POST['author']) : '';
$genre = is_string($_POST['genre'] ?? null) ? trim($_POST['genre']) : '';
$price = is_string($_POST['price'] ?? null) ? trim($_POST['price']) : '';
$stock = is_string($_POST['stock'] ?? null) ? trim($_POST['stock']) : '';

    $sql = "UPDATE books SET `title` = '" . $conn->real_escape_string($title) . "', `author` = '" . $conn->real_escape_string($author) . "', `genre` = '" . $conn->real_escape_string($genre) . "', `price` = '" . $conn->real_escape_string($price) . "', `stock` = '" . $conn->real_escape_string($stock) . "' WHERE bookID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book #<?= $id ?> - Bookstore Sales &amp; Inventory System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Book #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Book Title</label>
                <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($row['title'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Author</label>
                <input type="text" name="author" class="form-control" value="<?= htmlspecialchars($row['author'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Genre</label>
                <select name="genre" class="form-select" required>
                    <option value="Technology" <?= ($row['genre'] ?? '') === 'Technology' ? 'selected' : '' ?>>Technology</option>
<option value="Self-Help" <?= ($row['genre'] ?? '') === 'Self-Help' ? 'selected' : '' ?>>Self-Help</option>
<option value="Design" <?= ($row['genre'] ?? '') === 'Design' ? 'selected' : '' ?>>Design</option>
<option value="History" <?= ($row['genre'] ?? '') === 'History' ? 'selected' : '' ?>>History</option>
<option value="Fiction" <?= ($row['genre'] ?? '') === 'Fiction' ? 'selected' : '' ?>>Fiction</option>
<option value="Science" <?= ($row['genre'] ?? '') === 'Science' ? 'selected' : '' ?>>Science</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Price (₱)</label>
                <input type="number" step="0.01" name="price" class="form-control" value="<?= htmlspecialchars($row['price'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Stock Quantity</label>
                <input type="number"  name="stock" class="form-control" value="<?= htmlspecialchars($row['stock'] ?? '') ?>" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>