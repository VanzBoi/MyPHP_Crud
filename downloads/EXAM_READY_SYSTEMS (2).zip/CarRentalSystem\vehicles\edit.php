<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM vehicles WHERE vehicleID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$veh = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $plate = is_string($_POST['plateNumber'] ?? null) ? trim($_POST['plateNumber']) : '';
    $model = is_string($_POST['brandModel'] ?? null) ? trim($_POST['brandModel']) : '';
    $type = is_string($_POST['vehicleType'] ?? null) ? trim($_POST['vehicleType']) : '';
    $rate = floatval($_POST['dailyRate'] ?? 0);
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    $stmt = $conn->prepare("UPDATE vehicles SET plateNumber=?, brandModel=?, vehicleType=?, dailyRate=?, status=? WHERE vehicleID=?");
    $stmt->bind_param("sssdsi", $plate, $model, $type, $rate, $status, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Vehicle</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Edit Vehicle</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Plate Number</label>
                    <input type="text" name="plateNumber" class="form-control" required value="<?php echo htmlspecialchars($veh['plateNumber']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Brand & Model</label>
                    <input type="text" name="brandModel" class="form-control" required value="<?php echo htmlspecialchars($veh['brandModel']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Vehicle Type</label>
                    <select name="vehicleType" class="form-select" required>
                        <?php foreach(['Sedan', 'SUV', 'Van', 'Pickup'] as $opt): ?>
                        <option value="<?php echo $opt; ?>" <?php echo $veh['vehicleType'] === $opt ? 'selected' : ''; ?>><?php echo $opt; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Daily Rental Rate (₱)</label>
                    <input type="number" step="0.01" name="dailyRate" class="form-control" required value="<?php echo $veh['dailyRate']; ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <?php foreach(['Available', 'Rented', 'Maintenance'] as $s): ?>
                        <option value="<?php echo $s; ?>" <?php echo $veh['status'] === $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-warning w-100">Update Vehicle</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>