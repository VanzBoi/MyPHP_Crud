<?php
require_once '../database.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
if ($search !== '') {
    $stmt = $conn->prepare("SELECT e.*, p.positionName, p.basicSalary FROM employees e JOIN positions p ON e.positionID = p.positionID WHERE e.empFName LIKE ? OR e.empLName LIKE ? OR p.positionName LIKE ? ORDER BY e.empID DESC");
    $param = "%$search%";
    $stmt->bind_param("sss", $param, $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT e.*, p.positionName, p.basicSalary FROM employees e JOIN positions p ON e.positionID = p.positionID ORDER BY e.empID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Directory</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Registered Employees</h3>
            <a href="add.php" class="btn btn-primary">+ Add New Employee</a>
        </div>
        <div class="card p-3 mb-3">
            <form method="GET" class="row g-2">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="Search by employee name or position..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Search</button>
                    <?php if ($search !== ''): ?>
                        <a href="index.php" class="btn btn-outline-secondary">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <div class="card p-0">
            <table class="table table-bordered table-striped mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Full Name</th>
                        <th>Position</th>
                        <th>Basic Salary (₱)</th>
                        <th>Date Hired</th>
                        <th>Contact No.</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['empID']; ?></td>
                            <td><strong><?php echo htmlspecialchars($row['empFName'] . ' ' . $row['empLName']); ?></strong></td>
                            <td><span class="badge bg-secondary"><?php echo htmlspecialchars($row['positionName']); ?></span></td>
                            <td>₱<?php echo number_format($row['basicSalary'], 2); ?></td>
                            <td><?php echo htmlspecialchars($row['dateHired']); ?></td>
                            <td><?php echo htmlspecialchars($row['contactNo']); ?></td>
                            <td class="text-end">
                                <a href="edit.php?id=<?php echo $row['empID']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete.php?id=<?php echo $row['empID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete employee profile?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">No employees found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>