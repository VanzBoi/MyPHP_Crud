<?php include '../database.php'; include '../helpers.php';
$id = (int)($_GET['id'] ?? 0);
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $f = is_string($_POST['fName'] ?? null) ? $conn->real_escape_string(trim($_POST['fName'])) : '';
    $l = is_string($_POST['lName'] ?? null) ? $conn->real_escape_string(trim($_POST['lName'])) : '';
    $a = is_string($_POST['address'] ?? null) ? $conn->real_escape_string(trim($_POST['address'])) : '';
    $c = is_string($_POST['contactNo'] ?? null) ? $conn->real_escape_string(trim($_POST['contactNo'])) : '';
    mysqli_query($conn, "UPDATE guests SET fName='{$f}', lName='{$l}', address='{$a}', contactNo='{$c}' WHERE guestID={$id}");
  set_flash('Guest updated.', 'success');
  header('Location: index.php'); exit;
}
$res = mysqli_query($conn, "SELECT * FROM guests WHERE guestID={$id}");
$row = $res ? mysqli_fetch_assoc($res) : null;
if (!$row) {
    header('Location: index.php');
    exit;
}
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Guest</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
  </head>
  <body>
    <?php include '../navbar.php'; ?>
    <div class="container">
      <h4>Edit Guest</h4>
      <form method="post">
        <div class="mb-2"><label>First name</label><input required name="fName" class="form-control" value="<?= htmlspecialchars($row['fName']) ?>"></div>
        <div class="mb-2"><label>Last name</label><input required name="lName" class="form-control" value="<?= htmlspecialchars($row['lName']) ?>"></div>
        <div class="mb-2"><label>Address</label><textarea name="address" class="form-control"><?= htmlspecialchars($row['address']) ?></textarea></div>
        <div class="mb-2"><label>Contact</label><input name="contactNo" class="form-control" value="<?= htmlspecialchars($row['contactNo']) ?>"></div>
        <button class="btn btn-primary">Update</button>
        <a class="btn btn-secondary" href="index.php">Cancel</a>
      </form>
    </div>
      <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
  </body>
</html>
