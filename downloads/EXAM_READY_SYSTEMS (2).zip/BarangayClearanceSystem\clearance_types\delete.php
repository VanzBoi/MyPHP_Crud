<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    $conn->query("DELETE FROM `clearance_types` WHERE `typeID` = $id");
}

header("Location: index.php");
exit;
