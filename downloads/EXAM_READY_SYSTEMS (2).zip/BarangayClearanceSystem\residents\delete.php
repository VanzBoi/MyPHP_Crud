<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    $conn->query("DELETE FROM `residents` WHERE `residentID` = $id");
}

header("Location: index.php");
exit;
