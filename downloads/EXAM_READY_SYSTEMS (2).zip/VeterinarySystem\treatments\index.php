<?php
require_once '../database.php';

$query = "SELECT t.*, v.vetFName, v.vetLName, v.specialization, p.petName, p.speciesBreed, p.ownerName 
          FROM treatments t
          JOIN veterinarians v ON t.vetID = v.vetID
          JOIN pets p ON t.petID = p.petID
          ORDER BY t.treatmentID DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Treatment Records</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Clinical Treatment Records</h3>
            <a href="add.php" class="btn btn-primary">+ Record New Treatment</a>
        </div>
        <div class="card mb-3">
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Pet & Owner</th>
                        <th>Attending Vet</th>
                        <th>Date</th>
                        <th>Diagnosis</th>
                        <th>Prescription</th>
                        <th>Fee</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $row['treatmentID']; ?></td>
                            <td>
                                <strong> <?php echo htmlspecialchars($row['petName']); ?></strong>
                                <small class="text-muted d-block"><?php echo htmlspecialchars($row['ownerName']); ?></small>
                            </td>
                            <td>Dr. <?php echo htmlspecialchars($row['vetFName'] . ' ' . $row['vetLName']); ?></td>
                            <td><?php echo $row['treatmentDate']; ?></td>
                            <td><?php echo htmlspecialchars($row['diagnosis']); ?></td>
                            <td><small><?php echo htmlspecialchars($row['medication']); ?></small></td>
                            <td><strong class="text-success">₱<?php echo number_format($row['treatmentFee'], 2); ?></strong></td>
                            <td class="text-end">
                                <a href="delete.php?id=<?php echo $row['treatmentID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete treatment record?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No treatments recorded yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>