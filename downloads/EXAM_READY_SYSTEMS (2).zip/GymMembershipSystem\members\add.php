<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fName = is_string($_POST['fName'] ?? null) ? trim($_POST['fName']) : '';
    $lName = is_string($_POST['lName'] ?? null) ? trim($_POST['lName']) : '';
    $birthDate = is_string($_POST['birthDate'] ?? null) ? trim($_POST['birthDate']) : '';
    $age = intval($_POST['age'] ?? 0);
    $gender = is_string($_POST['gender'] ?? null) ? trim($_POST['gender']) : '';
    $contactNo = is_string($_POST['contactNo'] ?? null) ? trim($_POST['contactNo']) : '';
    $discount = floatval($_POST['discount'] ?? 0);

    if ($fName === '' || $lName === '' || $birthDate === '' || $age <= 0 || $gender === '' || $contactNo === '') {
        $errors[] = 'Please fill all required fields correctly.';
    }

    if (!$errors) {
        $stmt = mysqli_prepare($conn, 'INSERT INTO members (fName, lName, birthDate, age, gender, contactNo, discount) VALUES (?, ?, ?, ?, ?, ?, ?)');
        mysqli_stmt_bind_param($stmt, 'sssissd', $fName, $lName, $birthDate, $age, $gender, $contactNo, $discount);
        mysqli_stmt_execute($stmt);
        flash('Member added successfully.');
        redirect('index.php');
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Member - Gym Membership</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>
    <div class="container">
        <div class="py-3">
            <h2>Add Member</h2>
            <?php if ($errors): ?>
                <div class="alert alert-danger"><ul><?php foreach ($errors as $error): ?><li><?php echo escape($error); ?></li><?php endforeach; ?></ul></div>
            <?php endif; ?>
            <form method="post" action="add.php">
                <div class="row g-3">
                    <div class="col-md-6"><label class="form-label">First Name</label><input type="text" name="fName" class="form-control" value="<?php echo escape($_POST['fName'] ?? ''); ?>"></div>
                    <div class="col-md-6"><label class="form-label">Last Name</label><input type="text" name="lName" class="form-control" value="<?php echo escape($_POST['lName'] ?? ''); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Birth Date</label><input type="date" name="birthDate" class="form-control" value="<?php echo escape($_POST['birthDate'] ?? ''); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Age</label><input type="number" name="age" class="form-control" value="<?php echo escape($_POST['age'] ?? ''); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Gender</label><select name="gender" class="form-select"><option value="">Select</option><option value="Male" <?php echo (($_POST['gender'] ?? '') === 'Male') ? 'selected' : ''; ?>>Male</option><option value="Female" <?php echo (($_POST['gender'] ?? '') === 'Female') ? 'selected' : ''; ?>>Female</option></select></div>
                    <div class="col-md-6"><label class="form-label">Contact Number</label><input type="text" name="contactNo" class="form-control" value="<?php echo escape($_POST['contactNo'] ?? ''); ?>"></div>
                    <div class="col-md-6"><label class="form-label">Discount Rate (%)</label><input type="number" step="0.01" name="discount" class="form-control" value="<?php echo escape($_POST['discount'] ?? '0.00'); ?>"></div>
                </div>
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">Save Member</button>
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
