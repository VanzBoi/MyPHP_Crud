<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM appointments WHERE appointmentID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$e1List = $conn->query("SELECT serviceID, serviceName FROM services ORDER BY serviceName ASC");
$e2List = $conn->query("SELECT clientID, clientName FROM clients ORDER BY clientName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $serviceID = (int)($_POST['serviceID'] ?? 0);
    $clientID = (int)($_POST['clientID'] ?? 0);
    $appointmentDate = is_string($_POST['appointmentDate'] ?? null) ? trim($_POST['appointmentDate']) : '';
    $appointmentTime = is_string($_POST['appointmentTime'] ?? null) ? trim($_POST['appointmentTime']) : '';
    $totalFee = is_string($_POST['totalFee'] ?? null) ? trim($_POST['totalFee']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($serviceID <= 0 || $clientID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "UPDATE appointments SET `serviceID` = '" . $conn->real_escape_string($serviceID) . "', `clientID` = '" . $conn->real_escape_string($clientID) . "', `appointmentDate` = '" . $conn->real_escape_string($appointmentDate) . "', `appointmentTime` = '" . $conn->real_escape_string($appointmentTime) . "', `totalFee` = '" . $conn->real_escape_string($totalFee) . "', `status` = '" . $conn->real_escape_string($status) . "' WHERE appointmentID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Appointment #<?= $id ?> - Professional Service Appointment System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Appointment #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Service <span class="text-danger">*</span></label>
            <select name="serviceID" class="form-select" required>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['serviceID'] ?>" <?= ($row['serviceID'] == $e1Row['serviceID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e1Row['serviceName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Client <span class="text-danger">*</span></label>
            <select name="clientID" class="form-select" required>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['clientID'] ?>" <?= ($row['clientID'] == $e2Row['clientID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e2Row['clientName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Date</label>
                <input type="date" name="appointmentDate" class="form-control" value="<?= htmlspecialchars($row['appointmentDate'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Time Slot</label>
                <input type="text" name="appointmentTime" class="form-control" value="<?= htmlspecialchars($row['appointmentTime'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Total Fee (₱)</label>
                <input type="number" step="0.01" name="totalFee" class="form-control" value="<?= htmlspecialchars($row['totalFee'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Status</label>
                <select name="status" class="form-select" required>
                    <option value="Pending" <?= ($row['status'] ?? '') === 'Pending' ? 'selected' : '' ?>>Pending</option>
<option value="Confirmed" <?= ($row['status'] ?? '') === 'Confirmed' ? 'selected' : '' ?>>Confirmed</option>
<option value="Completed" <?= ($row['status'] ?? '') === 'Completed' ? 'selected' : '' ?>>Completed</option>
<option value="Cancelled" <?= ($row['status'] ?? '') === 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>