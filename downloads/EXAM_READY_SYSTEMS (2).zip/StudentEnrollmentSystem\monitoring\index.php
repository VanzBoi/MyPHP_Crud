<?php
require '../database.php';
require '../helpers.php';
$course = is_string($_GET['course'] ?? null) ? trim($_GET['course']) : '';
$where = '';
$params = [];
if ($course !== '') {
    $where = 'WHERE s.course = ?';
    $params = [$course];
}
$query = "SELECT e.*, s.fname, s.lname, s.course, sub.subjectCode, sub.subjectName, sub.units, sub.totalFee FROM enrollment e JOIN students s ON e.studentID = s.studentID JOIN subjects sub ON e.subjectID = sub.subjectID $where ORDER BY e.enrollDate DESC";
$stmt = $mysqli->prepare($query);
if ($params) {
    $stmt->bind_param('s', ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$courseStmt = $mysqli->prepare('SELECT DISTINCT course FROM students ORDER BY course');
$courseStmt->execute();
$courses = $courseStmt->get_result();

$totalQuery = "SELECT COUNT(*) AS totalEnrollments, SUM(sub.totalFee) AS totalFees, SUM(e.amountPaid) AS totalAmountPaid, SUM(e.balance) AS totalBalance FROM enrollment e JOIN students s ON e.studentID = s.studentID JOIN subjects sub ON e.subjectID = sub.subjectID $where";
$totalStmt = $mysqli->prepare($totalQuery);
if ($params) {
    $totalStmt->bind_param('s', ...$params);
}
$totalStmt->execute();
$totals = $totalStmt->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
  <?php include '../navbar.php'; ?>
  <main class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
      <div>
        <h1 class="h3 mb-1">Monitoring</h1>
        <p class="text-muted mb-0">View enrollment details and summary totals by course.</p>
      </div>
    </div>

    <div class="card mb-4">
      <div class="card-body">
        <form class="row g-3 align-items-end" action="index.php" method="get">
          <div class="col-md-8">
            <label for="course" class="form-label">Filter by Course</label>
            <select id="course" name="course" class="form-select">
              <option value="">All courses</option>
              <?php while ($row = $courses->fetch_assoc()) : ?>
                <option value="<?= e($row['course']) ?>" <?= $course === $row['course'] ? 'selected' : '' ?>><?= e($row['course']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="col-md-4 d-grid">
            <button class="btn btn-outline-primary" type="submit">Apply Filter</button>
          </div>
        </form>
      </div>
    </div>

    <div class="card mb-4">
      <div class="card-header fw-bold">Enrollment Monitoring Records</div>
      <div class="table-responsive">
        <table class="table table-striped table-bordered align-middle mb-0">
          <thead class="table-light">
            <tr><th>Student</th><th>Course</th><th>Subject Code</th><th>Subject Name</th><th>Units</th><th>Total Fee</th><th>Amount Paid</th><th>Balance</th><th>Payment Mode</th><th>Enrollment Date</th></tr>
          </thead>
          <tbody>
            <?php while ($row = $result->fetch_assoc()) : ?>
            <tr>
              <td><?= e($row['fname'] . ' ' . $row['lname']) ?></td>
              <td><?= e($row['course']) ?></td>
              <td><?= e($row['subjectCode']) ?></td>
              <td><?= e($row['subjectName']) ?></td>
              <td><?= e($row['units']) ?></td>
              <td><?= e(number_format($row['totalFee'], 2)) ?></td>
              <td><?= e(number_format($row['amountPaid'], 2)) ?></td>
              <td><?= e(number_format($row['balance'], 2)) ?></td>
              <td><?= e($row['paymentMode']) ?></td>
              <td><?= e($row['enrollDate']) ?></td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="row row-cols-1 row-cols-md-4 g-3">
      <div class="col">
        <div class="card">
          <div class="card-body">
            <h6 class="card-title text-uppercase text-muted">Total Enrollments</h6>
            <p class="fs-4 mb-0"><?= e($totals['totalEnrollments'] ?? 0) ?></p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card">
          <div class="card-body">
            <h6 class="card-title text-uppercase text-muted">Total Fees</h6>
            <p class="fs-4 mb-0"><?= e(number_format($totals['totalFees'] ?? 0, 2)) ?></p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card">
          <div class="card-body">
            <h6 class="card-title text-uppercase text-muted">Amount Paid</h6>
            <p class="fs-4 mb-0"><?= e(number_format($totals['totalAmountPaid'] ?? 0, 2)) ?></p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card">
          <div class="card-body">
            <h6 class="card-title text-uppercase text-muted">Total Balance</h6>
            <p class="fs-4 mb-0"><?= e(number_format($totals['totalBalance'] ?? 0, 2)) ?></p>
          </div>
        </div>
      </div>
    </div>
  </main>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
