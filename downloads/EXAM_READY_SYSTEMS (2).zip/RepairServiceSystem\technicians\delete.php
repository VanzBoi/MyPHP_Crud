<?php
require_once '../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    $conn->query("DELETE FROM technicians WHERE techID = $id");
}

header("Location: index.php");
exit;
?>
