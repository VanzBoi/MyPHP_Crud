CREATE DATABASE IF NOT EXISTS bookstore_system_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bookstore_system_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS books (
  bookID INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(100) NOT NULL,
  author VARCHAR(100) NOT NULL,
  genre VARCHAR(50) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  stock INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
  customerID INT AUTO_INCREMENT PRIMARY KEY,
  customerName VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL,
  membershipType VARCHAR(50) DEFAULT 'Regular'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  orderID INT AUTO_INCREMENT PRIMARY KEY,
  bookID INT NOT NULL,
  customerID INT NOT NULL,
  orderDate DATE NOT NULL,
  quantity INT NOT NULL,
  totalAmount DECIMAL(10,2) NOT NULL,
  paymentMode VARCHAR(50) DEFAULT 'Cash',
  FOREIGN KEY (bookID) REFERENCES books(bookID) ON DELETE CASCADE,
  FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO books (title, author, genre, price, stock) VALUES
('Clean Code', 'Robert C. Martin', 'Technology', 1850.00, 25),
('Atomic Habits', 'James Clear', 'Self-Help', 890.00, 50),
('The Design of Everyday Things', 'Don Norman', 'Design', 1250.00, 30),
('Sapiens: A Brief History', 'Yuval Noah Harari', 'History', 980.00, 40);

INSERT INTO customers (customerName, email, contactNumber, membershipType) VALUES
('Lorena Santos', 'lsantos@gmail.com', '09171234488', 'Student'),
('Jaime Rodriguez', 'jrodriguez@yahoo.com', '09182345599', 'Faculty'),
('Beatriz Gomez', 'bgomez@outlook.com', '09223456600', 'Regular');

INSERT INTO orders (bookID, customerID, orderDate, quantity, totalAmount, paymentMode) VALUES
(1, 1, '2026-10-25', 1, 1850.00, 'Cash'),
(2, 2, '2026-10-26', 2, 1780.00, 'GCash'),
(3, 3, '2026-10-27', 1, 1250.00, 'Card');

SET FOREIGN_KEY_CHECKS=1;