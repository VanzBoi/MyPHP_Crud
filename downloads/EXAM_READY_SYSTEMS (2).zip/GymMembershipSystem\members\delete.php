<?php
require_once '../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    $conn->query("DELETE FROM members WHERE memberID = $id");
}

header("Location: index.php");
exit;
?>
