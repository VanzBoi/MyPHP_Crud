<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT dentistID, dentistName FROM dentists ORDER BY dentistName ASC");
$e2List = $conn->query("SELECT patientID, patientName FROM patients ORDER BY patientName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dentistID = (int)($_POST['dentistID'] ?? 0);
    $patientID = (int)($_POST['patientID'] ?? 0);
    $appointmentDate = is_string($_POST['appointmentDate'] ?? null) ? trim($_POST['appointmentDate']) : '';
    $appointmentTime = is_string($_POST['appointmentTime'] ?? null) ? trim($_POST['appointmentTime']) : '';
    $serviceRendered = is_string($_POST['serviceRendered'] ?? null) ? trim($_POST['serviceRendered']) : '';
    $totalFee = is_string($_POST['totalFee'] ?? null) ? trim($_POST['totalFee']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($dentistID <= 0 || $patientID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "INSERT INTO appointments (`dentistID`, `patientID`, `appointmentDate`, `appointmentTime`, `serviceRendered`, `totalFee`, `status`) VALUES ('" . $conn->real_escape_string($dentistID) . "', '" . $conn->real_escape_string($patientID) . "', '" . $conn->real_escape_string($appointmentDate) . "', '" . $conn->real_escape_string($appointmentTime) . "', '" . $conn->real_escape_string($serviceRendered) . "', '" . $conn->real_escape_string($totalFee) . "', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Appointment - Dental Clinic Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Record New Appointment</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Dentist <span class="text-danger">*</span></label>
            <select name="dentistID" class="form-select" required>
                <option value="">-- Select Dentist --</option>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['dentistID'] ?>"><?= htmlspecialchars($e1Row['dentistName']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Patient <span class="text-danger">*</span></label>
            <select name="patientID" class="form-select" required>
                <option value="">-- Select Patient --</option>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['patientID'] ?>"><?= htmlspecialchars($e2Row['patientName']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Date</label>
                <input type="date" name="appointmentDate" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Time Slot</label>
                <input type="text" name="appointmentTime" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Service Rendered</label>
                <input type="text" name="serviceRendered" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Total Fee (₱)</label>
                <input type="number" step="0.01" name="totalFee" class="form-control" value="0" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Status</label>
                <select name="status" class="form-select" required>
                    <option value="Scheduled">Scheduled</option>
<option value="Completed">Completed</option>
<option value="Cancelled">Cancelled</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Submit Appointment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>