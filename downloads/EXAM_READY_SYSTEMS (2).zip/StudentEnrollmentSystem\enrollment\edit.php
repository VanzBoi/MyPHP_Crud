<?php
require '../database.php';
require '../helpers.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    redirect('index.php');
}

$res = $conn->query("SELECT * FROM enrollment WHERE enrollID = $id");
if (!$res || $res->num_rows === 0) {
    redirect('index.php');
}
$enrollment = $res->fetch_assoc();

$students = $conn->query('SELECT studentID, fname, lname, course FROM students ORDER BY fname, lname');
$subjects = $conn->query('SELECT subjectID, subjectCode, subjectName, units, feePerUnit, totalFee FROM subjects ORDER BY subjectCode');

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentID = (int)($_POST['studentID'] ?? 0);
    $subjectID = (int)($_POST['subjectID'] ?? 0);
    $enrollDate = is_string($_POST['enrollDate'] ?? null) ? trim($_POST['enrollDate']) : '';
    $amountPaid = is_string($_POST['amountPaid'] ?? null) ? trim($_POST['amountPaid']) : '';
    $paymentMode = is_string($_POST['paymentMode'] ?? null) ? trim($_POST['paymentMode']) : '';

    if ($studentID <= 0) $errors[] = 'Valid student is required.';
    if ($subjectID <= 0) $errors[] = 'Valid subject is required.';
    if ($enrollDate === '') $errors[] = 'Enrollment date is required.';
    if ($amountPaid === '' || !is_numeric($amountPaid)) $errors[] = 'Valid amount paid is required.';
    if ($paymentMode === '') $errors[] = 'Payment mode is required.';

    if (!$errors) {
        $subjectRes = $conn->query("SELECT totalFee FROM subjects WHERE subjectID = $subjectID");
        $subject = $subjectRes ? $subjectRes->fetch_assoc() : null;
        if (!$subject) {
            $errors[] = 'Subject not found.';
        }
    }

    if (!$errors) {
        $totalFee = (float)$subject['totalFee'];
        $balance = number_format($totalFee - (float)$amountPaid, 2, '.', '');
        $sql = "UPDATE enrollment SET `studentID` = '" . $conn->real_escape_string($studentID) . "', `subjectID` = '" . $conn->real_escape_string($subjectID) . "', `enrollDate` = '" . $conn->real_escape_string($enrollDate) . "', `amountPaid` = '" . $conn->real_escape_string($amountPaid) . "', `balance` = '" . $conn->real_escape_string($balance) . "', `paymentMode` = '" . $conn->real_escape_string($paymentMode) . "' WHERE enrollID = $id";
        if ($conn->query($sql)) {
            flash('Enrollment updated successfully.');
            redirect('index.php');
        } else {
            $errors[] = 'Failed to update transaction: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Enrollment</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
  <?php include '../navbar.php'; ?>
  <main class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="h3 mb-0">Edit Enrollment</h1>
      </div>
      <a class="btn btn-secondary" href="index.php">Back to Enrollment</a>
    </div>

    <?php if ($errors) : ?>
      <div class="alert alert-danger">
        <ul class="mb-0">
          <?php foreach ($errors as $error) : ?>
            <li><?= e($error) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form class="row g-3" action="edit.php?id=<?= e($id) ?>" method="post">
      <div class="col-md-6">
        <label for="studentID" class="form-label">Student</label>
        <select id="studentID" name="studentID" required class="form-select">
          <option value="">Select student</option>
          <?php while ($student = $students->fetch_assoc()) : ?>
            <option value="<?= e($student['studentID']) ?>" <?= ((isset($_POST['studentID']) && $_POST['studentID'] == $student['studentID']) || (!isset($_POST['studentID']) && $enrollment['studentID'] == $student['studentID'])) ? 'selected' : '' ?>><?= e($student['fname'] . ' ' . $student['lname'] . ' (' . $student['course'] . ')') ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-6">
        <label for="subjectID" class="form-label">Subject</label>
        <select id="subjectID" name="subjectID" required class="form-select">
          <option value="">Select subject</option>
          <?php while ($subject = $subjects->fetch_assoc()) : ?>
            <option value="<?= e($subject['subjectID']) ?>" <?= ((isset($_POST['subjectID']) && $_POST['subjectID'] == $subject['subjectID']) || (!isset($_POST['subjectID']) && $enrollment['subjectID'] == $subject['subjectID'])) ? 'selected' : '' ?>><?= e($subject['subjectCode'] . ' - ' . $subject['subjectName'] . ' (' . $subject['units'] . ' units)') ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-4">
        <label for="enrollDate" class="form-label">Enrollment Date</label>
        <input id="enrollDate" name="enrollDate" type="date" value="<?= e($_POST['enrollDate'] ?? $enrollment['enrollDate']) ?>" required class="form-control">
      </div>
      <div class="col-md-4">
        <label for="amountPaid" class="form-label">Amount Paid</label>
        <input id="amountPaid" name="amountPaid" type="number" step="0.01" value="<?= e($_POST['amountPaid'] ?? $enrollment['amountPaid']) ?>" required class="form-control">
      </div>
      <div class="col-md-4">
        <label for="paymentMode" class="form-label">Payment Mode</label>
        <select id="paymentMode" name="paymentMode" required class="form-select">
          <option value="">Select payment mode</option>
          <option value="Cash" <?= ((isset($_POST['paymentMode']) && $_POST['paymentMode'] === 'Cash') || (!isset($_POST['paymentMode']) && $enrollment['paymentMode'] === 'Cash')) ? 'selected' : '' ?>>Cash</option>
          <option value="Online" <?= ((isset($_POST['paymentMode']) && $_POST['paymentMode'] === 'Online') || (!isset($_POST['paymentMode']) && $enrollment['paymentMode'] === 'Online')) ? 'selected' : '' ?>>Online</option>
          <option value="Other" <?= ((isset($_POST['paymentMode']) && $_POST['paymentMode'] === 'Other') || (!isset($_POST['paymentMode']) && $enrollment['paymentMode'] === 'Other')) ? 'selected' : '' ?>>Other</option>
        </select>
      </div>
      <div class="col-12 d-grid">
        <button class="btn btn-primary" type="submit">Update Enrollment</button>
      </div>
    </form>
  </main>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
