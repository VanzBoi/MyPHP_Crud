CREATE DATABASE IF NOT EXISTS student_records_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE student_records_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS courses (
  courseID INT AUTO_INCREMENT PRIMARY KEY,
  courseCode VARCHAR(50) NOT NULL UNIQUE,
  courseTitle VARCHAR(100) NOT NULL,
  units INT NOT NULL,
  department VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS students (
  studentID INT AUTO_INCREMENT PRIMARY KEY,
  studentNumber VARCHAR(50) NOT NULL UNIQUE,
  fullName VARCHAR(100) NOT NULL,
  yearLevel VARCHAR(50) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS grades (
  gradeID INT AUTO_INCREMENT PRIMARY KEY,
  courseID INT NOT NULL,
  studentID INT NOT NULL,
  semester VARCHAR(50) NOT NULL,
  midterm DECIMAL(5,2) NOT NULL,
  finals DECIMAL(5,2) NOT NULL,
  finalGrade DECIMAL(5,2) NOT NULL,
  remarks VARCHAR(50) NOT NULL,
  FOREIGN KEY (courseID) REFERENCES courses(courseID) ON DELETE CASCADE,
  FOREIGN KEY (studentID) REFERENCES students(studentID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO courses (courseCode, courseTitle, units, department) VALUES
('IT201', 'Data Structures & Algorithms', 3, 'CCS'),
('IT205', 'Web Systems & Technologies', 3, 'CCS'),
('MATH101', 'Calculus for Computing', 3, 'CAS'),
('ENG102', 'Technical Communications', 3, 'CAS');

INSERT INTO students (studentNumber, fullName, yearLevel, contactNumber) VALUES
('2024-00121', 'John Cedrick Libradilla', '3rd Year', '09171112233'),
('2024-00122', 'Angelica Rivera', '3rd Year', '09182223344'),
('2024-00123', 'Joshua Garcia', '2nd Year', '09223334455');

INSERT INTO grades (courseID, studentID, semester, midterm, finals, finalGrade, remarks) VALUES
(1, 1, '1st Semester 2026', 1.4, 1.2, 1.30, 'Passed'),
(2, 2, '1st Semester 2026', 1.5, 1.3, 1.40, 'Passed'),
(3, 3, '1st Semester 2026', 2.0, 2.2, 2.10, 'Passed');

SET FOREIGN_KEY_CHECKS=1;