﻿<?php
require_once __DIR__ . '/../database.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
if ($search !== '') {
    $s = $conn->real_escape_string($search);
    $firstField = key($fields = ['supplierName' => 1, 'contactPerson' => 1, 'phone' => 1, 'city' => 1, ]);
    $q = "SELECT * FROM suppliers WHERE supplierName LIKE '%$s%' OR contactPerson LIKE '%$s%' ORDER BY supplierID DESC";
} else {
    $q = "SELECT * FROM suppliers ORDER BY supplierID DESC";
}
$res = $conn->query($q);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier List - Warehouse Inventory &amp; Stock Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="fw-bold mb-0">Supplier Management</h3>
            </div>
            <a href="add.php" class="btn btn-primary btn-sm">+ Add New Supplier</a>
        </div>

        <div class="card mb-4">
            <div class="card-body p-3">
                <form method="GET" class="row g-2">
                    <div class="col-md-10">
                        <input type="text" name="search" class="form-control form-control-sm" placeholder="Search by name, code or keyword..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-dark btn-sm w-100">Search</button>
                        <?php if ($search !== ''): ?>
                            <a href="index.php" class="btn btn-outline-secondary btn-sm">Reset</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="table table-striped table-bordered align-middle mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Supplier Name</th>
<th>Contact Person</th>
<th>Phone</th>
<th>City</th>

                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($res && $res->num_rows > 0): ?>
                            <?php while ($r = $res->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['supplierID'] ?></td>
                                    <td><?= htmlspecialchars($r['supplierName']) ?></td>
<td><?= htmlspecialchars($r['contactPerson']) ?></td>
<td><?= htmlspecialchars($r['phone']) ?></td>
<td><?= htmlspecialchars($r['city']) ?></td>

                                    <td class="text-end">
                                        <a href="edit.php?id=<?= $r['supplierID'] ?>" class="btn btn-outline-primary btn-sm py-0 px-2">Edit</a>
                                        <a href="delete.php?id=<?= $r['supplierID'] ?>" class="btn btn-outline-danger btn-sm py-0 px-2" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="10" class="text-center py-4 text-muted">No records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer class="text-center">
        <div class="container">
            <p class="mb-0">&copy; <?= date('Y') ?> Warehouse Inventory &amp; Stock Management System</p>
        </div>
    </footer>
    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>