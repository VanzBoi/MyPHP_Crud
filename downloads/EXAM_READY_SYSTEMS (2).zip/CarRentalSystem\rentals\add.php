<?php
require_once '../database.php';
$msg = '';

$vehicles = $conn->query("SELECT * FROM vehicles ORDER BY brandModel ASC");
$customers = $conn->query("SELECT * FROM customers ORDER BY custLName ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vehID = (int)($_POST['vehicleID'] ?? 0);
    $custID = (int)($_POST['customerID'] ?? 0);
    $rDate = is_string($_POST['rentalDate'] ?? null) ? trim($_POST['rentalDate']) : '';
    $retDate = is_string($_POST['returnDate'] ?? null) ? trim($_POST['returnDate']) : '';
    $mode = is_string($_POST['paymentMode'] ?? null) ? trim($_POST['paymentMode']) : '';

    $validDates = false;
    $days = 1;
    if ($rDate !== '' && $retDate !== '') {
        try {
            $d1 = new DateTime($rDate);
            $d2 = new DateTime($retDate);
            $days = $d2->diff($d1)->days;
            if ($days <= 0) $days = 1;
            $validDates = true;
        } catch (\Exception $e) {
            $msg = "<div class='alert alert-danger'>Invalid rental dates provided.</div>";
        }
    } else {
        $msg = "<div class='alert alert-danger'>Please select valid rental dates.</div>";
    }

    if ($vehID > 0 && $custID > 0 && $validDates) {
        // Fetch vehicle daily rate
        $vRes = $conn->query("SELECT dailyRate FROM vehicles WHERE vehicleID = $vehID");
        $vRow = $vRes ? $vRes->fetch_assoc() : null;
        $rate = $vRow ? floatval($vRow['dailyRate']) : 0;
        $totalFee = $days * $rate;

        $sql = "INSERT INTO rentals (vehicleID, customerID, rentalDate, returnDate, totalDays, totalFee, paymentMode) VALUES ($vehID, $custID, '" . $conn->real_escape_string($rDate) . "', '" . $conn->real_escape_string($retDate) . "', $days, $totalFee, '" . $conn->real_escape_string($mode) . "')";
        if ($conn->query($sql)) {
            // Update vehicle status
            $conn->query("UPDATE vehicles SET status = 'Rented' WHERE vehicleID = $vehID");
            header("Location: index.php?msg=booked");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Failed to record transaction: " . htmlspecialchars($conn->error) . "</div>";
        }
    } elseif (!$msg) {
        $msg = "<div class='alert alert-danger'>Please fill all required fields.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New Rental</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 650px;">
        <div class="card p-4 mb-3">
            <h4>Book Vehicle Rental</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Select Vehicle</label>
                    <select name="vehicleID" class="form-select" required>
                        <option value="">-- Choose Vehicle --</option>
                        <?php while($v = $vehicles->fetch_assoc()): ?>
                        <option value="<?php echo $v['vehicleID']; ?>">
                            <?php echo htmlspecialchars($v['brandModel'] . ' (' . $v['plateNumber'] . ') - ₱' . number_format($v['dailyRate'], 2) . '/day'); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Select Customer</label>
                    <select name="customerID" class="form-select" required>
                        <option value="">-- Choose Customer --</option>
                        <?php while($c = $customers->fetch_assoc()): ?>
                        <option value="<?php echo $c['customerID']; ?>">
                            <?php echo htmlspecialchars($c['custLName'] . ', ' . $c['custFName'] . ' (' . $c['licenseNumber'] . ')'); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Rental Date</label>
                        <input type="date" name="rentalDate" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Return Date</label>
                        <input type="date" name="returnDate" class="form-control" required value="<?php echo date('Y-m-d', strtotime('+2 days')); ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Payment Mode</label>
                    <select name="paymentMode" class="form-select">
                        <option value="Cash">Cash</option>
                        <option value="GCash">GCash</option>
                        <option value="Credit Card">Credit Card</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100">Confirm Rental Booking</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to Rentals</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>