<?php
if (!isset($baseUrl)) {
    require_once __DIR__ . '/database.php';
}
$navBase = rtrim($baseUrl, '/');
$currentUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container-fluid container">
        <a class="navbar-brand nav-brand" href="<?php echo $navBase; ?>/index.php">Gym Membership</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/members/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/members/index.php">Members</a></li>
                <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/packages/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/packages/index.php">Packages</a></li>
                <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/memberships/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/memberships/index.php">Memberships</a></li>
                <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/monitoring/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/monitoring/index.php">Monitoring</a></li>
            </ul>
        </div>
    </div>
</nav>
