<?php
require_once '../database.php';

$query = "SELECT b.*, m.movieTitle, m.cinemaHall, m.ticketPrice, c.custFName, c.custLName, c.customerType 
          FROM bookings b
          JOIN movies m ON b.movieID = m.movieID
          JOIN customers c ON b.customerID = c.customerID
          ORDER BY b.bookingID DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ticket Bookings</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Ticket Bookings</h3>
            <a href="add.php" class="btn btn-primary">+ Book Movie Ticket</a>
        </div>
        <div class="card mb-3">
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>Booking #</th>
                        <th>Movie Title</th>
                        <th>Customer</th>
                        <th>Type</th>
                        <th>Date</th>
                        <th>Tickets</th>
                        <th>Amount Paid</th>
                        <th>Payment Mode</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $row['bookingID']; ?></td>
                            <td>
                                <strong> <?php echo htmlspecialchars($row['movieTitle']); ?></strong>
                                <small class="text-muted d-block"><?php echo htmlspecialchars($row['cinemaHall']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($row['custFName'] . ' ' . $row['custLName']); ?></td>
                            <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($row['customerType']); ?></span></td>
                            <td><?php echo $row['bookingDate']; ?></td>
                            <td><?php echo $row['numTickets']; ?> ticket(s)</td>
                            <td><strong class="text-success">₱<?php echo number_format($row['totalAmountPaid'], 2); ?></strong></td>
                            <td><span class="badge bg-info text-dark"><?php echo htmlspecialchars($row['paymentMode']); ?></span></td>
                            <td class="text-end">
                                <a href="delete.php?id=<?php echo $row['bookingID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Cancel/Delete booking?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="9" class="text-center py-4 text-muted">No ticket bookings recorded yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>