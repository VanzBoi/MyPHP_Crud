﻿# Bookstore Management System

A simple PHP and MySQL web application for managing books, customers, and orders.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\BookSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/BookSystem/
4. The database `bookstore_system_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Books**: Add, view, edit, and delete books records.
- **Customers**: Add, view, edit, and delete customers records.
- **Orders**: Manage orders transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
