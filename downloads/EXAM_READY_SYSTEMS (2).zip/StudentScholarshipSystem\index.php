<?php
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/helpers.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Scholarship System</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="page-heading mb-4">
            <h1>Student Scholarship System</h1>
            <p class="text-muted">Manage student scholars, scholarship programs, application grants, and analytics.</p>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-bold">System Navigation</div>
            <div class="card-body">
                <div class="list-group">
                    <a href="students/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Students Management</span> <span class="text-muted">&rarr;</span></a>
                    <a href="scholarships/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Scholarships Programs</span> <span class="text-muted">&rarr;</span></a>
                    <a href="applications/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Applications & Grants</span> <span class="text-muted">&rarr;</span></a>
                    <a href="monitoring/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Monitoring & Reports</span> <span class="badge bg-primary">Monitoring</span></a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
