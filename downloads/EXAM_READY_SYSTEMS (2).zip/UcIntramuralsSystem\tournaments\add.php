<?php
require_once '../database.php';
$athletes = $conn->query("SELECT a.*, d.deptCode FROM athletes a JOIN departments d ON a.deptID = d.deptID ORDER BY a.fullName ASC");
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $athID = (int)($_POST['athleteID'] ?? 0);
    $sport = is_string($_POST['sportEvent'] ?? null) ? trim($_POST['sportEvent']) : '';
    $cat = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
    $bracket = is_string($_POST['bracket'] ?? null) ? trim($_POST['bracket']) : '';
    $date = is_string($_POST['matchDate'] ?? null) ? trim($_POST['matchDate']) : '';
    $fee = floatval($_POST['regFee'] ?? 0);
    $status = is_string($_POST['matchStatus'] ?? null) ? trim($_POST['matchStatus']) : 'Scheduled';

    if ($athID <= 0 || $sport === '' || $date === '') {
        $err = 'Please complete all required fields.';
    } else {
        $sql = "INSERT INTO tournaments (`athleteID`, `sportEvent`, `category`, `bracket`, `matchDate`, `regFee`, `matchStatus`) VALUES ('" . $conn->real_escape_string($athID) . "', '" . $conn->real_escape_string($sport) . "', '" . $conn->real_escape_string($cat) . "', '" . $conn->real_escape_string($bracket) . "', '" . $conn->real_escape_string($date) . "', '" . $conn->real_escape_string($fee) . "', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Failed to record transaction: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register Tournament Match</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 650px;">
        <div class="card p-4">
            <h4 class="mb-3">Tournament Match Registration</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Athlete</label>
                    <select name="athleteID" class="form-select" required>
                        <option value="">-- Choose Athlete --</option>
                        <?php while($a = $athletes->fetch_assoc()): ?>
                            <option value="<?php echo $a['athleteID']; ?>">
                                <?php echo htmlspecialchars($a['fullName'] . ' (' . $a['deptCode'] . ' - ' . $a['studentID'] . ')'); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Sport / Event</label>
                        <input type="text" name="sportEvent" class="form-control" required placeholder="e.g. Basketball 5v5, Badminton">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Category Division</label>
                        <select name="category" class="form-select" required>
                            <option value="Men Division">Men Division</option>
                            <option value="Women Division">Women Division</option>
                            <option value="Mixed Team">Mixed Team</option>
                        </select>
                    </div>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Tournament Bracket</label>
                        <select name="bracket" class="form-select" required>
                            <option value="Eliminations">Eliminations</option>
                            <option value="Quarterfinals">Quarterfinals</option>
                            <option value="Semifinals">Semifinals</option>
                            <option value="Finals / Championship">Finals / Championship</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Match Schedule</label>
                        <input type="date" name="matchDate" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Registration Fee (₱)</label>
                        <input type="number" step="0.01" name="regFee" class="form-control" value="150.00" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Initial Status</label>
                        <select name="matchStatus" class="form-select" required>
                            <option value="Scheduled">Scheduled</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Winner">Winner</option>
                            <option value="Eliminated">Eliminated</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Register Entry</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>