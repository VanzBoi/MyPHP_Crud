<?php
// Global navigation bar
$cur = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= $baseUrl ?>index.php">Student Academic Records &amp; Grading System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (strpos($cur, '/index.php') !== false && strpos($cur, '/courses') === false && strpos($cur, '/students') === false && strpos($cur, '/grades') === false && strpos($cur, '/monitoring') === false) ? 'active' : '' ?>" href="<?= $baseUrl ?>index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/courses/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>courses/index.php">Course / Subject</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/students/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>students/index.php">Student</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/grades/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>grades/index.php">Grade Record</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/monitoring/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>