<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = is_string($_POST['serviceName'] ?? null) ? trim($_POST['serviceName']) : '';
    $type = is_string($_POST['serviceType'] ?? null) ? trim($_POST['serviceType']) : '';
    $price = floatval($_POST['pricePerKilo'] ?? 0);

    if ($name && $price > 0) {
        $stmt = $conn->prepare("INSERT INTO services (serviceName, serviceType, pricePerKilo) VALUES (?, ?, ?)");
        $stmt->bind_param("ssd", $name, $type, $price);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Service</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Add New Laundry Service</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Service Name</label>
                    <input type="text" name="serviceName" class="form-control" required placeholder="e.g. Wash, Dry & Fold">
                </div>
                <div class="mb-3">
                    <label class="form-label">Service Type / Category</label>
                    <select name="serviceType" class="form-select" required>
                        <option value="Regular Wash">Regular Wash</option>
                        <option value="Heavy Wash">Heavy Wash (Comforters/Blankets)</option>
                        <option value="Dry-Cleaning">Dry-Cleaning</option>
                        <option value="Pressing">Pressing & Ironing</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Price per Kilogram (₱)</label>
                    <input type="number" step="0.01" name="pricePerKilo" class="form-control" required placeholder="35.00">
                </div>
                <button type="submit" class="btn btn-primary w-100">Save Service</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>