﻿<?php
require_once 'database.php';

$totalEvents = $conn->query("SELECT COUNT(*) FROM events")->fetch_row()[0];
$totalParticipants = $conn->query("SELECT COUNT(*) FROM participants")->fetch_row()[0];
$totalRegs = $conn->query("SELECT COUNT(*) FROM registrations")->fetch_row()[0];
$totalRevenue = $conn->query("SELECT IFNULL(SUM(feePaid), 0) FROM registrations")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Registration System - Dashboard</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="p-4 mb-4 bg-white rounded-3 border">
            <h1 class="display-6 fw-bold">Campus Event Registration System</h1>
            <p class="lead text-muted mb-0">Workshop, Seminar & Attendee Management</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Registered Events</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalEvents; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Registered Attendees</span>
                    <h3 class="mb-0 text-success"><?php echo $totalParticipants; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Confirmed Registrations</span>
                    <h3 class="mb-0 text-dark"><?php echo $totalRegs; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Total Registration Revenue</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalRevenue, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Events Management</h5>
                    <p class="text-muted small">Create seminars, workshops, define venues, schedules, and standard registration fees.</p>
                    <a href="<?php echo $baseUrl; ?>events/index.php" class="btn btn-outline-primary mt-auto">Open Events &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Attendee Directory</h5>
                    <p class="text-muted small">Manage participant profiles, institutional affiliations, contact numbers, and emails.</p>
                    <a href="<?php echo $baseUrl; ?>participants/index.php" class="btn btn-outline-success mt-auto">Open Participants &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Monitoring & Attendance</h5>
                    <p class="text-muted small">Filter registrations per event, calculate discount deductions, and review financial collections.</p>
                    <a href="<?php echo $baseUrl; ?>monitoring/index.php" class="btn btn-outline-dark mt-auto">Open Monitoring &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>