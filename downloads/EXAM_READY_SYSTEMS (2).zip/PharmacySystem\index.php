﻿<?php
require_once __DIR__ . '/database.php';

$c1 = $conn->query("SELECT COUNT(*) AS total FROM medicines")->fetch_assoc()['total'] ?? 0;
$c2 = $conn->query("SELECT COUNT(*) AS total FROM customers")->fetch_assoc()['total'] ?? 0;
$c3 = $conn->query("SELECT COUNT(*) AS total FROM purchases")->fetch_assoc()['total'] ?? 0;
$sumVal = $conn->query("SELECT IFNULL(SUM(totalAmount), 0) AS total FROM purchases")->fetch_assoc()['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacy Inventory and Sales System - Dashboard</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/navbar.php'; ?>

    <div class="container my-4">
        <div class="p-4 mb-4 rounded bg-white border" class="p-4 mb-4 rounded bg-light border text-dark">
            <div class="col-md-9 px-0">
                <h1 class="display-5 fw-bold">Pharmacy Inventory and Sales System</h1>
                <p class="lead my-3">Pharmaceutical inventory control, customer counter sales, and dispensary revenue monitoring.</p>
                <div class="d-flex gap-2 flex-wrap">
                    <a href="<?= $baseUrl ?>purchases/add.php" class="btn btn-warning fw-semibold">+ New Purchase</a>
                    <a href="<?= $baseUrl ?>monitoring/index.php" class="btn btn-light fw-semibold">View Monitoring Report</a>
                </div>
            </div>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Medicine</div>
                    <div class="fs-3 fw-bold text-dark"><?= $c1 ?></div>
                    <a href="<?= $baseUrl ?>medicines/index.php" class="small text-decoration-none mt-2">Manage Medicine &rarr;</a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Customer</div>
                    <div class="fs-3 fw-bold text-dark"><?= $c2 ?></div>
                    <a href="<?= $baseUrl ?>customers/index.php" class="small text-decoration-none mt-2">Manage Customer &rarr;</a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Total Purchase</div>
                    <div class="fs-3 fw-bold text-dark"><?= $c3 ?></div>
                    <a href="<?= $baseUrl ?>purchases/index.php" class="small text-decoration-none mt-2">View Purchase &rarr;</a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Total Volume / Value</div>
                    <div class="fs-3 fw-bold text-success">₱<?= number_format($sumVal, 2) ?></div>
                    <a href="<?= $baseUrl ?>monitoring/index.php" class="small text-decoration-none mt-2">Analytics &rarr;</a>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Quick Links</span>
                <span class="badge bg-primary">System Menu</span>
            </div>
            <div class="card-body">
                <div class="row g-3 text-center">
                    <div class="col-md-3">
                        <div class="p-3 border rounded bg-white">
                            <h6 class="fw-bold">Medicine CRUD</h6>
                            <p class="small text-muted mb-2">Primary Records</p>
                            <a href="<?= $baseUrl ?>medicines/index.php" class="btn btn-outline-primary btn-sm w-100">Open</a>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="p-3 border rounded bg-white">
                            <h6 class="fw-bold">Customer CRUD</h6>
                            <p class="small text-muted mb-2">Secondary Records</p>
                            <a href="<?= $baseUrl ?>customers/index.php" class="btn btn-outline-primary btn-sm w-100">Open</a>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="p-3 border rounded bg-white">
                            <h6 class="fw-bold">Purchases</h6>
                            <p class="small text-muted mb-2">Transaction Records</p>
                            <a href="<?= $baseUrl ?>purchases/index.php" class="btn btn-outline-primary btn-sm w-100">Open</a>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="p-3 border rounded bg-white">
                            <h6 class="fw-bold">Monitoring Report</h6>
                            <p class="small text-muted mb-2">Summary Report</p>
                            <a href="<?= $baseUrl ?>monitoring/index.php" class="btn btn-outline-primary btn-sm w-100">Open</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="text-center">
        <div class="container">
            <p class="mb-0">&copy; <?= date('Y') ?> Pharmacy Inventory and Sales System</p>
        </div>
    </footer>
    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>