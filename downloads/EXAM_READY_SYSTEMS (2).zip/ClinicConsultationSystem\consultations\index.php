<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';
$res = $mysqli->query("SELECT c.*, p.patFName, p.patLName, d.docFName, d.docLName FROM consultations c JOIN patients p ON c.patID=p.patID JOIN doctors d ON c.docID=d.docID ORDER BY c.consulDate DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Consultations Log - Clinic Consultation</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
  <div class="mb-3">
    <h1>Consultations Log</h1>
    <small class="text-muted">Record medical consultations, diagnosis, and doctor prescriptions</small>
  </div>

  <div class="card mb-4"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <a class="btn btn-primary" href="add.php">+ Record New Consultation</a>
      <a class="btn btn-outline-primary" href="../monitoring/index.php">View Monitoring Report &rarr;</a>
    </div>

    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>Date</th>
          <th>Patient</th>
          <th>Attending Doctor</th>
          <th>Diagnosis</th>
          <th>Prescription</th>
        </tr>
      </thead>
      <tbody>
      <?php if ($res && $res->num_rows > 0): ?>
        <?php while ($r = $res->fetch_assoc()): ?>
          <tr>
            <td><?php echo e($r['consulDate']); ?></td>
            <td><strong><?php echo e($r['patFName'].' '.$r['patLName']); ?></strong></td>
            <td><span class="badge bg-info text-dark">Dr. <?php echo e($r['docFName'].' '.$r['docLName']); ?></span></td>
            <td><?php echo e($r['diagnosis']); ?></td>
            <td><?php echo e($r['prescription']); ?></td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="5" class="text-center text-muted py-3">No consultations logged yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  </div>
</div>
<script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
