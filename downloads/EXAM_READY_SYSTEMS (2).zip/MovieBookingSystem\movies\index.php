<?php
require_once '../database.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
if ($search !== '') {
    $stmt = $conn->prepare("SELECT * FROM movies WHERE movieTitle LIKE ? OR genre LIKE ? OR cinemaHall LIKE ? ORDER BY movieID DESC");
    $param = "%$search%";
    $stmt->bind_param("sss", $param, $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM movies ORDER BY movieID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Movies Management</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Movies Management</h3>
            <a href="add.php" class="btn btn-primary">+ Add New Movie</a>
        </div>
        <div class="card p-3 mb-3">
            <form method="GET" class="row g-2">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="Search by title, genre, or cinema hall..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-secondary w-100">Search</button>
                </div>
            </form>
        </div>
        <div class="card mb-3">
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Movie Title</th>
                        <th>Genre</th>
                        <th>Cinema Hall</th>
                        <th>Duration</th>
                        <th>Ticket Price</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['movieID']; ?></td>
                            <td><strong> <?php echo htmlspecialchars($row['movieTitle']); ?></strong></td>
                            <td><span class="badge bg-secondary"><?php echo htmlspecialchars($row['genre']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['cinemaHall']); ?></td>
                            <td><?php echo $row['durationMinutes']; ?> mins</td>
                            <td><strong class="text-primary">₱<?php echo number_format($row['ticketPrice'], 2); ?></strong></td>
                            <td class="text-end">
                                <a href="edit.php?id=<?php echo $row['movieID']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete.php?id=<?php echo $row['movieID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete movie?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">No movies found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>