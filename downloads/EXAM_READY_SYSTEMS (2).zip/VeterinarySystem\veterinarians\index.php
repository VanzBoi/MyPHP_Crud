<?php
require_once '../database.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
if ($search !== '') {
    $stmt = $conn->prepare("SELECT * FROM veterinarians WHERE vetFName LIKE ? OR vetLName LIKE ? OR specialization LIKE ? ORDER BY vetID DESC");
    $param = "%$search%";
    $stmt->bind_param("sss", $param, $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM veterinarians ORDER BY vetID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Veterinarians</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Veterinarians Management</h3>
            <a href="add.php" class="btn btn-primary">+ Add Veterinarian</a>
        </div>
        <div class="card p-3 mb-3">
            <form method="GET" class="row g-2">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="Search by name or specialization..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-secondary w-100">Search</button>
                </div>
            </form>
        </div>
        <div class="card mb-3">
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Doctor Full Name</th>
                        <th>Specialization</th>
                        <th>Contact Number</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['vetID']; ?></td>
                            <td><strong>Dr. <?php echo htmlspecialchars($row['vetFName'] . ' ' . $row['vetLName']); ?></strong></td>
                            <td><span class="badge bg-secondary"><?php echo htmlspecialchars($row['specialization']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['contactNumber']); ?></td>
                            <td class="text-end">
                                <a href="edit.php?id=<?php echo $row['vetID']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete.php?id=<?php echo $row['vetID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this veterinarian?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center py-4 text-muted">No veterinarians found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>