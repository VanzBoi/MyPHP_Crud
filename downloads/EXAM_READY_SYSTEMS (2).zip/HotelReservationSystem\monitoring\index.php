<?php
require_once __DIR__ . '/../database.php';

$filter = is_string($_GET['roomType'] ?? null) ? $conn->real_escape_string(trim($_GET['roomType'])) : '';
$where = '';
if ($filter !== '') {
    $where = "WHERE rm.roomType = '{$filter}'";
}

$query = "SELECT r.*, g.fName, g.lName, rm.roomNo, rm.roomType, rm.price 
          FROM reservations r
          JOIN guests g ON r.guestID = g.guestID
          JOIN rooms rm ON r.roomID = rm.roomID
          {$where}
          ORDER BY r.reserveID DESC";
$result = mysqli_query($conn, $query);

// Calculate summary metrics
$aggQuery = "SELECT COUNT(*) AS totalRes, SUM(r.totalPaid) AS totalAmount, AVG(r.totalPaid) AS avgAmount
             FROM reservations r
             JOIN rooms rm ON r.roomID = rm.roomID
             {$where}";
$aggRes = mysqli_query($conn, $aggQuery);
$agg = mysqli_fetch_assoc($aggRes);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Reservation Monitoring</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
  </head>
<body>
  <?php include '../navbar.php'; ?>
  <div class="container">
    <div class="mb-3">
      <h1>Reservation Monitoring & Inquiry</h1>
      <small class="text-muted">Filter reservations by room type and view summary metrics</small>
    </div>

    <div class="card p-3 mb-3">
      <form method="get" class="row g-2 align-items-center">
        <div class="col-auto">
          <label class="col-form-label fw-bold">Filter by Room Type:</label>
        </div>
        <div class="col-auto">
          <select name="roomType" class="form-select">
            <option value="">-- All Room Types --</option>
            <option value="Standard" <?= $filter === 'Standard' ? 'selected' : '' ?>>Standard</option>
            <option value="Deluxe" <?= $filter === 'Deluxe' ? 'selected' : '' ?>>Deluxe</option>
            <option value="VIP" <?= $filter === 'VIP' ? 'selected' : '' ?>>VIP</option>
          </select>
        </div>
        <div class="col-auto">
          <button type="submit" class="btn btn-primary">Filter</button>
          <a href="index.php" class="btn btn-outline-secondary">Reset</a>
        </div>
      </form>
    </div>

    <div class="card mb-4"><div class="card-header fw-bold">Reservation Monitoring Records</div><div class="card-body">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>Guest Full Name</th>
            <th>Room No</th>
            <th>Room Type</th>
            <th>Check In</th>
            <th>Check Out</th>
            <th>Total Paid</th>
          </tr>
        </thead>
        <tbody>
        <?php if ($result && mysqli_num_rows($result) > 0): ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
            <tr>
              <td><?= $row['reserveID'] ?></td>
              <td><strong><?= htmlspecialchars($row['fName'] . ' ' . $row['lName']) ?></strong></td>
              <td><?= htmlspecialchars($row['roomNo']) ?></td>
              <td><span class="badge bg-info text-dark"><?= htmlspecialchars($row['roomType']) ?></span></td>
              <td><?= htmlspecialchars($row['checkIn']) ?></td>
              <td><?= htmlspecialchars($row['checkOut']) ?></td>
              <td>₱<?= number_format($row['totalPaid'], 2) ?></td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="7" class="text-center text-muted py-3">No reservations found.</td></tr>
        <?php endif; ?>
        </tbody>
      </table>

      <!-- Summary Cards -->
      <h3 class="mt-4 mb-3">Summary Metrics</h3>
      <div class="row g-3">
        <div class="col-md-4">
          <div class="">
            <div class="stat-val"><?= (int)$agg['totalRes'] ?></div>
            <div class="stat-label">Total Reservations</div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="">
            <div class="stat-val text-success">₱<?= number_format($agg['totalAmount'] ?? 0, 2) ?></div>
            <div class="stat-label">Total Revenue Collected</div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="">
            <div class="stat-val text-primary">₱<?= number_format($agg['avgAmount'] ?? 0, 2) ?></div>
            <div class="stat-label">Average Paid per Reservation</div>
          </div>
        </div>
      </div>
    </div>
    </div>
  </div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
