<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';

$q = is_string($_GET['q'] ?? null) ? trim($_GET['q']) : '';
if ($q !== '') {
    $safeQ = $mysqli->real_escape_string($q);
    $res = $mysqli->query("SELECT * FROM patients WHERE patFName LIKE '%$safeQ%' OR patLName LIKE '%$safeQ%' ORDER BY patID DESC");
} else {
    $res = $mysqli->query("SELECT * FROM patients ORDER BY patID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Patients Management - Clinic Consultation</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
  <div class="mb-3">
    <h1>Patients Management</h1>
    <small class="text-muted">Register and search patient medical profiles</small>
  </div>

  <div class="card mb-4"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <a class="btn btn-primary" href="add.php">+ Add New Patient</a>
      <form class="d-flex gap-2" method="get" style="max-width: 340px;">
        <input class="form-control" name="q" placeholder="Search patient name..." value="<?php echo e($q); ?>">
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if ($q): ?>
          <a href="index.php" class="btn btn-outline-secondary">Clear</a>
        <?php endif; ?>
      </form>
    </div>

    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Full Name</th>
          <th>Birthdate</th>
          <th>Telephone</th>
          <th style="width: 140px;">Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php if ($res && $res->num_rows > 0): ?>
        <?php while ($row = $res->fetch_assoc()): ?>
          <tr>
            <td><?php echo e($row['patID']); ?></td>
            <td><strong><?php echo e($row['patFName'] . ' ' . $row['patLName']); ?></strong></td>
            <td><?php echo e($row['patBDate']); ?></td>
            <td><?php echo e($row['patTelNo']); ?></td>
            <td>
              <a class="btn btn-sm btn-warning" href="edit.php?id=<?php echo $row['patID']; ?>">Edit</a>
              <a class="btn btn-sm btn-danger ms-1" href="delete.php?id=<?php echo $row['patID']; ?>" onclick="return confirm('Delete patient?');">Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="5" class="text-center text-muted py-3">No patients found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  </div>
</div>
<script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
