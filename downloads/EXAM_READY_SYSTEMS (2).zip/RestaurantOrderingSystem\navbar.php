<?php
// Global navigation bar
$cur = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= $baseUrl ?>index.php">Restaurant Ordering &amp; POS System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (strpos($cur, '/index.php') !== false && strpos($cur, '/menu_items') === false && strpos($cur, '/customers') === false && strpos($cur, '/orders') === false && strpos($cur, '/monitoring') === false) ? 'active' : '' ?>" href="<?= $baseUrl ?>index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/menu_items/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>menu_items/index.php">Menu Item</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/customers/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>customers/index.php">Customer / Table</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/orders/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>orders/index.php">Order</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/monitoring/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>