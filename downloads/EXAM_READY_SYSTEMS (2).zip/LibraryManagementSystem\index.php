﻿<?php
require_once 'database.php';

$totalBooks = $conn->query("SELECT COUNT(*) FROM books")->fetch_row()[0];
$totalBorrowers = $conn->query("SELECT COUNT(*) FROM borrowers")->fetch_row()[0];
$totalLoans = $conn->query("SELECT COUNT(*) FROM borrowed_books")->fetch_row()[0];
$totalFines = $conn->query("SELECT IFNULL(SUM(fine), 0) FROM borrowed_books")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Library Management System - Dashboard</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="p-4 mb-4 bg-white rounded-3 border">
            <h1 class="display-6 fw-bold">Campus Library Management System</h1>
            <p class="lead text-muted mb-0">Book Circulation, Borrowers & Fine Management</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Cataloged Books</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalBooks; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Registered Borrowers</span>
                    <h3 class="mb-0 text-success"><?php echo $totalBorrowers; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Circulation Transactions</span>
                    <h3 class="mb-0 text-dark"><?php echo $totalLoans; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Total Overdue Fines</span>
                    <h3 class="mb-0 text-danger">₱<?php echo number_format($totalFines, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Books Inventory</h5>
                    <p class="text-muted small">Catalog textbooks, reference materials, book authors, and available shelf copies.</p>
                    <a href="<?php echo $baseUrl; ?>books/index.php" class="btn btn-outline-primary mt-auto">Open Books &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Student & Faculty Directory</h5>
                    <p class="text-muted small">Maintain verified library patron cards, degree programs, and contact directories.</p>
                    <a href="<?php echo $baseUrl; ?>borrowers/index.php" class="btn btn-outline-success mt-auto">Open Borrowers &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Loan Circulation & Monitoring</h5>
                    <p class="text-muted small">Issue book loans, record returns, compute overdue penalties, and filter borrow records.</p>
                    <a href="<?php echo $baseUrl; ?>monitoring/index.php" class="btn btn-outline-dark mt-auto">Open Monitoring &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>