<?php
require '../database.php';
require '../helpers.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$query = "SELECT e.*, s.fname, s.lname, s.course, sub.subjectCode, sub.subjectName FROM enrollment e JOIN students s ON e.studentID = s.studentID JOIN subjects sub ON e.subjectID = sub.subjectID";
if ($search !== '') {
    $s = $mysqli->real_escape_string($search);
    $query .= " WHERE s.fname LIKE '%$s%' OR s.lname LIKE '%$s%' OR s.course LIKE '%$s%' OR sub.subjectCode LIKE '%$s%' OR sub.subjectName LIKE '%$s%'";
}
$query .= " ORDER BY e.enrollDate DESC";
$result = $mysqli->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Enrollment</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
  <?php include '../navbar.php'; ?>
  <main class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
      <div>
        <h1 class="h3 mb-1">Enrollment</h1>
        <p class="text-muted mb-0">Enroll students, record payments, and view balances.</p>
      </div>
      <a class="btn btn-primary" href="add.php">Enroll Student</a>
    </div>

    <?php if ($message = flash()) : ?>
      <div class="alert alert-success" role="alert">
        <?= e($message) ?>
      </div>
    <?php endif; ?>

    <div class="card mb-4">
      <div class="card-body">
        <form class="row g-3 align-items-end" action="index.php" method="get">
          <div class="col-md-8">
            <label for="search" class="form-label">Search</label>
            <input id="search" name="search" value="<?= e($search) ?>" placeholder="Student, course, subject" class="form-control">
          </div>
          <div class="col-md-4 d-grid">
            <button class="btn btn-outline-primary" type="submit">Search</button>
          </div>
        </form>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-striped table-bordered align-middle mb-0">
        <thead class="table-light">
          <tr><th>ID</th><th>Student</th><th>Course</th><th>Subject</th><th>Enroll Date</th><th>Amount Paid</th><th>Balance</th><th>Payment Mode</th><th class="text-end">Actions</th></tr>
        </thead>
        <tbody>
          <?php while ($row = $result->fetch_assoc()) : ?>
          <tr>
            <td><?= e($row['enrollID']) ?></td>
            <td><?= e($row['fname'] . ' ' . $row['lname']) ?></td>
            <td><?= e($row['course']) ?></td>
            <td><?= e($row['subjectCode'] . ' - ' . $row['subjectName']) ?></td>
            <td><?= e($row['enrollDate']) ?></td>
            <td><?= e(number_format($row['amountPaid'], 2)) ?></td>
            <td><?= e(number_format($row['balance'], 2)) ?></td>
            <td><?= e($row['paymentMode']) ?></td>
            <td class="text-end">
              <a class="btn btn-sm btn-outline-secondary me-2" href="edit.php?id=<?= e($row['enrollID']) ?>">Edit</a>
              <a class="btn btn-sm btn-outline-danger" href="delete.php?id=<?= e($row['enrollID']) ?>" onclick="return confirm('Delete this enrollment?');">Delete</a>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </main>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
