<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM orders WHERE orderID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$e1List = $conn->query("SELECT productID, productName FROM products ORDER BY productName ASC");
$e2List = $conn->query("SELECT customerID, customerName FROM customers ORDER BY customerName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productID = (int)($_POST['productID'] ?? 0);
    $customerID = (int)($_POST['customerID'] ?? 0);
    $orderDate = is_string($_POST['orderDate'] ?? null) ? trim($_POST['orderDate']) : '';
    $quantity = is_string($_POST['quantity'] ?? null) ? trim($_POST['quantity']) : '';
    $totalAmount = is_string($_POST['totalAmount'] ?? null) ? trim($_POST['totalAmount']) : '';
    $paymentStatus = is_string($_POST['paymentStatus'] ?? null) ? trim($_POST['paymentStatus']) : '';
    $deliveryStatus = is_string($_POST['deliveryStatus'] ?? null) ? trim($_POST['deliveryStatus']) : '';

    if ($productID <= 0 || $customerID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "UPDATE orders SET `productID` = '" . $conn->real_escape_string($productID) . "', `customerID` = '" . $conn->real_escape_string($customerID) . "', `orderDate` = '" . $conn->real_escape_string($orderDate) . "', `quantity` = '" . $conn->real_escape_string($quantity) . "', `totalAmount` = '" . $conn->real_escape_string($totalAmount) . "', `paymentStatus` = '" . $conn->real_escape_string($paymentStatus) . "', `deliveryStatus` = '" . $conn->real_escape_string($deliveryStatus) . "' WHERE orderID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order #<?= $id ?> - Sales &amp; Order Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Order #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Product <span class="text-danger">*</span></label>
            <select name="productID" class="form-select" required>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['productID'] ?>" <?= ($row['productID'] == $e1Row['productID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e1Row['productName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Customer <span class="text-danger">*</span></label>
            <select name="customerID" class="form-select" required>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['customerID'] ?>" <?= ($row['customerID'] == $e2Row['customerID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e2Row['customerName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Order Date</label>
                <input type="date" name="orderDate" class="form-control" value="<?= htmlspecialchars($row['orderDate'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Quantity</label>
                <input type="number"  name="quantity" class="form-control" value="<?= htmlspecialchars($row['quantity'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Total Amount (₱)</label>
                <input type="number" step="0.01" name="totalAmount" class="form-control" value="<?= htmlspecialchars($row['totalAmount'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Payment Status</label>
                <select name="paymentStatus" class="form-select" required>
                    <option value="Paid" <?= ($row['paymentStatus'] ?? '') === 'Paid' ? 'selected' : '' ?>>Paid</option>
<option value="Pending" <?= ($row['paymentStatus'] ?? '') === 'Pending' ? 'selected' : '' ?>>Pending</option>
<option value="Cancelled" <?= ($row['paymentStatus'] ?? '') === 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Delivery Status</label>
                <select name="deliveryStatus" class="form-select" required>
                    <option value="Processing" <?= ($row['deliveryStatus'] ?? '') === 'Processing' ? 'selected' : '' ?>>Processing</option>
<option value="Shipped" <?= ($row['deliveryStatus'] ?? '') === 'Shipped' ? 'selected' : '' ?>>Shipped</option>
<option value="Delivered" <?= ($row['deliveryStatus'] ?? '') === 'Delivered' ? 'selected' : '' ?>>Delivered</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>