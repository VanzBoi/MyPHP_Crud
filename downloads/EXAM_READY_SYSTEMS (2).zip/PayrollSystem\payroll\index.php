<?php
require_once '../database.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
if ($search !== '') {
    $stmt = $conn->prepare("SELECT p.*, e.empFName, e.empLName, pos.positionName FROM payroll p JOIN employees e ON p.empID = e.empID JOIN positions pos ON e.positionID = pos.positionID WHERE e.empFName LIKE ? OR e.empLName LIKE ? OR pos.positionName LIKE ? ORDER BY p.payrollID DESC");
    $param = "%$search%";
    $stmt->bind_param("sss", $param, $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT p.*, e.empFName, e.empLName, pos.positionName FROM payroll p JOIN employees e ON p.empID = e.empID JOIN positions pos ON e.positionID = pos.positionID ORDER BY p.payrollID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payroll Records</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Payroll Disbursement Slips</h3>
            <a href="add.php" class="btn btn-primary">+ Process New Payroll</a>
        </div>
        <div class="card p-3 mb-3">
            <form method="GET" class="row g-2">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="Search by employee name or job title..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Search</button>
                    <?php if ($search !== ''): ?>
                        <a href="index.php" class="btn btn-outline-secondary">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <div class="card p-0">
            <table class="table table-bordered table-striped mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Employee</th>
                        <th>Position</th>
                        <th>Pay Date</th>
                        <th>Basic Salary (₱)</th>
                        <th>Allowance (₱)</th>
                        <th>Deductions (₱)</th>
                        <th>Net Pay (₱)</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['payrollID']; ?></td>
                            <td><strong><?php echo htmlspecialchars($row['empFName'] . ' ' . $row['empLName']); ?></strong></td>
                            <td><span class="badge bg-secondary"><?php echo htmlspecialchars($row['positionName']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['payDate']); ?></td>
                            <td>₱<?php echo number_format($row['basicSalary'], 2); ?></td>
                            <td>₱<?php echo number_format($row['allowance'], 2); ?></td>
                            <td class="text-danger">-₱<?php echo number_format($row['deduction'], 2); ?></td>
                            <td class="text-success fw-bold">₱<?php echo number_format($row['netPay'], 2); ?></td>
                            <td class="text-end">
                                <a href="edit.php?id=<?php echo $row['payrollID']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete.php?id=<?php echo $row['payrollID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete payroll slip?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="9" class="text-center py-4 text-muted">No payroll entries recorded.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>