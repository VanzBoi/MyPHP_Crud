<?php
require_once __DIR__ . '/../database.php';

// Filter parameter
$filterVal = is_string($_GET['filter'] ?? null) ? trim($_GET['filter']) : '';

$where = "1=1";
if ($filterVal !== '') {
    $esc = $conn->real_escape_string($filterVal);
    $where .= " AND t.equipmentID = '$esc'";
}

// Count total records
$totalCount = $conn->query("SELECT COUNT(*) AS total FROM borrow_logs t WHERE $where")->fetch_assoc()['total'] ?? 0;

// Get total sum
$totalAmount = $conn->query("SELECT IFNULL(SUM(penaltyFee), 0) AS total FROM borrow_logs t WHERE $where")->fetch_assoc()['total'] ?? 0;

// Calculate average or percentage
$avgValue = ($totalCount > 0) ? ($totalAmount / $totalCount) : 0;

// Dropdown options
$filterOptions = $conn->query("SELECT equipmentID, equipmentName FROM equipment ORDER BY equipmentName ASC");

// Query transactions
$sql = "SELECT t.*, e1.equipmentName AS e1_title, e2.borrowerName AS e2_title 
        FROM borrow_logs t
        JOIN equipment e1 ON t.equipmentID = e1.equipmentID
        JOIN borrowers e2 ON t.borrowerID = e2.borrowerID
        WHERE $where
        ORDER BY t.logID DESC";
$records = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitoring & Reports - Equipment Borrowing &amp; Tracking System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="fw-bold mb-0">System Monitoring & Analytical Summary</h3>
            </div>
            <a href="<?= $baseUrl ?>borrow_logs/add.php" class="btn btn-warning btn-sm fw-semibold">+ Record New Borrow Log</a>
        </div>

        <!-- Filter Card -->
        <div class="card mb-4">
            <div class="card-body p-3">
                <form method="GET" class="row g-2 align-items-center">
                    <div class="col-auto">
                        <label class="col-form-label fw-bold">Filter by Equipment:</label>
                    </div>
                    <div class="col-md-6">
                        <select name="filter" class="form-select form-select-sm" onchange="this.form.submit()">
                            <option value="">-- All Equipment (Show All) --</option>
                            <?php if ($filterOptions): ?>
                                <?php while ($opt = $filterOptions->fetch_assoc()): ?>
                                    <option value="<?= $opt['equipmentID'] ?>" <?= ($filterVal == $opt['equipmentID']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($opt['equipmentName']) ?>
                                    </option>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-auto">
                        <?php if ($filterVal !== ''): ?>
                            <a href="index.php" class="btn btn-outline-secondary btn-sm">Reset Filter</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="card p-3 bg-white ">
                    <div class="text-muted small text-uppercase fw-bold">Total Transactions</div>
                    <div class="fs-2 fw-bold text-dark my-1"><?= number_format($totalCount) ?></div>
                    <small class="text-muted">Total records matching active filter</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 bg-white ">
                    <div class="text-muted small text-uppercase fw-bold">Total Amount (₱)</div>
                    <div class="fs-2 fw-bold text-success my-1">₱<?= number_format($totalAmount, 2) ?></div>
                    <small class="text-muted">Calculated sum of transaction amount</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 bg-white ">
                    <div class="text-muted small text-uppercase fw-bold">Average Penalty Fee</div>
                    <div class="fs-2 fw-bold text-info my-1">₱<?= number_format($avgValue, 2) ?></div>
                    <small class="text-muted">Calculated average per transaction</small>
                </div>
            </div>
        </div>

        <!-- Detail Table -->
        <div class="card">
            <div class="card-header fw-bold bg-white py-3 d-flex justify-content-between align-items-center">
                <h6 class="mb-0 fw-bold">Filtered Transaction Breakdown</h6>
                <span class="badge bg-secondary"><?= $totalCount ?> items</span>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-bordered align-middle mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Equipment</th>
                            <th>Borrower</th>
                            <th>Amount / Fee</th>
                            <th>Status / Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records && $records->num_rows > 0): ?>
                            <?php while ($r = $records->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['logID'] ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($r['e1_title'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($r['e2_title'] ?? '') ?></td>
                                    <td class="text-success fw-bold">₱<?= number_format($r['penaltyFee'] ?? 0, 2) ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark border">Active Record</span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">No records match the selected filter.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer class="text-center">
        <div class="container">
            <p class="mb-0">&copy; <?= date('Y') ?> Equipment Borrowing &amp; Tracking System</p>
        </div>
    </footer>
    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>