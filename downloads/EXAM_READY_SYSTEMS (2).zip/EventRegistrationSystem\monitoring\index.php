﻿<?php
require_once '../database.php';

$evFilter = intval($_GET['evCode'] ?? 0);
$where = ($evFilter > 0) ? "WHERE e.evCode = $evFilter" : "";

$events = $conn->query("SELECT * FROM events ORDER BY evName ASC");

$totalEvents = $conn->query("SELECT COUNT(*) FROM events e $where")->fetch_row()[0];
$totalParticipants = $conn->query("SELECT COUNT(DISTINCT r.partID) FROM registrations r JOIN events e ON r.evCode = e.evCode $where")->fetch_row()[0];
$totalRegistrations = $conn->query("SELECT COUNT(*) FROM registrations r JOIN events e ON r.evCode = e.evCode $where")->fetch_row()[0];
$totalRevenue = $conn->query("SELECT IFNULL(SUM(r.feePaid), 0) FROM registrations r JOIN events e ON r.evCode = e.evCode $where")->fetch_row()[0];

$query = "SELECT e.evCode, e.evName, e.evDate, e.evVenue, e.evRFee, COUNT(r.regID) AS totalAttendees, IFNULL(SUM(r.feePaid), 0) AS totalRevenue FROM events e LEFT JOIN registrations r ON e.evCode = r.evCode " . (($evFilter > 0) ? "WHERE e.evCode = $evFilter" : "") . " GROUP BY e.evCode ORDER BY totalRevenue DESC";
$report = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Registration Monitoring</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <h3 class="mb-3">Event Operations & Attendance Monitoring</h3>

        <div class="card p-3 mb-4">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-md-9">
                    <select name="evCode" class="form-select">
                        <option value="0">-- All Campus Events (Overall Summary) --</option>
                        <?php while($e = $events->fetch_assoc()): ?>
                            <option value="<?php echo $e['evCode']; ?>" <?php echo ($e['evCode'] == $evFilter) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($e['evName'] . ' (' . $e['evDate'] . ')'); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Filter Event</button>
                    <?php if ($evFilter > 0): ?>
                        <a href="index.php" class="btn btn-outline-secondary">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Covered Events</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalEvents; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Unique Attendees</span>
                    <h3 class="mb-0 text-success"><?php echo $totalParticipants; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Total Registrations</span>
                    <h3 class="mb-0 text-dark"><?php echo $totalRegistrations; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Registration Collections</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalRevenue, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="card p-0">
            <div class="card-header fw-bold">Event Attendance & Revenue Breakdown</div>
            <table class="table table-bordered table-striped mb-0">
                <thead>
                    <tr>
                        <th>Event Title</th>
                        <th>Date & Venue</th>
                        <th>Standard Fee (₱)</th>
                        <th>Total Attendees</th>
                        <th>Total Revenue Collected (₱)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($report && $report->num_rows > 0): ?>
                        <?php while($r = $report->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($r['evName']); ?></strong></td>
                            <td><?php echo htmlspecialchars($r['evDate'] . ' @ ' . $r['evVenue']); ?></td>
                            <td>₱<?php echo number_format($r['evRFee'], 2); ?></td>
                            <td><?php echo $r['totalAttendees']; ?></td>
                            <td class="text-success fw-bold">₱<?php echo number_format($r['totalRevenue'], 2); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center py-4 text-muted">No registration records found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>