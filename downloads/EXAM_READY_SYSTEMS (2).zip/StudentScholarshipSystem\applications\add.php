<?php
require_once '../database.php';
require_once '../helpers.php';

$students = $mysqli->query('SELECT studID, fName, lName FROM students ORDER BY fName, lName')->fetch_all(MYSQLI_ASSOC);
$scholarships = $mysqli->query('SELECT scholID, scholName, discountRate FROM scholarships ORDER BY scholName')->fetch_all(MYSQLI_ASSOC);

$studID = '';
$scholID = '';
$tuitionFee = '';
$appDate = date('Y-m-d');
$status = 'Pending';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studID = (int)($_POST['studID'] ?? 0);
    $scholID = (int)($_POST['scholID'] ?? 0);
    $tuitionFee = is_string($_POST['tuitionFee'] ?? null) ? trim($_POST['tuitionFee']) : '';
    $appDate = is_string($_POST['appDate'] ?? null) ? trim($_POST['appDate']) : date('Y-m-d');
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : 'Pending';

    if ($studID <= 0 || $scholID <= 0 || $tuitionFee === '' || $appDate === '') {
        set_flash('All fields are required.', 'error');
    } elseif (!is_numeric($tuitionFee) || (float)$tuitionFee < 0) {
        set_flash('Tuition fee must be a positive number.', 'error');
    } else {
        $studentId = (int)$studID;
        $scholarshipId = (int)$scholID;
        $tuition = (float)$tuitionFee;

        $resSch = $mysqli->query("SELECT discountRate FROM scholarships WHERE scholID = $scholarshipId");
        $sch = $resSch ? $resSch->fetch_assoc() : null;
        if (!$sch) {
            set_flash('Selected scholarship not found.', 'error');
        } else {
            $discountRate = (float)($sch['discountRate'] ?? 0);
            $discountAmount = $tuition * $discountRate;
            $amountPaid = $tuition - $discountAmount;

            $sql = "INSERT INTO applications (`studID`, `scholID`, `tuitionFee`, `discountAmount`, `amountPaid`, `appDate`, `status`) VALUES ('" . $mysqli->real_escape_string($studentId) . "', '" . $mysqli->real_escape_string($scholarshipId) . "', '" . $mysqli->real_escape_string($tuition) . "', '" . $mysqli->real_escape_string($discountAmount) . "', '" . $mysqli->real_escape_string($amountPaid) . "', '" . $mysqli->real_escape_string($appDate) . "', '" . $mysqli->real_escape_string($status) . "')";
            if ($mysqli->query($sql)) {
                set_flash('Application added successfully.');
                redirect('index.php');
            } else {
                set_flash('Failed to record transaction: ' . $mysqli->error, 'error');
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Application</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<div class="container mt-4">
    <?php include '../navbar.php'; ?>
    <div class="mb-3">
        <h2>Add Application</h2>
    </div>
    <?php flash(); ?>
    <form method="post">
        <div class="mb-3">
            <label class="form-label">Student</label>
            <select name="studID" class="form-select">
                <option value="">Select student</option>
                <?php foreach ($students as $student): ?>
                    <option value="<?= escape($student['studID']) ?>" <?= $studID == $student['studID'] ? 'selected' : '' ?>><?= escape($student['fName'] . ' ' . $student['lName']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Scholarship</label>
            <select name="scholID" class="form-select">
                <option value="">Select scholarship</option>
                <?php foreach ($scholarships as $scholarship): ?>
                    <option value="<?= escape($scholarship['scholID']) ?>" <?= $scholID == $scholarship['scholID'] ? 'selected' : '' ?>><?= escape($scholarship['scholName']) ?> (<?= number_format($scholarship['discountRate'] * 100, 0) ?>%)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Tuition Fee</label>
            <input type="text" name="tuitionFee" class="form-control" value="<?= escape($tuitionFee) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Application Date</label>
            <input type="date" name="appDate" class="form-control" value="<?= escape($appDate) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <?php foreach (['Pending', 'Approved', 'Rejected'] as $option): ?>
                    <option value="<?= $option ?>" <?= $status === $option ? 'selected' : '' ?>><?= $option ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button class="btn btn-warning" type="submit">Save</button>
        <a href="index.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
