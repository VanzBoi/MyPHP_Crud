<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM borrowers WHERE borrowerID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$b = $res->fetch_assoc();
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = is_string($_POST['fname'] ?? null) ? trim($_POST['fname']) : '';
    $lname = is_string($_POST['lname'] ?? null) ? trim($_POST['lname']) : '';
    $course = is_string($_POST['course'] ?? null) ? trim($_POST['course']) : '';
    $contact = is_string($_POST['contactNo'] ?? null) ? trim($_POST['contactNo']) : '';

    if ($fname === '' || $lname === '') {
        $err = 'Please enter borrower name.';
    } else {
        $stmt = $conn->prepare("UPDATE borrowers SET fname = ?, lname = ?, course = ?, contactNo = ? WHERE borrowerID = ?");
        $stmt->bind_param("ssssi", $fname, $lname, $course, $contact, $id);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Update failed: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Borrower</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Edit Borrower Profile</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">First Name</label>
                        <input type="text" name="fname" class="form-control" required value="<?php echo htmlspecialchars($b['fname']); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="lname" class="form-control" required value="<?php echo htmlspecialchars($b['lname']); ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Course / Academic Program</label>
                    <input type="text" name="course" class="form-control" required value="<?php echo htmlspecialchars($b['course']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="contactNo" class="form-control" required value="<?php echo htmlspecialchars($b['contactNo']); ?>">
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Borrower</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>