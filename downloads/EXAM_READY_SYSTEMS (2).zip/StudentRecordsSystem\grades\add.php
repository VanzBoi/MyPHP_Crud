<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT courseID, courseTitle FROM courses ORDER BY courseTitle ASC");
$e2List = $conn->query("SELECT studentID, fullName FROM students ORDER BY fullName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $courseID = (int)($_POST['courseID'] ?? 0);
    $studentID = (int)($_POST['studentID'] ?? 0);
    $semester = is_string($_POST['semester'] ?? null) ? trim($_POST['semester']) : '';
    $midterm = is_string($_POST['midterm'] ?? null) ? trim($_POST['midterm']) : '';
    $finals = is_string($_POST['finals'] ?? null) ? trim($_POST['finals']) : '';
    $finalGrade = is_string($_POST['finalGrade'] ?? null) ? trim($_POST['finalGrade']) : '';
    $remarks = is_string($_POST['remarks'] ?? null) ? trim($_POST['remarks']) : '';

    if ($courseID <= 0 || $studentID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "INSERT INTO grades (`courseID`, `studentID`, `semester`, `midterm`, `finals`, `finalGrade`, `remarks`) VALUES ('" . $conn->real_escape_string($courseID) . "', '" . $conn->real_escape_string($studentID) . "', '" . $conn->real_escape_string($semester) . "', '" . $conn->real_escape_string($midterm) . "', '" . $conn->real_escape_string($finals) . "', '" . $conn->real_escape_string($finalGrade) . "', '" . $conn->real_escape_string($remarks) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Grade Record - Student Academic Records &amp; Grading System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Record New Grade Record</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Course / Subject <span class="text-danger">*</span></label>
            <select name="courseID" class="form-select" required>
                <option value="">-- Select Course / Subject --</option>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['courseID'] ?>"><?= htmlspecialchars($e1Row['courseTitle']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Student <span class="text-danger">*</span></label>
            <select name="studentID" class="form-select" required>
                <option value="">-- Select Student --</option>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['studentID'] ?>"><?= htmlspecialchars($e2Row['fullName']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Semester / Term</label>
                <input type="text" name="semester" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Midterm Grade</label>
                <input type="number" step="0.01" name="midterm" class="form-control" value="1.50" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Finals Grade</label>
                <input type="number" step="0.01" name="finals" class="form-control" value="1.50" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Final Grade (GPA)</label>
                <input type="number" step="0.01" name="finalGrade" class="form-control" value="1.50" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Remarks</label>
                <select name="remarks" class="form-select" required>
                    <option value="Passed">Passed</option>
<option value="Failed">Failed</option>
<option value="Incomplete">Incomplete</option>
<option value="Dropped">Dropped</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Submit Grade Record</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>