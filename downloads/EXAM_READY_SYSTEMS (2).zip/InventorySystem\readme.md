﻿# Warehouse Inventory Management System

A simple PHP and MySQL web application for managing suppliers, products, and stock movements.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\InventorySystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/InventorySystem/
4. The database `inventory_system_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Suppliers**: Add, view, edit, and delete suppliers records.
- **Products**: Add, view, edit, and delete products records.
- **Stock Movements**: Manage stock movements transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
