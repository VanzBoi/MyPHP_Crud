<?php
// Turn off strict reporting for standard procedural error checking
mysqli_report(MYSQLI_REPORT_OFF);

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'user_roles_db';

$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

$mysqli = $conn;
$database = $DB_NAME;
$db = $DB_NAME;
$baseUrl = '/' . basename(__DIR__) . '/';

return $conn;
