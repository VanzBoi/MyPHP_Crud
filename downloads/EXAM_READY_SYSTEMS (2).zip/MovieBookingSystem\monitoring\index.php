﻿<?php
require_once '../database.php';

$moviesList = $conn->query("SELECT * FROM movies ORDER BY movieTitle ASC");
$filterMovieID = intval($_GET['movieID'] ?? 0);

if ($filterMovieID > 0) {
    $stmt = $conn->prepare("SELECT b.*, m.movieTitle, m.cinemaHall, m.ticketPrice, c.custFName, c.custLName, c.customerType 
                            FROM bookings b
                            JOIN movies m ON b.movieID = m.movieID
                            JOIN customers c ON b.customerID = c.customerID
                            WHERE b.movieID = ?
                            ORDER BY b.bookingDate DESC");
    $stmt->bind_param("i", $filterMovieID);
    $stmt->execute();
    $records = $stmt->get_result();

    $aggStmt = $conn->prepare("SELECT COUNT(*) AS total_bookings, IFNULL(SUM(numTickets), 0) AS total_tickets, IFNULL(SUM(totalAmountPaid), 0) AS total_revenue 
                               FROM bookings 
                               WHERE movieID = ?");
    $aggStmt->bind_param("i", $filterMovieID);
    $aggStmt->execute();
    $agg = $aggStmt->get_result()->fetch_assoc();

    $movieInfo = $conn->query("SELECT * FROM movies WHERE movieID = $filterMovieID")->fetch_assoc();
    $basePrice = floatval($movieInfo['ticketPrice']);
    $filterLabel = $movieInfo['movieTitle'] . " (Ticket: ₱" . number_format($basePrice, 2) . ")";
} else {
    $records = $conn->query("SELECT b.*, m.movieTitle, m.cinemaHall, m.ticketPrice, c.custFName, c.custLName, c.customerType 
                             FROM bookings b
                             JOIN movies m ON b.movieID = m.movieID
                             JOIN customers c ON b.customerID = c.customerID
                             ORDER BY b.bookingDate DESC");
    $agg = $conn->query("SELECT COUNT(*) AS total_bookings, IFNULL(SUM(numTickets), 0) AS total_tickets, IFNULL(SUM(totalAmountPaid), 0) AS total_revenue FROM bookings")->fetch_assoc();
    $basePrice = 0;
    $filterLabel = "All Movies";
}

$countBookings = $agg['total_bookings'] ?? 0;
$totalTickets = $agg['total_tickets'] ?? 0;
$sumRevenue = $agg['total_revenue'] ?? 0.00;

// Calculate discount amounts:
// If single movie filtered: Total Discounts = (Total Tickets * Base Ticket Price) - Total Revenue
// If all movies: compute sum of original prices - sumRevenue
if ($filterMovieID > 0) {
    $totalDiscount = ($totalTickets * $basePrice) - $sumRevenue;
} else {
    $sumGross = $conn->query("SELECT IFNULL(SUM(b.numTickets * m.ticketPrice), 0) FROM bookings b JOIN movies m ON b.movieID = m.movieID")->fetch_row()[0];
    $totalDiscount = $sumGross - $sumRevenue;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cinema Box Office Monitoring</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="mb-0">Cinema Box Office Monitoring</h3>
            </div>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">Reset Filter</a>
        </div>

        <!-- Filter Card -->
        <div class="card p-3 mb-4">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-auto">
                    <label class="form-label mb-0 fw-semibold">Filter by Movie Title:</label>
                </div>
                <div class="col-md-5">
                    <select name="movieID" class="form-select" onchange="this.form.submit()">
                        <option value="">-- All Movies --</option>
                        <?php while($m = $moviesList->fetch_assoc()): ?>
                        <option value="<?php echo $m['movieID']; ?>" <?php echo $filterMovieID === intval($m['movieID']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($m['movieTitle'] . ' (' . $m['cinemaHall'] . ')'); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
            </form>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="card p-3 mb-3">
                    <span class="text-muted small fw-semibold">Total Bookings & Tickets</span>
                    <h2 class="text-primary mb-0"><?php echo $countBookings; ?> <small class="text-muted fs-6">Orders (<?php echo $totalTickets; ?> Tickets)</small></h2>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 mb-3">
                    <span class="text-muted small fw-semibold">Total Ticket Sales</span>
                    <h2 class="text-success mb-0">₱<?php echo number_format($sumRevenue, 2); ?></h2>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 mb-3">
                    <span class="text-muted small fw-semibold">Total Discounts Granted</span>
                    <h2 class="text-warning mb-0">₱<?php echo number_format(max(0, $totalDiscount), 2); ?></h2>
                </div>
            </div>
        </div>

        <!-- Table displaying filtered records -->
        <div class="card mb-3">
            <div class="card-header fw-bold bg-white py-3">
                <h5 class="mb-0">Sales Records for: <span class="badge bg-primary"><?php echo htmlspecialchars($filterLabel); ?></span></h5>
            </div>
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>Movie Title</th>
                        <th>Cinema</th>
                        <th>Customer Full Name</th>
                        <th>Classification</th>
                        <th>Date</th>
                        <th>Tickets</th>
                        <th>Amount Paid</th>
                        <th>Payment Mode</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($records && $records->num_rows > 0): ?>
                        <?php while($row = $records->fetch_assoc()): ?>
                        <tr>
                            <td><strong> <?php echo htmlspecialchars($row['movieTitle']); ?></strong></td>
                            <td><?php echo htmlspecialchars($row['cinemaHall']); ?></td>
                            <td><?php echo htmlspecialchars($row['custFName'] . ' ' . $row['custLName']); ?></td>
                            <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($row['customerType']); ?></span></td>
                            <td><?php echo $row['bookingDate']; ?></td>
                            <td><?php echo $row['numTickets']; ?> ticket(s)</td>
                            <td><strong class="text-success">₱<?php echo number_format($row['totalAmountPaid'], 2); ?></strong></td>
                            <td><span class="badge bg-info text-dark"><?php echo htmlspecialchars($row['paymentMode']); ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No booking records found for this movie.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>