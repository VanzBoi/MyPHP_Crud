CREATE DATABASE IF NOT EXISTS user_roles_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE user_roles_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS roles (
  roleID INT AUTO_INCREMENT PRIMARY KEY,
  roleName VARCHAR(100) NOT NULL,
  department VARCHAR(50) NOT NULL,
  accessLevel VARCHAR(50) NOT NULL,
  stipendAllowance DECIMAL(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  userID INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  fullName VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS assignments (
  assignmentID INT AUTO_INCREMENT PRIMARY KEY,
  roleID INT NOT NULL,
  userID INT NOT NULL,
  assignedDate DATE NOT NULL,
  allowance DECIMAL(10,2) NOT NULL,
  status VARCHAR(50) DEFAULT 'Active',
  FOREIGN KEY (roleID) REFERENCES roles(roleID) ON DELETE CASCADE,
  FOREIGN KEY (userID) REFERENCES users(userID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO roles (roleName, department, accessLevel, stipendAllowance) VALUES
('System Administrator', 'IT Services', 'Super Admin (Level 3)', 5000.00),
('Department Chair / Dean', 'Academic Affairs', 'Manager (Level 2)', 3500.00),
('Faculty Instructor', 'College Faculty', 'Staff (Level 1)', 2000.00),
('Student Council Officer', 'Student Affairs', 'Viewer (Level 1)', 1000.00);

INSERT INTO users (username, fullName, email, contactNumber) VALUES
('jcedrick', 'John Cedrick Libradilla', 'jcedrick@uc.edu.ph', '09171234567'),
('mdeleon', 'Maria De Leon', 'mdeleon@uc.edu.ph', '09182345678'),
('rperez', 'Robert Perez', 'rperez@uc.edu.ph', '09223456789');

INSERT INTO assignments (roleID, userID, assignedDate, allowance, status) VALUES
(1, 1, '2026-10-25', 5000.00, 'Active'),
(2, 2, '2026-10-26', 3500.00, 'Active'),
(3, 3, '2026-10-27', 2000.00, 'Active');

SET FOREIGN_KEY_CHECKS=1;