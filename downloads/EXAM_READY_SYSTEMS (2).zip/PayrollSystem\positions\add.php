<?php
require_once '../database.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = is_string($_POST['positionName'] ?? null) ? trim($_POST['positionName']) : '';
    $basic = floatval($_POST['basicSalary'] ?? 0);
    $allowance = floatval($_POST['allowance'] ?? 0);

    if ($name === '' || $basic <= 0) {
        $err = 'Please fill out all required fields.';
    } else {
        $stmt = $conn->prepare("INSERT INTO positions (positionName, basicSalary, allowance) VALUES (?, ?, ?)");
        $stmt->bind_param("sdd", $name, $basic, $allowance);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Failed to save position: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Position</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Add New Position</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Position Title</label>
                    <input type="text" name="positionName" class="form-control" required placeholder="e.g. Senior Developer">
                </div>
                <div class="mb-3">
                    <label class="form-label">Monthly Basic Salary (₱)</label>
                    <input type="number" step="0.01" name="basicSalary" class="form-control" required placeholder="e.g. 35000.00">
                </div>
                <div class="mb-3">
                    <label class="form-label">Standard Allowance (₱)</label>
                    <input type="number" step="0.01" name="allowance" class="form-control" value="0.00">
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Save Position</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>