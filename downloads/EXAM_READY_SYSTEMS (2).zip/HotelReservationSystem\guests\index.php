<?php include '../database.php'; ?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Guests Management</title>
      <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
  </head>
  <body>
    <?php include '../navbar.php'; ?>
    <div class="container">
      <div class="mb-3">
        <h1>Guests Management</h1>
        <small class="text-muted">Register and manage hotel guests</small>
      </div>

      <div class="card mb-4"><div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <a class="btn btn-primary" href="add.php">+ Add New Guest</a>
          <?php
          $search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
          $query = "SELECT * FROM guests";
          if ($search) {
              $safeSearch = mysqli_real_escape_string($conn, $search);
              $query .= " WHERE fName LIKE '%$safeSearch%' OR lName LIKE '%$safeSearch%' OR address LIKE '%$safeSearch%'";
          }
          $query .= " ORDER BY guestID DESC";
          $res = mysqli_query($conn, $query);
          ?>
          <form method="get" class="d-flex gap-2" style="max-width: 320px;">
            <input type="text" name="search" class="form-control" placeholder="Search guests..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn btn-primary">Search</button>
            <?php if ($search): ?>
              <a href="index.php" class="btn btn-outline-secondary">Clear</a>
            <?php endif; ?>
          </form>
        </div>

        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Full Name</th>
              <th>Address</th>
              <th>Contact No</th>
              <th style="width: 140px;">Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php if ($res && mysqli_num_rows($res) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($res)): ?>
              <tr>
                <td><?= $row['guestID'] ?></td>
                <td><strong><?= htmlspecialchars($row['fName'].' '.$row['lName']) ?></strong></td>
                <td><?= htmlspecialchars($row['address']) ?></td>
                <td><?= htmlspecialchars($row['contactNo']) ?></td>
                <td>
                  <a class="btn btn-sm btn-warning" href="edit.php?id=<?= $row['guestID'] ?>">Edit</a>
                  <a class="btn btn-sm btn-danger ms-1" href="delete.php?id=<?= $row['guestID'] ?>" onclick="return confirm('Delete this guest record?')">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="5" class="text-center text-muted py-3">No guests found.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
      </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
  </body>
</html>
