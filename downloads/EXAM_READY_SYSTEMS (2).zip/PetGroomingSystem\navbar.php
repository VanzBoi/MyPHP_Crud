<?php
// Global navigation bar
$cur = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= $baseUrl ?>index.php">Pet Grooming Management System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (strpos($cur, '/index.php') !== false && strpos($cur, '/services') === false && strpos($cur, '/pets') === false && strpos($cur, '/bookings') === false && strpos($cur, '/monitoring') === false) ? 'active' : '' ?>" href="<?= $baseUrl ?>index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/services/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>services/index.php">Service</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/pets/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>pets/index.php">Pet</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/bookings/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>bookings/index.php">Booking</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/monitoring/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>