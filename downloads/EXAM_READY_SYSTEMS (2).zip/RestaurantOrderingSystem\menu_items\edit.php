<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM menu_items WHERE itemID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemName = is_string($_POST['itemName'] ?? null) ? trim($_POST['itemName']) : '';
$category = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
$price = is_string($_POST['price'] ?? null) ? trim($_POST['price']) : '';
$availability = is_string($_POST['availability'] ?? null) ? trim($_POST['availability']) : '';

    $sql = "UPDATE menu_items SET `itemName` = '" . $conn->real_escape_string($itemName) . "', `category` = '" . $conn->real_escape_string($category) . "', `price` = '" . $conn->real_escape_string($price) . "', `availability` = '" . $conn->real_escape_string($availability) . "' WHERE itemID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu Item #<?= $id ?> - Restaurant Ordering &amp; POS System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Menu Item #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Dish / Item Name</label>
                <input type="text" name="itemName" class="form-control" value="<?= htmlspecialchars($row['itemName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Category</label>
                <select name="category" class="form-select" required>
                    <option value="Main Dish" <?= ($row['category'] ?? '') === 'Main Dish' ? 'selected' : '' ?>>Main Dish</option>
<option value="Appetizer" <?= ($row['category'] ?? '') === 'Appetizer' ? 'selected' : '' ?>>Appetizer</option>
<option value="Soup" <?= ($row['category'] ?? '') === 'Soup' ? 'selected' : '' ?>>Soup</option>
<option value="Dessert" <?= ($row['category'] ?? '') === 'Dessert' ? 'selected' : '' ?>>Dessert</option>
<option value="Beverage" <?= ($row['category'] ?? '') === 'Beverage' ? 'selected' : '' ?>>Beverage</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Price (₱)</label>
                <input type="number" step="0.01" name="price" class="form-control" value="<?= htmlspecialchars($row['price'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Availability</label>
                <select name="availability" class="form-select" required>
                    <option value="Available" <?= ($row['availability'] ?? '') === 'Available' ? 'selected' : '' ?>>Available</option>
<option value="Out of Stock" <?= ($row['availability'] ?? '') === 'Out of Stock' ? 'selected' : '' ?>>Out of Stock</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>