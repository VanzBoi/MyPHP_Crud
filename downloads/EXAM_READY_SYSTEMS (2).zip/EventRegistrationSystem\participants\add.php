<?php
require_once '../database.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fName = is_string($_POST['partFName'] ?? null) ? trim($_POST['partFName']) : '';
    $lName = is_string($_POST['partLName'] ?? null) ? trim($_POST['partLName']) : '';
    $contact = is_string($_POST['contactNo'] ?? null) ? trim($_POST['contactNo']) : '';
    $email = is_string($_POST['email'] ?? null) ? trim($_POST['email']) : '';
    $org = is_string($_POST['organization'] ?? null) ? trim($_POST['organization']) : '';

    if ($fName === '' || $lName === '') {
        $err = 'First Name and Last Name are required.';
    } else {
        $stmt = $conn->prepare("INSERT INTO participants (partFName, partLName, contactNo, email, organization) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $fName, $lName, $contact, $email, $org);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Failed to register participant: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Participant</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Register New Participant</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">First Name</label>
                        <input type="text" name="partFName" class="form-control" required placeholder="e.g. Alice">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="partLName" class="form-control" required placeholder="e.g. Garcia">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Organization / College</label>
                    <input type="text" name="organization" class="form-control" placeholder="e.g. UC Computer Society" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="e.g. alice@gmail.com" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="contactNo" class="form-control" placeholder="e.g. 0917-111-2222" required>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Save Participant</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>