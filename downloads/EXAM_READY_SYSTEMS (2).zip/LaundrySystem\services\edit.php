<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM services WHERE serviceID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$s = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = is_string($_POST['serviceName'] ?? null) ? trim($_POST['serviceName']) : '';
    $type = is_string($_POST['serviceType'] ?? null) ? trim($_POST['serviceType']) : '';
    $price = floatval($_POST['pricePerKilo'] ?? 0);

    $stmt = $conn->prepare("UPDATE services SET serviceName=?, serviceType=?, pricePerKilo=? WHERE serviceID=?");
    $stmt->bind_param("ssdi", $name, $type, $price, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Service</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Edit Laundry Service</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Service Name</label>
                    <input type="text" name="serviceName" class="form-control" required value="<?php echo htmlspecialchars($s['serviceName']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Service Type / Category</label>
                    <select name="serviceType" class="form-select" required>
                        <?php foreach(['Regular Wash', 'Heavy Wash', 'Dry-Cleaning', 'Pressing'] as $t): ?>
                        <option value="<?php echo $t; ?>" <?php echo $s['serviceType'] === $t ? 'selected' : ''; ?>><?php echo $t; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Price per Kilogram (₱)</label>
                    <input type="number" step="0.01" name="pricePerKilo" class="form-control" required value="<?php echo $s['pricePerKilo']; ?>">
                </div>
                <button type="submit" class="btn btn-warning w-100">Update Service</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>