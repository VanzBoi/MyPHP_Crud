<?php
require_once '../database.php';
$msg = '';
$vets = $conn->query("SELECT * FROM veterinarians ORDER BY vetLName ASC");
$pets = $conn->query("SELECT * FROM pets ORDER BY petName ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vetID = (int)($_POST['vetID'] ?? 0);
    $petID = (int)($_POST['petID'] ?? 0);
    $tDate = is_string($_POST['treatmentDate'] ?? null) ? trim($_POST['treatmentDate']) : '';
    $diag = is_string($_POST['diagnosis'] ?? null) ? trim($_POST['diagnosis']) : '';
    $med = is_string($_POST['medication'] ?? null) ? trim($_POST['medication']) : '';
    $fee = floatval($_POST['treatmentFee'] ?? 0);

    if ($vetID <= 0 || $petID <= 0 || $tDate === '' || $diag === '') {
        $msg = "<div class='alert alert-danger'>Please fill in all required fields.</div>";
    } else {
        $sql = "INSERT INTO treatments (`vetID`, `petID`, `treatmentDate`, `diagnosis`, `medication`, `treatmentFee`, `status`) VALUES ('" . $conn->real_escape_string($vetID) . "', '" . $conn->real_escape_string($petID) . "', '" . $conn->real_escape_string($tDate) . "', '" . $conn->real_escape_string($diag) . "', '" . $conn->real_escape_string($med) . "', '" . $conn->real_escape_string($fee) . "', 'Completed')";
        if ($conn->query($sql)) {
            header("Location: index.php?msg=saved");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Failed to record transaction: " . htmlspecialchars($conn->error) . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Record Treatment</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 650px;">
        <div class="card p-4 mb-3">
            <h4>Record Pet Treatment</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Select Pet Patient</label>
                    <select name="petID" class="form-select" required>
                        <option value="">-- Choose Pet --</option>
                        <?php while($p = $pets->fetch_assoc()): ?>
                        <option value="<?php echo $p['petID']; ?>">
                            <?php echo htmlspecialchars($p['petName'] . ' (' . $p['speciesBreed'] . ') - Owner: ' . $p['ownerName']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Attending Veterinarian</label>
                    <select name="vetID" class="form-select" required>
                        <option value="">-- Choose Veterinarian --</option>
                        <?php while($v = $vets->fetch_assoc()): ?>
                        <option value="<?php echo $v['vetID']; ?>">
                            <?php echo htmlspecialchars('Dr. ' . $v['vetFName'] . ' ' . $v['vetLName'] . ' (' . $v['specialization'] . ')'); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Treatment Date</label>
                    <input type="date" name="treatmentDate" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Clinical Diagnosis / Findings</label>
                    <input type="text" name="diagnosis" class="form-control" required placeholder="e.g. Parvovirus, Skin Allergy, Routine Check">
                </div>
                <div class="mb-3">
                    <label class="form-label">Prescription / Procedures Conducted</label>
                    <textarea name="medication" class="form-control" rows="2" placeholder="e.g. Antibiotics, Deworming tablet, Wound cleaning"></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Treatment Fee (₱)</label>
                    <input type="number" step="0.01" name="treatmentFee" class="form-control" required placeholder="750.00">
                </div>
                <button type="submit" class="btn btn-primary w-100">Save Treatment Log</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to Treatments</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>