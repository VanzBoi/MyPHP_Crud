<?php
require '../database.php';
require '../helpers.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subjectCode = is_string($_POST['subjectCode'] ?? null) ? trim($_POST['subjectCode']) : '';
    $subjectName = is_string($_POST['subjectName'] ?? null) ? trim($_POST['subjectName']) : '';
    $units = is_string($_POST['units'] ?? null) ? trim($_POST['units']) : '';
    $feePerUnit = is_string($_POST['feePerUnit'] ?? null) ? trim($_POST['feePerUnit']) : '';

    if ($subjectCode === '') $errors[] = 'Subject code is required.';
    if ($subjectName === '') $errors[] = 'Subject name is required.';
    if ($units === '' || !ctype_digit($units)) $errors[] = 'Valid units are required.';
    if ($feePerUnit === '' || !is_numeric($feePerUnit)) $errors[] = 'Valid fee per unit is required.';

    if (!$errors) {
        $totalFee = number_format($units * $feePerUnit, 2, '.', '');
        $stmt = $mysqli->prepare('INSERT INTO subjects (subjectCode, subjectName, units, feePerUnit, totalFee) VALUES (?, ?, ?, ?, ?)');
        $stmt->bind_param('ssidd', $subjectCode, $subjectName, $units, $feePerUnit, $totalFee);
        $stmt->execute();
        flash('Subject added successfully.');
        redirect('index.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Subject</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
  <?php include '../navbar.php'; ?>
  <main class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="h3 mb-0">Add Subject</h1>
      </div>
      <a class="btn btn-secondary" href="index.php">Back to Subjects</a>
    </div>

    <?php if ($errors) : ?>
      <div class="alert alert-danger">
        <ul class="mb-0">
          <?php foreach ($errors as $error) : ?>
            <li><?= e($error) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form class="row g-3" action="add.php" method="post">
      <div class="col-md-6">
        <label for="subjectCode" class="form-label">Subject Code</label>
        <input id="subjectCode" name="subjectCode" value="<?= e(old('subjectCode')) ?>" required class="form-control">
      </div>
      <div class="col-md-6">
        <label for="subjectName" class="form-label">Subject Name</label>
        <input id="subjectName" name="subjectName" value="<?= e(old('subjectName')) ?>" required class="form-control">
      </div>
      <div class="col-md-3">
        <label for="units" class="form-label">Units</label>
        <input id="units" name="units" value="<?= e(old('units')) ?>" required class="form-control">
      </div>
      <div class="col-md-3">
        <label for="feePerUnit" class="form-label">Fee per Unit</label>
        <input id="feePerUnit" name="feePerUnit" value="<?= e(old('feePerUnit')) ?>" required class="form-control">
      </div>
      <div class="col-12 d-grid">
        <button class="btn btn-primary" type="submit">Save Subject</button>
      </div>
    </form>
  </main>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
