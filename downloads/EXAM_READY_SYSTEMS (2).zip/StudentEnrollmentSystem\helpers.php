<?php
// helpers.php - Session, sanitation, and flash helpers
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function e($string) {
    return htmlspecialchars(is_string($string) ? $string : (is_scalar($string) ? (string)$string : ''), ENT_QUOTES, 'UTF-8');
}

function escape($string) {
    return htmlspecialchars(is_string($string) ? $string : (is_scalar($string) ? (string)$string : ''), ENT_QUOTES, 'UTF-8');
}

function old($field, $default = '') {
    return (isset($_POST[$field]) && (is_string($_POST[$field]) || is_scalar($_POST[$field]))) ? htmlspecialchars((string)$_POST[$field], ENT_QUOTES, 'UTF-8') : $default;
}

function set_flash($message, $type = 'success') {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
}

function flash($message = null, $type = 'success') {
    if ($message !== null) {
        $_SESSION['flash_message'] = $message;
        $_SESSION['flash_type'] = $type;
        return;
    }
    if (isset($_SESSION['flash_message'])) {
        $msg = $_SESSION['flash_message'];
        $typ = $_SESSION['flash_type'] ?? 'success';
        if ($typ === 'error') $typ = 'danger';
        unset($_SESSION['flash_message'], $_SESSION['flash_type']);
        echo '<div class="alert alert-' . $typ . ' alert-dismissible fade show mb-3" role="alert">' . htmlspecialchars($msg) . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        return $msg;
    }
    return null;
}

function redirect($url) {
    header("Location: $url");
    exit;
}