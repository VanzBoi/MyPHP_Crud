<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pName = is_string($_POST['petName'] ?? null) ? trim($_POST['petName']) : '';
    $breed = is_string($_POST['speciesBreed'] ?? null) ? trim($_POST['speciesBreed']) : '';
    $age = is_string($_POST['petAge'] ?? null) ? trim($_POST['petAge']) : '';
    $owner = is_string($_POST['ownerName'] ?? null) ? trim($_POST['ownerName']) : '';
    $contact = is_string($_POST['ownerContact'] ?? null) ? trim($_POST['ownerContact']) : '';

    if ($pName && $breed && $owner) {
        $stmt = $conn->prepare("INSERT INTO pets (petName, speciesBreed, petAge, ownerName, ownerContact) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $pName, $breed, $age, $owner, $contact);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register Pet</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Register New Pet</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Pet Name</label>
                    <input type="text" name="petName" class="form-control" required placeholder="e.g. Brownie">
                </div>
                <div class="mb-3">
                    <label class="form-label">Species & Breed</label>
                    <input type="text" name="speciesBreed" class="form-control" required placeholder="e.g. Dog - Golden Retriever">
                </div>
                <div class="mb-3">
                    <label class="form-label">Pet Age</label>
                    <input type="text" name="petAge" class="form-control" placeholder="e.g. 2 years">
                </div>
                <div class="mb-3">
                    <label class="form-label">Owner Full Name</label>
                    <input type="text" name="ownerName" class="form-control" required placeholder="e.g. Maria Santos">
                </div>
                <div class="mb-3">
                    <label class="form-label">Owner Contact Number</label>
                    <input type="text" name="ownerContact" class="form-control" required placeholder="0917-000-0000">
                </div>
                <button type="submit" class="btn btn-primary w-100">Register Pet</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>