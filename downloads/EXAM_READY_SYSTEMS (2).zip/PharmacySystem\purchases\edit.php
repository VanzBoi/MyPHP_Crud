<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM purchases WHERE purchaseID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$e1List = $conn->query("SELECT medicineID, medicineName FROM medicines ORDER BY medicineName ASC");
$e2List = $conn->query("SELECT customerID, customerName FROM customers ORDER BY customerName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medicineID = (int)($_POST['medicineID'] ?? 0);
    $customerID = (int)($_POST['customerID'] ?? 0);
    $purchaseDate = is_string($_POST['purchaseDate'] ?? null) ? trim($_POST['purchaseDate']) : '';
    $quantity = is_string($_POST['quantity'] ?? null) ? trim($_POST['quantity']) : '';
    $totalAmount = is_string($_POST['totalAmount'] ?? null) ? trim($_POST['totalAmount']) : '';
    $paymentMode = is_string($_POST['paymentMode'] ?? null) ? trim($_POST['paymentMode']) : '';

    if ($medicineID <= 0 || $customerID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "UPDATE purchases SET `medicineID` = '" . $conn->real_escape_string($medicineID) . "', `customerID` = '" . $conn->real_escape_string($customerID) . "', `purchaseDate` = '" . $conn->real_escape_string($purchaseDate) . "', `quantity` = '" . $conn->real_escape_string($quantity) . "', `totalAmount` = '" . $conn->real_escape_string($totalAmount) . "', `paymentMode` = '" . $conn->real_escape_string($paymentMode) . "' WHERE purchaseID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Purchase #<?= $id ?> - Pharmacy Inventory and Sales System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Purchase #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Medicine <span class="text-danger">*</span></label>
            <select name="medicineID" class="form-select" required>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['medicineID'] ?>" <?= ($row['medicineID'] == $e1Row['medicineID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e1Row['medicineName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Customer <span class="text-danger">*</span></label>
            <select name="customerID" class="form-select" required>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['customerID'] ?>" <?= ($row['customerID'] == $e2Row['customerID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e2Row['customerName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Date</label>
                <input type="date" name="purchaseDate" class="form-control" value="<?= htmlspecialchars($row['purchaseDate'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Quantity Sold</label>
                <input type="number"  name="quantity" class="form-control" value="<?= htmlspecialchars($row['quantity'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Total Amount (₱)</label>
                <input type="number" step="0.01" name="totalAmount" class="form-control" value="<?= htmlspecialchars($row['totalAmount'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Payment Mode</label>
                <select name="paymentMode" class="form-select" required>
                    <option value="Cash" <?= ($row['paymentMode'] ?? '') === 'Cash' ? 'selected' : '' ?>>Cash</option>
<option value="GCash" <?= ($row['paymentMode'] ?? '') === 'GCash' ? 'selected' : '' ?>>GCash</option>
<option value="Card" <?= ($row['paymentMode'] ?? '') === 'Card' ? 'selected' : '' ?>>Card</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>