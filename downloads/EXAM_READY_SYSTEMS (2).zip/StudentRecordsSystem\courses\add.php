<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $courseCode = is_string($_POST['courseCode'] ?? null) ? trim($_POST['courseCode']) : '';
$courseTitle = is_string($_POST['courseTitle'] ?? null) ? trim($_POST['courseTitle']) : '';
$units = is_string($_POST['units'] ?? null) ? trim($_POST['units']) : '';
$department = is_string($_POST['department'] ?? null) ? trim($_POST['department']) : '';

    $sql = "INSERT INTO courses (`courseCode`, `courseTitle`, `units`, `department`) VALUES ('" . $conn->real_escape_string($courseCode) . "', '" . $conn->real_escape_string($courseTitle) . "', '" . $conn->real_escape_string($units) . "', '" . $conn->real_escape_string($department) . "')";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to add record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Course / Subject - Student Academic Records &amp; Grading System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Add New Course / Subject</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Course Code</label>
                <input type="text" name="courseCode" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Course Title</label>
                <input type="text" name="courseTitle" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Units</label>
                <input type="number"  name="units" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Department</label>
                <select name="department" class="form-select" required>
                    <option value="CCS">CCS</option>
<option value="COE">COE</option>
<option value="CBA">CBA</option>
<option value="CAS">CAS</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Course / Subject</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>