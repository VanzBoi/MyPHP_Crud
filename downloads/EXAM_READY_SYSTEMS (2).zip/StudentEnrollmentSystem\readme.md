﻿# Student Enrollment System

A simple PHP and MySQL web application for managing subjects, students, and enrollment.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\StudentEnrollmentSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/StudentEnrollmentSystem/
4. The database `enrollmentdb` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Subjects**: Add, view, edit, and delete subjects records.
- **Students**: Add, view, edit, and delete students records.
- **Enrollment**: Manage enrollment transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
