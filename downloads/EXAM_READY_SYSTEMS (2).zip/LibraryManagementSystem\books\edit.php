<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM books WHERE bookID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$b = $res->fetch_assoc();
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = is_string($_POST['title'] ?? null) ? trim($_POST['title']) : '';
    $author = is_string($_POST['author'] ?? null) ? trim($_POST['author']) : '';
    $category = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
    $price = floatval($_POST['price'] ?? 0);
    $copies = intval($_POST['copies'] ?? 1);

    if ($title === '' || $author === '') {
        $err = 'Please complete book title and author.';
    } else {
        $stmt = $conn->prepare("UPDATE books SET title = ?, author = ?, category = ?, price = ?, copies = ? WHERE bookID = ?");
        $stmt->bind_param("sssdi", $title, $author, $category, $price, $copies, $id);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Update failed: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Book</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Edit Book Catalog Entry</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Book Title</label>
                    <input type="text" name="title" class="form-control" required value="<?php echo htmlspecialchars($b['title']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Author / Creator</label>
                    <input type="text" name="author" class="form-control" required value="<?php echo htmlspecialchars($b['author']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <input type="text" name="category" class="form-control" value="<?php echo htmlspecialchars($b['category']); ?>">
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Replacement Value (₱)</label>
                        <input type="number" step="0.01" name="price" class="form-control" value="<?php echo $b['price']; ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Copies on Shelf</label>
                        <input type="number" name="copies" class="form-control" value="<?php echo $b['copies']; ?>" min="0" required>
                    </div>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Book</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>