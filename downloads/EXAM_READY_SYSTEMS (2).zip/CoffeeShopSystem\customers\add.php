<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = is_string($_POST['customerName'] ?? null) ? trim($_POST['customerName']) : '';
    $table = is_string($_POST['tableNumber'] ?? null) ? trim($_POST['tableNumber']) : '';
    $contact = is_string($_POST['customerContact'] ?? null) ? trim($_POST['customerContact']) : '';

    if ($name) {
        $stmt = $conn->prepare("INSERT INTO customers (customerName, tableNumber, customerContact) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $table, $contact);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Customer</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Add Customer / Table</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Customer Name</label>
                    <input type="text" name="customerName" class="form-control" required placeholder="e.g. Juan Gomez">
                </div>
                <div class="mb-3">
                    <label class="form-label">Table Number / Dining Mode</label>
                    <input type="text" name="tableNumber" class="form-control" required placeholder="e.g. Table 5, Counter, Takeout">
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="customerContact" class="form-control" placeholder="0917-000-0000">
                </div>
                <button type="submit" class="btn btn-primary w-100">Save Customer Record</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>