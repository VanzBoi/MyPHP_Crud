<?php include '../database.php'; include '../helpers.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $no = is_string($_POST['roomNo'] ?? null) ? $conn->real_escape_string(trim($_POST['roomNo'])) : '';
  $type = is_string($_POST['roomType'] ?? null) ? $conn->real_escape_string(trim($_POST['roomType'])) : '';
  $price = (float)($_POST['price'] ?? 0);
  $status = is_string($_POST['status'] ?? null) ? $conn->real_escape_string(trim($_POST['status'])) : '';
  mysqli_query($conn, "INSERT INTO rooms (roomNo,roomType,price,status) VALUES ('{$no}','{$type}',{$price},'{$status}')");
  set_flash('Room added.', 'success');
  header('Location: index.php'); exit;
}
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Room</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
  </head>
  <body>
    <?php include '../navbar.php'; ?>
    <div class="container">
      <h4>Add Room</h4>
      <form method="post">
        <div class="mb-2"><label>Room No</label><input name="roomNo" class="form-control" required></div>
        <div class="mb-2"><label>Room Type</label><input name="roomType" class="form-control" required></div>
        <div class="mb-2"><label>Price</label><input type="number" step="0.01" name="price" class="form-control" required></div>
        <div class="mb-2"><label>Status</label><select name="status" class="form-control"><option>Available</option><option>Occupied</option></select></div>
        <button class="btn btn-primary">Save</button>
        <a class="btn btn-secondary" href="index.php">Cancel</a>
      </form>
    </div>
      <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
  </body>
</html>
