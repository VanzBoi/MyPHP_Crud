CREATE DATABASE IF NOT EXISTS laundry_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE laundry_db;

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS services (
  serviceID INT AUTO_INCREMENT PRIMARY KEY,
  serviceName VARCHAR(100) NOT NULL,
  serviceType VARCHAR(50) NOT NULL,
  pricePerKilo DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
  customerID INT AUTO_INCREMENT PRIMARY KEY,
  custFName VARCHAR(100) NOT NULL,
  custLName VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL,
  address VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS laundry_orders (
  orderID INT AUTO_INCREMENT PRIMARY KEY,
  serviceID INT NOT NULL,
  customerID INT NOT NULL,
  orderDate DATE NOT NULL,
  weightKilos DECIMAL(10,2) NOT NULL,
  totalAmount DECIMAL(10,2) NOT NULL,
  orderStatus VARCHAR(50) DEFAULT 'Pending',
  FOREIGN KEY (serviceID) REFERENCES services(serviceID) ON DELETE CASCADE,
  FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO services (serviceName, serviceType, pricePerKilo) VALUES
('Wash, Dry & Fold', 'Regular Wash', 35.00),
('Beddings & Comforter Heavy Wash', 'Heavy Wash', 55.00),
('Barong & Suit Premium Care', 'Dry-Cleaning', 120.00),
('Steam Press & Ironing', 'Pressing', 30.00);

INSERT INTO customers (custFName, custLName, contactNumber, address) VALUES
('Grace', 'Villanueva', '0917-888-1122', 'Lahug, Cebu City'),
('Antonio', 'Aquino', '0918-777-3344', 'Banilad, Mandaue City'),
('Lourdes', 'Mercado', '0922-444-6688', 'Guadalupe, Cebu City');

INSERT INTO laundry_orders (serviceID, customerID, orderDate, weightKilos, totalAmount, orderStatus) VALUES
(1, 1, '2026-10-24', 6.50, 227.50, 'Claimed'),
(2, 2, '2026-10-25', 10.00, 550.00, 'Ready'),
(3, 3, '2026-10-25', 3.00, 360.00, 'Processing'),
(1, 2, '2026-10-26', 8.00, 280.00, 'Pending');

SET FOREIGN_KEY_CHECKS=1;