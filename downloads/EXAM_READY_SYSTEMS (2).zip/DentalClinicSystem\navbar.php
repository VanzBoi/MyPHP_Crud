<?php
// Global navigation bar
$cur = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= $baseUrl ?>index.php">Dental Clinic Management System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (strpos($cur, '/index.php') !== false && strpos($cur, '/dentists') === false && strpos($cur, '/patients') === false && strpos($cur, '/appointments') === false && strpos($cur, '/monitoring') === false) ? 'active' : '' ?>" href="<?= $baseUrl ?>index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/dentists/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>dentists/index.php">Dentist</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/patients/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>patients/index.php">Patient</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/appointments/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>appointments/index.php">Appointment</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/monitoring/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>