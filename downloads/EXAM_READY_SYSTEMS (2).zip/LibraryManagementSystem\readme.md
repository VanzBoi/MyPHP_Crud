﻿# Library Management System

A simple PHP and MySQL web application for managing books, borrowers, and borrowed books.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\LibraryManagementSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/LibraryManagementSystem/
4. The database `librarydb` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Books**: Add, view, edit, and delete books records.
- **Borrowers**: Add, view, edit, and delete borrowers records.
- **Borrowed Books**: Manage borrowed books transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
