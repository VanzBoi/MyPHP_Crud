<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    redirect('index.php');
}

$stmt = mysqli_prepare($conn, 'SELECT * FROM packages WHERE packageID = ?');
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$package = mysqli_fetch_assoc($result);
if (!$package) {
    redirect('index.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $packageName = is_string($_POST['packageName'] ?? null) ? trim($_POST['packageName']) : '';
    $description = is_string($_POST['description'] ?? null) ? trim($_POST['description']) : '';
    $duration = intval($_POST['duration'] ?? 0);
    $fee = floatval($_POST['fee'] ?? 0);
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : 'Active';

    if ($packageName === '' || $duration <= 0 || $fee <= 0) {
        $errors[] = 'Please provide the package name, duration, and fee.';
    }

    if (!$errors) {
        $stmt = mysqli_prepare($conn, 'UPDATE packages SET packageName = ?, description = ?, duration = ?, fee = ?, status = ? WHERE packageID = ?');
        mysqli_stmt_bind_param($stmt, 'ssidsi', $packageName, $description, $duration, $fee, $status, $id);
        mysqli_stmt_execute($stmt);
        flash('Package updated successfully.');
        redirect('index.php');
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Package - Gym Membership</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>
    <div class="container">
        <div class="py-3">
            <h2>Edit Package</h2>
            <?php if ($errors): ?>
                <div class="alert alert-danger"><ul><?php foreach ($errors as $error): ?><li><?php echo escape($error); ?></li><?php endforeach; ?></ul></div>
            <?php endif; ?>
            <form method="post" action="edit.php?id=<?php echo escape($id); ?>">
                <div class="mb-3"><label class="form-label">Package Name</label><input type="text" name="packageName" class="form-control" value="<?php echo escape($_POST['packageName'] ?? $package['packageName']); ?>"></div>
                <div class="mb-3"><label class="form-label">Description</label><textarea name="description" class="form-control"><?php echo escape($_POST['description'] ?? $package['description']); ?></textarea></div>
                <div class="row g-3">
                    <div class="col-md-4"><label class="form-label">Duration (Months)</label><input type="number" name="duration" class="form-control" value="<?php echo escape($_POST['duration'] ?? $package['duration']); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Fee</label><input type="number" step="0.01" name="fee" class="form-control" value="<?php echo escape($_POST['fee'] ?? $package['fee']); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Status</label><select name="status" class="form-select"><option value="Active" <?php echo ((($_POST['status'] ?? $package['status']) === 'Active') ? 'selected' : ''); ?>>Active</option><option value="Inactive" <?php echo ((($_POST['status'] ?? $package['status']) === 'Inactive') ? 'selected' : ''); ?>>Inactive</option></select></div>
                </div>
                <div class="mt-4"><button type="submit" class="btn btn-primary">Update Package</button> <a href="index.php" class="btn btn-secondary">Cancel</a></div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
