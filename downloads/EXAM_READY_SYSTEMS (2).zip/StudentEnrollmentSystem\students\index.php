<?php
require '../database.php';
require '../helpers.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$query = "SELECT * FROM students";
if ($search !== '') {
    $s = $mysqli->real_escape_string($search);
    $query .= " WHERE fname LIKE '%$s%' OR lname LIKE '%$s%' OR course LIKE '%$s%' OR contactNo LIKE '%$s%'";
}
$result = $mysqli->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Students</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
  <?php include '../navbar.php'; ?>
  <main class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
      <div>
        <h1 class="h3 mb-1">Students</h1>
        <p class="text-muted mb-0">Add, view, edit, and remove student records.</p>
      </div>
      <a class="btn btn-primary" href="add.php">Add Student</a>
    </div>

    <?php if ($message = flash()) : ?>
      <div class="alert alert-success" role="alert">
        <?= e($message) ?>
      </div>
    <?php endif; ?>

    <div class="card mb-4">
      <div class="card-body">
        <form class="row g-3 align-items-end" action="index.php" method="get">
          <div class="col-md-8">
            <label for="search" class="form-label">Search</label>
            <input id="search" name="search" value="<?= e($search) ?>" placeholder="Name, course, contact" class="form-control">
          </div>
          <div class="col-md-4 d-grid">
            <button class="btn btn-outline-primary" type="submit">Search</button>
          </div>
        </form>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-striped table-bordered align-middle mb-0">
        <thead class="table-light">
          <tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Course</th><th>Year</th><th>Contact</th><th class="text-end">Actions</th></tr>
        </thead>
        <tbody>
          <?php while ($student = $result->fetch_assoc()) : ?>
          <tr>
            <td><?= e($student['studentID']) ?></td>
            <td><?= e($student['fname']) ?></td>
            <td><?= e($student['lname']) ?></td>
            <td><?= e($student['course']) ?></td>
            <td><?= e($student['yearLevel']) ?></td>
            <td><?= e($student['contactNo']) ?></td>
            <td class="text-end">
              <a class="btn btn-sm btn-outline-secondary me-2" href="edit.php?id=<?= e($student['studentID']) ?>">Edit</a>
              <a class="btn btn-sm btn-outline-danger" href="delete.php?id=<?= e($student['studentID']) ?>" onclick="return confirm('Delete this student?');">Delete</a>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </main>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
