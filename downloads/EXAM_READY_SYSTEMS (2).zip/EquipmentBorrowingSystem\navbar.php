<?php
// Global navigation bar
$cur = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= $baseUrl ?>index.php">Equipment Borrowing &amp; Tracking System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (strpos($cur, '/index.php') !== false && strpos($cur, '/equipment') === false && strpos($cur, '/borrowers') === false && strpos($cur, '/borrow_logs') === false && strpos($cur, '/monitoring') === false) ? 'active' : '' ?>" href="<?= $baseUrl ?>index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/equipment/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>equipment/index.php">Equipment</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/borrowers/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>borrowers/index.php">Borrower</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/borrow_logs/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>borrow_logs/index.php">Borrow Log</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/monitoring/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>