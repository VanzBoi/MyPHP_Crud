<?php
if (!isset($baseUrl)) {
    require_once __DIR__ . '/database.php';
}
$navBase = rtrim($baseUrl, '/');
$currentUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
  <div class="container-fluid container">
    <a class="navbar-brand nav-brand" href="<?php echo $navBase; ?>/index.php">Clinic Consultation</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navmenu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/doctors/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/doctors/index.php">Doctors</a></li>
        <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/patients/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/patients/index.php">Patients</a></li>
        <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/consultations/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/consultations/index.php">Consultations</a></li>
        <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/monitoring/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/monitoring/index.php">Monitoring</a></li>
      </ul>
    </div>
  </div>
</nav>
