<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$query = 'SELECT * FROM members';
$params = [];
if ($search !== '') {
    $query .= ' WHERE fName LIKE ? OR lName LIKE ? OR contactNo LIKE ?';
    $params = ["%{$search}%", "%{$search}%", "%{$search}%"];
}
$stmt = mysqli_prepare($conn, $query);
if ($params) {
    mysqli_stmt_bind_param($stmt, 'sss', ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Members - Gym Membership</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Members</h2>
            <a href="add.php" class="btn btn-success">Add Member</a>
        </div>
        <?php if ($flash = flash()): ?>
            <div class="alert alert-<?php echo escape($flash['type']); ?>"><?php echo escape($flash['message']); ?></div>
        <?php endif; ?>
        <form class="row g-2 mb-3" method="get" action="index.php">
            <div class="col-md-10">
                <input type="search" name="search" class="form-control" placeholder="Search members by name or contact" value="<?php echo escape($search); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Search</button>
            </div>
        </form>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Birth Date</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Contact</th>
                        <th>Discount (%)</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($member = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo escape($member['memberID']); ?></td>
                            <td><?php echo escape($member['fName']); ?></td>
                            <td><?php echo escape($member['lName']); ?></td>
                            <td><?php echo escape($member['birthDate']); ?></td>
                            <td><?php echo escape($member['age']); ?></td>
                            <td><?php echo escape($member['gender']); ?></td>
                            <td><?php echo escape($member['contactNo']); ?></td>
                            <td><?php echo escape($member['discount']); ?></td>
                            <td>
                                <a href="edit.php?id=<?php echo escape($member['memberID']); ?>" class="btn btn-sm btn-primary">Edit</a>
                                <a href="delete.php?id=<?php echo escape($member['memberID']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this member?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
