CREATE DATABASE IF NOT EXISTS appointment_system_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE appointment_system_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS services (
  serviceID INT AUTO_INCREMENT PRIMARY KEY,
  serviceName VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL,
  durationMin INT NOT NULL,
  serviceFee DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS clients (
  clientID INT AUTO_INCREMENT PRIMARY KEY,
  clientName VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL,
  address VARCHAR(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS appointments (
  appointmentID INT AUTO_INCREMENT PRIMARY KEY,
  serviceID INT NOT NULL,
  clientID INT NOT NULL,
  appointmentDate DATE NOT NULL,
  appointmentTime VARCHAR(20) NOT NULL,
  totalFee DECIMAL(10,2) NOT NULL,
  status VARCHAR(50) DEFAULT 'Pending',
  FOREIGN KEY (serviceID) REFERENCES services(serviceID) ON DELETE CASCADE,
  FOREIGN KEY (clientID) REFERENCES clients(clientID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO services (serviceName, category, durationMin, serviceFee) VALUES
('Legal Document Review', 'Legal', 60, 2500.00),
('Tax & Financial Advisory', 'Financial', 90, 3000.00),
('Career & Life Coaching', 'Coaching', 45, 1200.00),
('Corporate Compliance Audit', 'Corporate', 120, 5000.00);

INSERT INTO clients (clientName, email, contactNumber, address) VALUES
('Eduardo Manalo', 'emanalo@gmail.com', '09171239876', 'Cebu City'),
('Regina Velasquez', 'regina@yahoo.com', '09182348765', 'Mandaue City'),
('Arthur Nery', 'arthur@outlook.com', '09223457654', 'Lapu-Lapu City');

INSERT INTO appointments (serviceID, clientID, appointmentDate, appointmentTime, totalFee, status) VALUES
(1, 1, '2026-10-25', '10:00 AM', 2500.00, 'Confirmed'),
(2, 2, '2026-10-26', '02:00 PM', 3000.00, 'Completed'),
(3, 3, '2026-10-27', '04:30 PM', 1200.00, 'Pending');

SET FOREIGN_KEY_CHECKS=1;