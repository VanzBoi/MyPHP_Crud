<?php
require_once '../database.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
if ($search !== '') {
    $stmt = $conn->prepare("SELECT a.*, d.deptCode, d.deptName FROM athletes a JOIN departments d ON a.deptID = d.deptID WHERE a.studentID LIKE ? OR a.fullName LIKE ? OR d.deptCode LIKE ? ORDER BY a.athleteID DESC");
    $param = "%$search%";
    $stmt->bind_param("sss", $param, $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT a.*, d.deptCode, d.deptName FROM athletes a JOIN departments d ON a.deptID = d.deptID ORDER BY a.athleteID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Athlete Roster</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Registered Student Athletes</h3>
            <a href="add.php" class="btn btn-primary">+ Add New Athlete</a>
        </div>
        <div class="card p-3 mb-3">
            <form method="GET" class="row g-2">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="Search by student ID, athlete name or college..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Search</button>
                    <?php if ($search !== ''): ?>
                        <a href="index.php" class="btn btn-outline-secondary">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <div class="card p-0">
            <table class="table table-bordered table-striped mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student ID</th>
                        <th>Full Name</th>
                        <th>Department</th>
                        <th>Year Level</th>
                        <th>Gender</th>
                        <th>Contact No.</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['athleteID']; ?></td>
                            <td><code><?php echo htmlspecialchars($row['studentID']); ?></code></td>
                            <td><strong><?php echo htmlspecialchars($row['fullName']); ?></strong></td>
                            <td><span class="badge bg-primary"><?php echo htmlspecialchars($row['deptCode']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['yearLevel']); ?></td>
                            <td><?php echo htmlspecialchars($row['gender']); ?></td>
                            <td><?php echo htmlspecialchars($row['contactNo']); ?></td>
                            <td class="text-end">
                                <a href="edit.php?id=<?php echo $row['athleteID']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete.php?id=<?php echo $row['athleteID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete athlete?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No athletes found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>