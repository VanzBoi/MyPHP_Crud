<?php
require_once '../database.php';
require_once '../helpers.php';

$fName = '';
$lName = '';
$course = '';
$yearLevel = '';
$contactNo = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fName = is_string($_POST['fName'] ?? null) ? trim($_POST['fName']) : '';
    $lName = is_string($_POST['lName'] ?? null) ? trim($_POST['lName']) : '';
    $course = is_string($_POST['course'] ?? null) ? trim($_POST['course']) : '';
    $yearLevel = is_string($_POST['yearLevel'] ?? null) ? trim($_POST['yearLevel']) : '';
    $contactNo = is_string($_POST['contactNo'] ?? null) ? trim($_POST['contactNo']) : '';

    if ($fName === '' || $lName === '' || $course === '' || $yearLevel === '' || $contactNo === '') {
        set_flash('All fields are required.', 'error');
    } else {
        $stmt = $mysqli->prepare('INSERT INTO students (fName, lName, course, yearLevel, contactNo) VALUES (?, ?, ?, ?, ?)');
        $stmt->bind_param('sssss', $fName, $lName, $course, $yearLevel, $contactNo);
        $stmt->execute();
        $stmt->close();
        set_flash('Student added successfully.');
        redirect('index.php');
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Student</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<div class="container mt-4">
    <?php include '../navbar.php'; ?>
    <div class="mb-3">
        <h2>Add Student</h2>
    </div>
    <?php flash(); ?>
    <form method="post">
        <div class="mb-3">
            <label class="form-label">First Name</label>
            <input type="text" name="fName" class="form-control" value="<?= escape($fName) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Last Name</label>
            <input type="text" name="lName" class="form-control" value="<?= escape($lName) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Course</label>
            <input type="text" name="course" class="form-control" value="<?= escape($course) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Year Level</label>
            <input type="text" name="yearLevel" class="form-control" value="<?= escape($yearLevel) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Contact No.</label>
            <input type="text" name="contactNo" class="form-control" value="<?= escape($contactNo) ?>">
        </div>
        <button class="btn btn-primary" type="submit">Save</button>
        <a href="index.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
