<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM products WHERE productID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName = is_string($_POST['productName'] ?? null) ? trim($_POST['productName']) : '';
$category = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
$unitCost = is_string($_POST['unitCost'] ?? null) ? trim($_POST['unitCost']) : '';
$reorderLevel = is_string($_POST['reorderLevel'] ?? null) ? trim($_POST['reorderLevel']) : '';

    $sql = "UPDATE products SET `productName` = '" . $conn->real_escape_string($productName) . "', `category` = '" . $conn->real_escape_string($category) . "', `unitCost` = '" . $conn->real_escape_string($unitCost) . "', `reorderLevel` = '" . $conn->real_escape_string($reorderLevel) . "' WHERE productID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product #<?= $id ?> - Warehouse Inventory &amp; Stock Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Product #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Product Name</label>
                <input type="text" name="productName" class="form-control" value="<?= htmlspecialchars($row['productName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Category</label>
                <select name="category" class="form-select" required>
                    <option value="Industrial" <?= ($row['category'] ?? '') === 'Industrial' ? 'selected' : '' ?>>Industrial</option>
<option value="Hardware" <?= ($row['category'] ?? '') === 'Hardware' ? 'selected' : '' ?>>Hardware</option>
<option value="Safety Gear" <?= ($row['category'] ?? '') === 'Safety Gear' ? 'selected' : '' ?>>Safety Gear</option>
<option value="Tools" <?= ($row['category'] ?? '') === 'Tools' ? 'selected' : '' ?>>Tools</option>
<option value="Electrical" <?= ($row['category'] ?? '') === 'Electrical' ? 'selected' : '' ?>>Electrical</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Unit Cost (₱)</label>
                <input type="number" step="0.01" name="unitCost" class="form-control" value="<?= htmlspecialchars($row['unitCost'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Reorder Level</label>
                <input type="number"  name="reorderLevel" class="form-control" value="<?= htmlspecialchars($row['reorderLevel'] ?? '') ?>" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>