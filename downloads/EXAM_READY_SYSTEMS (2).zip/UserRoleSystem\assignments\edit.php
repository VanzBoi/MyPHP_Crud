<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM assignments WHERE assignmentID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$e1List = $conn->query("SELECT roleID, roleName FROM roles ORDER BY roleName ASC");
$e2List = $conn->query("SELECT userID, fullName FROM users ORDER BY fullName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $roleID = (int)($_POST['roleID'] ?? 0);
    $userID = (int)($_POST['userID'] ?? 0);
    $assignedDate = is_string($_POST['assignedDate'] ?? null) ? trim($_POST['assignedDate']) : '';
    $allowance = is_string($_POST['allowance'] ?? null) ? trim($_POST['allowance']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($roleID <= 0 || $userID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "UPDATE assignments SET `roleID` = '" . $conn->real_escape_string($roleID) . "', `userID` = '" . $conn->real_escape_string($userID) . "', `assignedDate` = '" . $conn->real_escape_string($assignedDate) . "', `allowance` = '" . $conn->real_escape_string($allowance) . "', `status` = '" . $conn->real_escape_string($status) . "' WHERE assignmentID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Assignment #<?= $id ?> - User Role &amp; Access Assignment System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Assignment #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Role <span class="text-danger">*</span></label>
            <select name="roleID" class="form-select" required>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['roleID'] ?>" <?= ($row['roleID'] == $e1Row['roleID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e1Row['roleName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">User <span class="text-danger">*</span></label>
            <select name="userID" class="form-select" required>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['userID'] ?>" <?= ($row['userID'] == $e2Row['userID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e2Row['fullName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Assigned Date</label>
                <input type="date" name="assignedDate" class="form-control" value="<?= htmlspecialchars($row['assignedDate'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Stipend / Allowance (₱)</label>
                <input type="number" step="0.01" name="allowance" class="form-control" value="<?= htmlspecialchars($row['allowance'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Status</label>
                <select name="status" class="form-select" required>
                    <option value="Active" <?= ($row['status'] ?? '') === 'Active' ? 'selected' : '' ?>>Active</option>
<option value="Suspended" <?= ($row['status'] ?? '') === 'Suspended' ? 'selected' : '' ?>>Suspended</option>
<option value="Revoked" <?= ($row['status'] ?? '') === 'Revoked' ? 'selected' : '' ?>>Revoked</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>