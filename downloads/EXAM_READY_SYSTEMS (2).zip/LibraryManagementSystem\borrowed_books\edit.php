<?php
require_once '../database.php';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}
$res = $conn->query("SELECT * FROM borrowed_books WHERE borrowID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$loan = $res->fetch_assoc();
$books = $conn->query("SELECT * FROM books ORDER BY title ASC");
$borrowers = $conn->query("SELECT * FROM borrowers ORDER BY fname ASC");
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $borID = (int)($_POST['borrowerID'] ?? 0);
    $bookID = (int)($_POST['bookID'] ?? 0);
    $borrowDate = is_string($_POST['borrowDate'] ?? null) ? trim($_POST['borrowDate']) : '';
    $dueDate = is_string($_POST['dueDate'] ?? null) ? trim($_POST['dueDate']) : '';
    $returnDate = is_string($_POST['returnDate'] ?? null) ? trim($_POST['returnDate']) : '';
    $fine = floatval($_POST['fine'] ?? 0);
    $status = is_string($_POST['loanStatus'] ?? null) ? trim($_POST['loanStatus']) : 'Borrowed';

    if ($borID <= 0 || $bookID <= 0 || $borrowDate === '' || $dueDate === '') {
        $err = 'Please complete all required fields.';
    } else {
        $returnDateSql = $returnDate !== '' ? "'" . $conn->real_escape_string($returnDate) . "'" : "NULL";
        $sql = "UPDATE borrowed_books SET `borrowerID` = '" . $conn->real_escape_string($borID) . "', `bookID` = '" . $conn->real_escape_string($bookID) . "', `borrowDate` = '" . $conn->real_escape_string($borrowDate) . "', `dueDate` = '" . $conn->real_escape_string($dueDate) . "', `returnDate` = $returnDateSql, `fine` = '" . $conn->real_escape_string($fine) . "', `loanStatus` = '" . $conn->real_escape_string($status) . "' WHERE borrowID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Failed to update transaction: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Borrow Record</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Edit Loan Transaction</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Borrower</label>
                    <select name="borrowerID" class="form-select" required>
                        <?php while($b = $borrowers->fetch_assoc()): ?>
                            <option value="<?php echo $b['borrowerID']; ?>" <?php echo ($b['borrowerID'] == $loan['borrowerID']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($b['fname'] . ' ' . $b['lname'] . ' (' . $b['course'] . ')'); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Book</label>
                    <select name="bookID" class="form-select" required>
                        <?php while($bk = $books->fetch_assoc()): ?>
                            <option value="<?php echo $bk['bookID']; ?>" <?php echo ($bk['bookID'] == $loan['bookID']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($bk['title'] . ' - ' . $bk['author']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Borrow Date</label>
                        <input type="date" name="borrowDate" class="form-control" value="<?php echo $loan['borrowDate']; ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Due Date</label>
                        <input type="date" name="dueDate" class="form-control" value="<?php echo $loan['dueDate']; ?>" required>
                    </div>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Actual Return Date</label>
                        <input type="date" name="returnDate" class="form-control" value="<?php echo $loan['returnDate'] ?? ''; ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Assessed Fine (₱)</label>
                        <input type="number" step="0.01" name="fine" class="form-control" value="<?php echo $loan['fine']; ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Loan Status</label>
                    <select name="loanStatus" class="form-select" required>
                        <option value="Borrowed" <?php echo ($loan['loanStatus'] === 'Borrowed') ? 'selected' : ''; ?>>Borrowed</option>
                        <option value="Returned" <?php echo ($loan['loanStatus'] === 'Returned') ? 'selected' : ''; ?>>Returned</option>
                        <option value="Overdue" <?php echo ($loan['loanStatus'] === 'Overdue') ? 'selected' : ''; ?>>Overdue</option>
                    </select>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Loan Record</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>