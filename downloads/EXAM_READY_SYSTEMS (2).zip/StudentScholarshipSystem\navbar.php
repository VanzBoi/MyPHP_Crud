<?php
if (!isset($baseUrl)) {
    require_once __DIR__ . '/database.php';
}
$navBase = rtrim($baseUrl, '/');
$currentUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container-fluid container">
        <a class="navbar-brand nav-brand" href="<?php echo $navBase; ?>/index.php">Scholarship System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navScholarship">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navScholarship">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/students/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/students/index.php">Students</a></li>
                <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/scholarships/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/scholarships/index.php">Scholarships</a></li>
                <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/applications/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/applications/index.php">Applications</a></li>
                <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/monitoring/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/monitoring/index.php">Monitoring</a></li>
            </ul>
        </div>
    </div>
</nav>
