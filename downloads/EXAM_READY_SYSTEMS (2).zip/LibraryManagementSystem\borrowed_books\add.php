<?php
require_once '../database.php';
$books = $conn->query("SELECT * FROM books WHERE copies > 0 ORDER BY title ASC");
$borrowers = $conn->query("SELECT * FROM borrowers ORDER BY fname ASC");
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $borID = (int)($_POST['borrowerID'] ?? 0);
    $bookID = (int)($_POST['bookID'] ?? 0);
    $borrowDate = is_string($_POST['borrowDate'] ?? null) ? trim($_POST['borrowDate']) : '';
    $dueDate = is_string($_POST['dueDate'] ?? null) ? trim($_POST['dueDate']) : '';
    $status = is_string($_POST['loanStatus'] ?? null) ? trim($_POST['loanStatus']) : 'Borrowed';

    if ($borID <= 0 || $bookID <= 0 || $borrowDate === '' || $dueDate === '') {
        $err = 'Please select a borrower, book, and loan schedule.';
    } else {
        $sql = "INSERT INTO borrowed_books (`borrowerID`, `bookID`, `borrowDate`, `dueDate`, `fine`, `loanStatus`) VALUES ('" . $conn->real_escape_string($borID) . "', '" . $conn->real_escape_string($bookID) . "', '" . $conn->real_escape_string($borrowDate) . "', '" . $conn->real_escape_string($dueDate) . "', '0.00', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            $conn->query("UPDATE books SET copies = copies - 1 WHERE bookID = $bookID AND copies > 0");
            header("Location: index.php");
            exit;
        } else {
            $err = 'Failed to record transaction: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Issue Book Loan</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Issue Book Loan</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Borrower</label>
                    <select name="borrowerID" class="form-select" required>
                        <option value="">-- Choose Borrower --</option>
                        <?php while($b = $borrowers->fetch_assoc()): ?>
                            <option value="<?php echo $b['borrowerID']; ?>">
                                <?php echo htmlspecialchars($b['fname'] . ' ' . $b['lname'] . ' (' . $b['course'] . ')'); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Select Book</label>
                    <select name="bookID" class="form-select" required>
                        <option value="">-- Choose Book --</option>
                        <?php while($bk = $books->fetch_assoc()): ?>
                            <option value="<?php echo $bk['bookID']; ?>">
                                <?php echo htmlspecialchars($bk['title'] . ' - ' . $bk['author'] . ' (' . $bk['copies'] . ' copies available)'); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Borrow Date</label>
                        <input type="date" name="borrowDate" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Due Return Date</label>
                        <input type="date" name="dueDate" class="form-control" value="<?php echo date('Y-m-d', strtotime('+7 days')); ?>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Status</label>
                    <select name="loanStatus" class="form-select" required>
                        <option value="Borrowed">Borrowed</option>
                        <option value="Overdue">Overdue</option>
                    </select>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Confirm Book Loan</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>