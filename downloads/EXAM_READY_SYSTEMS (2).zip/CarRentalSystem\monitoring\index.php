<?php
require_once '../database.php';

// Fetch distinct vehicle types for dropdown filter
$typeResult = $conn->query("SELECT DISTINCT vehicleType FROM vehicles ORDER BY vehicleType ASC");

$filterType = is_string($_GET['vehicleType'] ?? null) ? trim($_GET['vehicleType']) : '';

// Filtered query
if ($filterType !== '') {
    $stmt = $conn->prepare("SELECT r.*, v.plateNumber, v.brandModel, v.vehicleType, v.dailyRate, c.custFName, c.custLName 
                            FROM rentals r
                            JOIN vehicles v ON r.vehicleID = v.vehicleID
                            JOIN customers c ON r.customerID = c.customerID
                            WHERE v.vehicleType = ?
                            ORDER BY r.rentalID DESC");
    $stmt->bind_param("s", $filterType);
    $stmt->execute();
    $records = $stmt->get_result();

    // Summary metrics
    $aggStmt = $conn->prepare("SELECT COUNT(*) AS total_rentals, IFNULL(SUM(r.totalFee), 0) AS total_revenue, IFNULL(AVG(r.totalDays), 0) AS avg_days
                               FROM rentals r
                               JOIN vehicles v ON r.vehicleID = v.vehicleID
                               WHERE v.vehicleType = ?");
    $aggStmt->bind_param("s", $filterType);
    $aggStmt->execute();
    $agg = $aggStmt->get_result()->fetch_assoc();
} else {
    $records = $conn->query("SELECT r.*, v.plateNumber, v.brandModel, v.vehicleType, v.dailyRate, c.custFName, c.custLName 
                             FROM rentals r
                             JOIN vehicles v ON r.vehicleID = v.vehicleID
                             JOIN customers c ON r.customerID = c.customerID
                             ORDER BY r.rentalID DESC");
    $agg = $conn->query("SELECT COUNT(*) AS total_rentals, IFNULL(SUM(totalFee), 0) AS total_revenue, IFNULL(AVG(totalDays), 0) AS avg_days FROM rentals")->fetch_assoc();
}

$count = $agg['total_rentals'] ?? 0;
$sumRevenue = $agg['total_revenue'] ?? 0.00;
$avgDays = round($agg['avg_days'] ?? 0, 1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Car Rental Monitoring Report</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="mb-0">Rental Monitoring Report</h3>
            </div>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">Reset Filter</a>
        </div>

        <!-- Filter Card -->
        <div class="card p-3 mb-4">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-auto">
                    <label class="form-label mb-0 fw-semibold">Filter by Vehicle Type:</label>
                </div>
                <div class="col-md-4">
                    <select name="vehicleType" class="form-select" onchange="this.form.submit()">
                        <option value="">-- All Vehicle Types --</option>
                        <?php while($t = $typeResult->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($t['vehicleType']); ?>" <?php echo $filterType === $t['vehicleType'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($t['vehicleType']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary">Filter Records</button>
                </div>
            </form>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="card p-3 mb-3">
                    <span class="text-muted small fw-semibold">Total Rentals</span>
                    <h2 class="text-primary mb-0"><?php echo $count; ?> <small class="text-muted fs-6">Rentals</small></h2>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 mb-3">
                    <span class="text-muted small fw-semibold">Total Fees Collected</span>
                    <h2 class="text-success mb-0">₱<?php echo number_format($sumRevenue, 2); ?></h2>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 mb-3">
                    <span class="text-muted small fw-semibold">Average Rental Duration</span>
                    <h2 class="text-warning mb-0"><?php echo $avgDays; ?> <small class="text-muted fs-6">Days / Trip</small></h2>
                </div>
            </div>
        </div>

        <!-- Table displaying filtered records -->
        <div class="card mb-3">
            <div class="card-header fw-bold bg-white py-3">
                <h5 class="mb-0">
                    Results for: <span class="badge bg-primary"><?php echo $filterType !== '' ? htmlspecialchars($filterType) : 'All Vehicles'; ?></span>
                </h5>
            </div>
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>Vehicle Details</th>
                        <th>Type</th>
                        <th>Customer Full Name</th>
                        <th>Rental Period</th>
                        <th>Duration</th>
                        <th>Fee Paid</th>
                        <th>Payment Mode</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($records && $records->num_rows > 0): ?>
                        <?php while($row = $records->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($row['brandModel']); ?></strong>
                                <small class="text-muted d-block"><?php echo htmlspecialchars($row['plateNumber']); ?></small>
                            </td>
                            <td><span class="badge bg-secondary"><?php echo htmlspecialchars($row['vehicleType']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['custFName'] . ' ' . $row['custLName']); ?></td>
                            <td><?php echo $row['rentalDate']; ?> &rarr; <?php echo $row['returnDate']; ?></td>
                            <td><?php echo $row['totalDays']; ?> days</td>
                            <td><strong class="text-success">₱<?php echo number_format($row['totalFee'], 2); ?></strong></td>
                            <td><span class="badge bg-info text-dark"><?php echo htmlspecialchars($row['paymentMode']); ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">No rental records found matching this filter.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>