<?php
require_once '../database.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
if ($search !== '') {
    $stmt = $conn->prepare("SELECT * FROM customers WHERE custFName LIKE ? OR custLName LIKE ? OR customerType LIKE ? ORDER BY customerID DESC");
    $param = "%$search%";
    $stmt->bind_param("sss", $param, $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM customers ORDER BY customerID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Moviegoers</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Moviegoers Registry</h3>
            <a href="add.php" class="btn btn-primary">+ Add New Moviegoer</a>
        </div>
        <div class="card p-3 mb-3">
            <form method="GET" class="row g-2">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="Search by name or customer type..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-secondary w-100">Search</button>
                </div>
            </form>
        </div>
        <div class="card mb-3">
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Moviegoer Full Name</th>
                        <th>Type / Discount Eligibility</th>
                        <th>Contact Number</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['customerID']; ?></td>
                            <td><strong><?php echo htmlspecialchars($row['custFName'] . ' ' . $row['custLName']); ?></strong></td>
                            <td>
                                <span class="badge <?php echo $row['customerType'] === 'Regular' ? 'bg-secondary' : 'bg-success'; ?>">
                                    <?php echo htmlspecialchars($row['customerType']); ?> (<?php echo $row['customerType'] === 'Regular' ? '0%' : '20% Off'; ?>)
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($row['contactNumber']); ?></td>
                            <td class="text-end">
                                <a href="edit.php?id=<?php echo $row['customerID']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete.php?id=<?php echo $row['customerID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete record?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center py-4 text-muted">No moviegoers found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>