<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = is_string($_POST['title'] ?? null) ? trim($_POST['title']) : '';
$author = is_string($_POST['author'] ?? null) ? trim($_POST['author']) : '';
$genre = is_string($_POST['genre'] ?? null) ? trim($_POST['genre']) : '';
$price = is_string($_POST['price'] ?? null) ? trim($_POST['price']) : '';
$stock = is_string($_POST['stock'] ?? null) ? trim($_POST['stock']) : '';

    $sql = "INSERT INTO books (`title`, `author`, `genre`, `price`, `stock`) VALUES ('" . $conn->real_escape_string($title) . "', '" . $conn->real_escape_string($author) . "', '" . $conn->real_escape_string($genre) . "', '" . $conn->real_escape_string($price) . "', '" . $conn->real_escape_string($stock) . "')";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to add record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Book - Bookstore Sales &amp; Inventory System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Add New Book</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Book Title</label>
                <input type="text" name="title" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Author</label>
                <input type="text" name="author" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Genre</label>
                <select name="genre" class="form-select" required>
                    <option value="Technology">Technology</option>
<option value="Self-Help">Self-Help</option>
<option value="Design">Design</option>
<option value="History">History</option>
<option value="Fiction">Fiction</option>
<option value="Science">Science</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Price (₱)</label>
                <input type="number" step="0.01" name="price" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Stock Quantity</label>
                <input type="number"  name="stock" class="form-control" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Book</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>