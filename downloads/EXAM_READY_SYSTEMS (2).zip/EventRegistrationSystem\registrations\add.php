<?php
require_once '../database.php';
$events = $conn->query("SELECT * FROM events ORDER BY evName ASC");
$parts = $conn->query("SELECT * FROM participants ORDER BY partFName ASC");
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $evCode = (int)($_POST['evCode'] ?? 0);
    $partID = (int)($_POST['partID'] ?? 0);
    $regDate = is_string($_POST['regDate'] ?? null) ? trim($_POST['regDate']) : '';
    $discount = floatval($_POST['discountRate'] ?? 0);
    $pmode = is_string($_POST['paymentMode'] ?? null) ? trim($_POST['paymentMode']) : 'Cash';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : 'Confirmed';

    if ($evCode <= 0 || $partID <= 0 || $regDate === '') {
        $err = 'Please select an event, participant, and registration date.';
    } else {
        $evRowRes = $conn->query("SELECT evRFee FROM events WHERE evCode = $evCode");
        $evRow = $evRowRes ? $evRowRes->fetch_assoc() : null;
        $baseFee = floatval($evRow['evRFee'] ?? 0);
        $finalFee = $baseFee - ($baseFee * ($discount / 100));
        if ($finalFee < 0) $finalFee = 0;

        $sql = "INSERT INTO registrations (`evCode`, `partID`, `regDate`, `discountRate`, `feePaid`, `paymentMode`, `status`) VALUES ('" . $conn->real_escape_string($evCode) . "', '" . $conn->real_escape_string($partID) . "', '" . $conn->real_escape_string($regDate) . "', '" . $conn->real_escape_string($discount) . "', '" . $conn->real_escape_string($finalFee) . "', '" . $conn->real_escape_string($pmode) . "', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Failed to record transaction: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register Participant</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 650px;">
        <div class="card p-4">
            <h4 class="mb-3">Event Registration Form</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Select Event</label>
                    <select name="evCode" id="evCode" class="form-select" required onchange="calculateFee()">
                        <option value="">-- Choose Event --</option>
                        <?php while($e = $events->fetch_assoc()): ?>
                            <option value="<?php echo $e['evCode']; ?>" data-fee="<?php echo $e['evRFee']; ?>">
                                <?php echo htmlspecialchars($e['evName'] . ' - ₱' . number_format($e['evRFee'], 2) . ' (' . $e['evDate'] . ')'); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Select Participant</label>
                    <select name="partID" class="form-select" required>
                        <option value="">-- Choose Attendee --</option>
                        <?php while($p = $parts->fetch_assoc()): ?>
                            <option value="<?php echo $p['partID']; ?>">
                                <?php echo htmlspecialchars($p['partFName'] . ' ' . $p['partLName'] . ' (' . $p['organization'] . ')'); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Registration Date</label>
                        <input type="date" name="regDate" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Discount Rate (%)</label>
                        <input type="number" step="0.01" name="discountRate" id="discountRate" class="form-control" value="0.00" oninput="calculateFee()">
                    </div>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Payment Mode</label>
                        <select name="paymentMode" class="form-select" required>
                            <option value="Cash">Cash (Counter)</option>
                            <option value="GCash">GCash / E-Wallet</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Computed Fee to Pay (₱)</label>
                        <input type="text" id="computedFeeDisplay" class="form-control fw-bold text-success" readonly value="₱0.00">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Registration Status</label>
                    <select name="status" class="form-select" required>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Pending">Pending Payment</option>
                    </select>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Complete Registration</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        function calculateFee() {
            const select = document.getElementById('evCode');
            const opt = select.options[select.selectedIndex];
            const baseFee = opt ? (parseFloat(opt.getAttribute('data-fee')) || 0) : 0;
            const discount = parseFloat(document.getElementById('discountRate').value) || 0;
            let finalFee = baseFee - (baseFee * (discount / 100));
            if (finalFee < 0) finalFee = 0;
            document.getElementById('computedFeeDisplay').value = '₱' + finalFee.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
        }
    </script>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>