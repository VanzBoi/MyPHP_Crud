<?php
if(session_status() === PHP_SESSION_NONE) session_start();

function set_flash($msg, $type='info'){
    $_SESSION['_flash'] = ['msg'=>$msg, 'type'=>$type];
}

function get_flash(){
    if(isset($_SESSION['_flash'])){ $f = $_SESSION['_flash']; unset($_SESSION['_flash']); return $f; }
    return null;
}

function display_flash(){
    $f = get_flash();
    if(!$f) return;
    $type = $f['type'];
    $cls = 'alert-info';
    if($type === 'success') $cls = 'alert-success';
    if($type === 'error') $cls = 'alert-danger';
    echo "<div class=\"container mt-2\"><div class=\"alert {$cls}\" role=\"alert\">".htmlspecialchars($f['msg'])."</div></div>";
}

?>
