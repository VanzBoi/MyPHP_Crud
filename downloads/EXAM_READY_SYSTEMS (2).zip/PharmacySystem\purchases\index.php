﻿<?php
require_once __DIR__ . '/../database.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$where = "1=1";
if ($search !== '') {
    $s = $conn->real_escape_string($search);
    $where .= " AND (e1.medicineName LIKE '%$s%' OR e2.customerName LIKE '%$s%')";
}

$sql = "SELECT t.*, e1.medicineName AS e1_title, e2.customerName AS e2_title 
        FROM purchases t
        JOIN medicines e1 ON t.medicineID = e1.medicineID
        JOIN customers e2 ON t.customerID = e2.customerID
        WHERE $where
        ORDER BY t.purchaseID DESC";
$res = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase List - Pharmacy Inventory and Sales System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="fw-bold mb-0">Purchase Records</h3>
                <small class="text-muted">Transaction Management</small>
            </div>
            <a href="add.php" class="btn btn-warning fw-semibold btn-sm">+ New Purchase</a>
        </div>

        <div class="card mb-4">
            <div class="card-body p-3">
                <form method="GET" class="row g-2">
                    <div class="col-md-10">
                        <input type="text" name="search" class="form-control form-control-sm" placeholder="Search by Medicine or Customer..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-dark btn-sm w-100">Search</button>
                        <?php if ($search !== ''): ?>
                            <a href="index.php" class="btn btn-outline-secondary btn-sm">Reset</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="table table-striped table-bordered align-middle mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Medicine</th>
<th>Customer</th>
<th>Date</th>
<th>Quantity Sold</th>
<th>Total Amount (₱)</th>
<th>Payment Mode</th>

                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($res && $res->num_rows > 0): ?>
                            <?php while ($r = $res->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['purchaseID'] ?></td>
                                    <td><?= htmlspecialchars($r['e1_title'] ?? '') ?></td>
<td><?= htmlspecialchars($r['e2_title'] ?? '') ?></td>
<td><?= htmlspecialchars($r['purchaseDate']) ?></td>
<td><?= htmlspecialchars($r['quantity']) ?></td>
<td>₱<?= number_format($r['totalAmount'], 2) ?></td>
<td><?= htmlspecialchars($r['paymentMode']) ?></td>

                                    <td class="text-end">
                                        <a href="edit.php?id=<?= $r['purchaseID'] ?>" class="btn btn-outline-primary btn-sm py-0 px-2">Edit</a>
                                        <a href="delete.php?id=<?= $r['purchaseID'] ?>" class="btn btn-outline-danger btn-sm py-0 px-2" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="12" class="text-center py-4 text-muted">No transactions recorded yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer class="text-center">
        <div class="container">
            <p class="mb-0">&copy; <?= date('Y') ?> Pharmacy Inventory and Sales System</p>
        </div>
    </footer>
    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>