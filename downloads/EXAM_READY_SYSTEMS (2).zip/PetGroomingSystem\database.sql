CREATE DATABASE IF NOT EXISTS pet_grooming_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pet_grooming_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS services (
  serviceID INT AUTO_INCREMENT PRIMARY KEY,
  serviceName VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  durationMin INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pets (
  petID INT AUTO_INCREMENT PRIMARY KEY,
  petName VARCHAR(100) NOT NULL,
  petType VARCHAR(50) NOT NULL,
  breed VARCHAR(100) NOT NULL,
  ownerName VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS bookings (
  bookingID INT AUTO_INCREMENT PRIMARY KEY,
  serviceID INT NOT NULL,
  petID INT NOT NULL,
  bookingDate DATE NOT NULL,
  totalPrice DECIMAL(10,2) NOT NULL,
  paymentMethod VARCHAR(50) NOT NULL,
  status VARCHAR(50) DEFAULT 'Confirmed',
  FOREIGN KEY (serviceID) REFERENCES services(serviceID) ON DELETE CASCADE,
  FOREIGN KEY (petID) REFERENCES pets(petID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO services (serviceName, category, price, durationMin) VALUES
('Full Bath & Blowdry', 'Bathing', 650.00, 45),
('Complete Haircut & Styling', 'Grooming', 950.00, 60),
('Nail Trimming & Ear Cleaning', 'Spa Care', 450.00, 30),
('Flea & Tick Medic Treatment', 'Medical Spa', 800.00, 50);

INSERT INTO pets (petName, petType, breed, ownerName, contactNumber) VALUES
('Milo', 'Dog', 'Shih Tzu', 'Jasmine Flores', '09173334455'),
('Luna', 'Cat', 'Persian', 'Kevin Tan', '09184445566'),
('Barkley', 'Dog', 'Golden Retriever', 'Andrea Gomez', '09225556677');

INSERT INTO bookings (serviceID, petID, bookingDate, totalPrice, paymentMethod, status) VALUES
(1, 1, '2026-10-25', 650.00, 'Cash', 'Completed'),
(2, 2, '2026-10-26', 950.00, 'GCash', 'Completed'),
(3, 3, '2026-10-27', 450.00, 'Cash', 'Confirmed');

SET FOREIGN_KEY_CHECKS=1;