<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM patients WHERE patientID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patientName = is_string($_POST['patientName'] ?? null) ? trim($_POST['patientName']) : '';
$age = is_string($_POST['age'] ?? null) ? trim($_POST['age']) : '';
$gender = is_string($_POST['gender'] ?? null) ? trim($_POST['gender']) : '';
$contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    $sql = "UPDATE patients SET `patientName` = '" . $conn->real_escape_string($patientName) . "', `age` = '" . $conn->real_escape_string($age) . "', `gender` = '" . $conn->real_escape_string($gender) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "' WHERE patientID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Patient #<?= $id ?> - Dental Clinic Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Patient #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Patient Name</label>
                <input type="text" name="patientName" class="form-control" value="<?= htmlspecialchars($row['patientName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Age</label>
                <input type="number"  name="age" class="form-control" value="<?= htmlspecialchars($row['age'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Gender</label>
                <select name="gender" class="form-select" required>
                    <option value="Male" <?= ($row['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
<option value="Female" <?= ($row['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
<option value="Other" <?= ($row['gender'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Contact Number</label>
                <input type="text" name="contactNumber" class="form-control" value="<?= htmlspecialchars($row['contactNumber'] ?? '') ?>" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>