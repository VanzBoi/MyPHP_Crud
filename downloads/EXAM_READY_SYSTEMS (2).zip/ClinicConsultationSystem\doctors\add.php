<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = is_string($_POST['docFName'] ?? null) ? trim($_POST['docFName']) : '';
    $l = is_string($_POST['docLName'] ?? null) ? trim($_POST['docLName']) : '';
    $addr = is_string($_POST['docAddress'] ?? null) ? trim($_POST['docAddress']) : '';
    $spec = is_string($_POST['docSpecial'] ?? null) ? trim($_POST['docSpecial']) : '';
    $stmt = $mysqli->prepare("INSERT INTO doctors (docFName, docLName, docAddress, docSpecial) VALUES (?,?,?,?)");
    $stmt->bind_param('ssss', $f, $l, $addr, $spec);
    $stmt->execute();
    flash('success', 'Doctor added.');
    redirect('index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Doctor - Clinic Consultation</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
  <h2>Add Doctor</h2>
  <form method="post">
    <div class="mb-2">
      <label>First Name</label>
      <input class="form-control" name="docFName" required>
    </div>
    <div class="mb-2">
      <label>Last Name</label>
      <input class="form-control" name="docLName" required>
    </div>
    <div class="mb-2">
      <label>Address</label>
      <input class="form-control" name="docAddress">
    </div>
    <div class="mb-2">
      <label>Specialization</label>
      <input class="form-control" name="docSpecial">
    </div>
    <button class="btn btn-primary">Save</button>
  </form>
</div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
