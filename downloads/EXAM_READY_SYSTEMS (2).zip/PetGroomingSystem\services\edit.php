<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM services WHERE serviceID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $serviceName = is_string($_POST['serviceName'] ?? null) ? trim($_POST['serviceName']) : '';
$category = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
$price = is_string($_POST['price'] ?? null) ? trim($_POST['price']) : '';
$durationMin = is_string($_POST['durationMin'] ?? null) ? trim($_POST['durationMin']) : '';

    $sql = "UPDATE services SET `serviceName` = '" . $conn->real_escape_string($serviceName) . "', `category` = '" . $conn->real_escape_string($category) . "', `price` = '" . $conn->real_escape_string($price) . "', `durationMin` = '" . $conn->real_escape_string($durationMin) . "' WHERE serviceID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Service #<?= $id ?> - Pet Grooming Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Service #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Service Name</label>
                <input type="text" name="serviceName" class="form-control" value="<?= htmlspecialchars($row['serviceName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Category</label>
                <select name="category" class="form-select" required>
                    <option value="Bathing" <?= ($row['category'] ?? '') === 'Bathing' ? 'selected' : '' ?>>Bathing</option>
<option value="Grooming" <?= ($row['category'] ?? '') === 'Grooming' ? 'selected' : '' ?>>Grooming</option>
<option value="Spa Care" <?= ($row['category'] ?? '') === 'Spa Care' ? 'selected' : '' ?>>Spa Care</option>
<option value="Medical Spa" <?= ($row['category'] ?? '') === 'Medical Spa' ? 'selected' : '' ?>>Medical Spa</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Price (₱)</label>
                <input type="number" step="0.01" name="price" class="form-control" value="<?= htmlspecialchars($row['price'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Duration (Mins)</label>
                <input type="number"  name="durationMin" class="form-control" value="<?= htmlspecialchars($row['durationMin'] ?? '') ?>" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>