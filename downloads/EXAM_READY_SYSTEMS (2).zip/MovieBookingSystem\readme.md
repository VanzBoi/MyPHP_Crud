﻿# Cinema Movie Booking System

A simple PHP and MySQL web application for managing movies, customers, and bookings.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\MovieBookingSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/MovieBookingSystem/
4. The database `movie_booking_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Movies**: Add, view, edit, and delete movies records.
- **Customers**: Add, view, edit, and delete customers records.
- **Bookings**: Manage bookings transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
