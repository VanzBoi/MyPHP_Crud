﻿# Student Academic Records & Grading System

A simple PHP and MySQL web application for managing courses, students, and grades.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\StudentRecordsSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/StudentRecordsSystem/
4. The database `student_records_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Courses**: Add, view, edit, and delete courses records.
- **Students**: Add, view, edit, and delete students records.
- **Grades**: Manage grades transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
