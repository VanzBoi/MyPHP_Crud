<?php
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/helpers.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gym Membership System</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/navbar.php'; ?>
    <div class="container">
        <div class="page-heading mb-4">
            <h1>Gym Membership Management System</h1>
            <p class="text-muted">Manage gym member profiles, packages, active memberships, and analytics.</p>
        </div>

        <div class="card mb-3">
            <div class="card-header fw-bold">System Navigation</div>
            <div class="card-body">
                <div class="list-group">
                    <a href="<?php echo $baseUrl; ?>members/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Members Management</span> <span class="text-muted">&rarr;</span></a>
                    <a href="<?php echo $baseUrl; ?>packages/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Packages Management</span> <span class="text-muted">&rarr;</span></a>
                    <a href="<?php echo $baseUrl; ?>memberships/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Memberships Management</span> <span class="text-muted">&rarr;</span></a>
                    <a href="<?php echo $baseUrl; ?>monitoring/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Monitoring & Reports</span> <span class="badge bg-primary">Monitoring</span></a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
