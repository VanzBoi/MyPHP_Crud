<?php
// Global navigation bar
$cur = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= $baseUrl ?>index.php">Repair Service Management System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (strpos($cur, '/index.php') !== false && strpos($cur, '/technicians') === false && strpos($cur, '/appliances') === false && strpos($cur, '/repairs') === false && strpos($cur, '/monitoring') === false) ? 'active' : '' ?>" href="<?= $baseUrl ?>index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/technicians/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>technicians/index.php">Technician</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/appliances/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>appliances/index.php">Device/Appliance</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/repairs/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>repairs/index.php">Repair Job</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/monitoring/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>