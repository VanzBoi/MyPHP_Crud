﻿<?php
require_once '../database.php';

$deptFilter = intval($_GET['deptID'] ?? 0);
$where = ($deptFilter > 0) ? "WHERE d.deptID = $deptFilter" : "";

$depts = $conn->query("SELECT * FROM departments ORDER BY deptCode ASC");

$totalAthletes = $conn->query("SELECT COUNT(*) FROM athletes a JOIN departments d ON a.deptID = d.deptID $where")->fetch_row()[0];
$totalMatches = $conn->query("SELECT COUNT(*) FROM tournaments t JOIN athletes a ON t.athleteID = a.athleteID JOIN departments d ON a.deptID = d.deptID $where")->fetch_row()[0];
$totalFees = $conn->query("SELECT IFNULL(SUM(t.regFee), 0) FROM tournaments t JOIN athletes a ON t.athleteID = a.athleteID JOIN departments d ON a.deptID = d.deptID $where")->fetch_row()[0];
$totalWinners = $conn->query("SELECT COUNT(*) FROM tournaments t JOIN athletes a ON t.athleteID = a.athleteID JOIN departments d ON a.deptID = d.deptID " . (($deptFilter > 0) ? "$where AND t.matchStatus = 'Winner'" : "WHERE t.matchStatus = 'Winner'"))->fetch_row()[0];

$query = "SELECT d.deptCode, d.deptName, COUNT(DISTINCT a.athleteID) AS totalAthletes, COUNT(t.tournamentID) AS totalEntries, IFNULL(SUM(t.regFee), 0) AS totalFees, SUM(CASE WHEN t.matchStatus = 'Winner' THEN 1 ELSE 0 END) AS totalWins FROM departments d LEFT JOIN athletes a ON d.deptID = a.deptID LEFT JOIN tournaments t ON a.athleteID = t.athleteID " . (($deptFilter > 0) ? "WHERE d.deptID = $deptFilter" : "") . " GROUP BY d.deptID ORDER BY totalWins DESC, totalAthletes DESC";
$report = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Intramurals Monitoring & Standings</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <h3 class="mb-3">Tournament Monitoring & College Standing</h3>

        <div class="card p-3 mb-4">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-md-9">
                    <select name="deptID" class="form-select">
                        <option value="0">-- All Colleges & Departments (Overall) --</option>
                        <?php while($d = $depts->fetch_assoc()): ?>
                            <option value="<?php echo $d['deptID']; ?>" <?php echo ($d['deptID'] == $deptFilter) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($d['deptCode'] . ' - ' . $d['deptName']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Filter Standing</button>
                    <?php if ($deptFilter > 0): ?>
                        <a href="index.php" class="btn btn-outline-secondary">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Registered Athletes</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalAthletes; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Tournament Registrations</span>
                    <h3 class="mb-0 text-dark"><?php echo $totalMatches; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Victory Matches Won</span>
                    <h3 class="mb-0 text-warning"><?php echo $totalWinners; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Total Fees Collected</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalFees, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="card p-0">
            <div class="card-header fw-bold">College Department Standing Table</div>
            <table class="table table-bordered table-striped mb-0">
                <thead>
                    <tr>
                        <th>College</th>
                        <th>Department Full Name</th>
                        <th>Official Athletes</th>
                        <th>Match Entries</th>
                        <th>Matches Won</th>
                        <th>Total Fees (₱)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($report && $report->num_rows > 0): ?>
                        <?php while($r = $report->fetch_assoc()): ?>
                        <tr>
                            <td><span class="badge bg-primary"><?php echo htmlspecialchars($r['deptCode']); ?></span></td>
                            <td><strong><?php echo htmlspecialchars($r['deptName']); ?></strong></td>
                            <td><?php echo $r['totalAthletes']; ?></td>
                            <td><?php echo $r['totalEntries']; ?></td>
                            <td><span class="badge bg-warning text-dark"><?php echo $r['totalWins']; ?> wins</span></td>
                            <td class="text-success fw-bold">₱<?php echo number_format($r['totalFees'], 2); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center py-4 text-muted">No standing data available.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>