<?php
require_once '../database.php';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}
$res = $conn->query("SELECT * FROM tournaments WHERE tournamentID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$tour = $res->fetch_assoc();
$athletes = $conn->query("SELECT a.*, d.deptCode FROM athletes a JOIN departments d ON a.deptID = d.deptID ORDER BY a.fullName ASC");
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $athID = (int)($_POST['athleteID'] ?? 0);
    $sport = is_string($_POST['sportEvent'] ?? null) ? trim($_POST['sportEvent']) : '';
    $cat = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
    $bracket = is_string($_POST['bracket'] ?? null) ? trim($_POST['bracket']) : '';
    $date = is_string($_POST['matchDate'] ?? null) ? trim($_POST['matchDate']) : '';
    $fee = floatval($_POST['regFee'] ?? 0);
    $status = is_string($_POST['matchStatus'] ?? null) ? trim($_POST['matchStatus']) : 'Scheduled';

    if ($athID <= 0 || $sport === '' || $date === '') {
        $err = 'Please complete all required fields.';
    } else {
        $sql = "UPDATE tournaments SET `athleteID` = '" . $conn->real_escape_string($athID) . "', `sportEvent` = '" . $conn->real_escape_string($sport) . "', `category` = '" . $conn->real_escape_string($cat) . "', `bracket` = '" . $conn->real_escape_string($bracket) . "', `matchDate` = '" . $conn->real_escape_string($date) . "', `regFee` = '" . $conn->real_escape_string($fee) . "', `matchStatus` = '" . $conn->real_escape_string($status) . "' WHERE tournamentID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Failed to update transaction: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Tournament Match</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 650px;">
        <div class="card p-4">
            <h4 class="mb-3">Edit Tournament Registration</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Athlete</label>
                    <select name="athleteID" class="form-select" required>
                        <?php while($a = $athletes->fetch_assoc()): ?>
                            <option value="<?php echo $a['athleteID']; ?>" <?php echo ($a['athleteID'] == $tour['athleteID']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($a['fullName'] . ' (' . $a['deptCode'] . ' - ' . $a['studentID'] . ')'); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Sport / Event</label>
                        <input type="text" name="sportEvent" class="form-control" required value="<?php echo htmlspecialchars($tour['sportEvent']); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Category Division</label>
                        <select name="category" class="form-select" required>
                            <option value="Men Division" <?php echo ($tour['category'] === 'Men Division') ? 'selected' : ''; ?>>Men Division</option>
                            <option value="Women Division" <?php echo ($tour['category'] === 'Women Division') ? 'selected' : ''; ?>>Women Division</option>
                            <option value="Mixed Team" <?php echo ($tour['category'] === 'Mixed Team') ? 'selected' : ''; ?>>Mixed Team</option>
                        </select>
                    </div>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Tournament Bracket</label>
                        <select name="bracket" class="form-select" required>
                            <option value="Eliminations" <?php echo ($tour['bracket'] === 'Eliminations') ? 'selected' : ''; ?>>Eliminations</option>
                            <option value="Quarterfinals" <?php echo ($tour['bracket'] === 'Quarterfinals') ? 'selected' : ''; ?>>Quarterfinals</option>
                            <option value="Semifinals" <?php echo ($tour['bracket'] === 'Semifinals') ? 'selected' : ''; ?>>Semifinals</option>
                            <option value="Finals / Championship" <?php echo ($tour['bracket'] === 'Finals / Championship') ? 'selected' : ''; ?>>Finals / Championship</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Match Schedule</label>
                        <input type="date" name="matchDate" class="form-control" value="<?php echo $tour['matchDate']; ?>" required>
                    </div>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Registration Fee (₱)</label>
                        <input type="number" step="0.01" name="regFee" class="form-control" value="<?php echo $tour['regFee']; ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Status</label>
                        <select name="matchStatus" class="form-select" required>
                            <option value="Scheduled" <?php echo ($tour['matchStatus'] === 'Scheduled') ? 'selected' : ''; ?>>Scheduled</option>
                            <option value="In Progress" <?php echo ($tour['matchStatus'] === 'In Progress') ? 'selected' : ''; ?>>In Progress</option>
                            <option value="Winner" <?php echo ($tour['matchStatus'] === 'Winner') ? 'selected' : ''; ?>>Winner</option>
                            <option value="Eliminated" <?php echo ($tour['matchStatus'] === 'Eliminated') ? 'selected' : ''; ?>>Eliminated</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Entry</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>