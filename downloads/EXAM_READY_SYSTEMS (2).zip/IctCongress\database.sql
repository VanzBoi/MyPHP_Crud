CREATE DATABASE IF NOT EXISTS congress_system_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE congress_system_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS workshops (
  workshopID INT AUTO_INCREMENT PRIMARY KEY,
  workshopTitle VARCHAR(100) NOT NULL,
  speakerName VARCHAR(100) NOT NULL,
  venueRoom VARCHAR(100) NOT NULL,
  registrationFee DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS participants (
  participantID INT AUTO_INCREMENT PRIMARY KEY,
  fullName VARCHAR(100) NOT NULL,
  campus VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS registrations (
  registrationID INT AUTO_INCREMENT PRIMARY KEY,
  workshopID INT NOT NULL,
  participantID INT NOT NULL,
  registrationDate DATE NOT NULL,
  amountPaid DECIMAL(10,2) NOT NULL,
  paymentStatus VARCHAR(50) DEFAULT 'Paid',
  attendanceStatus VARCHAR(50) DEFAULT 'Registered',
  FOREIGN KEY (workshopID) REFERENCES workshops(workshopID) ON DELETE CASCADE,
  FOREIGN KEY (participantID) REFERENCES participants(participantID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO workshops (workshopTitle, speakerName, venueRoom, registrationFee) VALUES
('AI & Machine Learning in Web Development', 'Dr. Arvin Santos', 'Audio-Visual Hall A', 500.00),
('Cloud Cybersecurity Fundamentals', 'Engr. Cynthia Diaz', 'Plenary Hall', 600.00),
('Modern Full-Stack Engineering', 'Prof. Leo Manabat', 'Computer Lab 3', 450.00),
('UI/UX Design Systems Workshop', 'Ms. Hannah Tan', 'Multimedia Studio', 400.00);

INSERT INTO participants (fullName, campus, email, contactNumber) VALUES
('Francis Magalona', 'UC-Main', 'fmagalona@gmail.com', '09171114422'),
('Ely Buendia', 'UC-Banilad', 'ebuendia@yahoo.com', '09182225533'),
('Rico Blanco', 'UC-LM', 'rblanco@outlook.com', '09223336644');

INSERT INTO registrations (workshopID, participantID, registrationDate, amountPaid, paymentStatus, attendanceStatus) VALUES
(1, 1, '2026-10-25', 500.00, 'Paid', 'Present'),
(2, 2, '2026-10-26', 600.00, 'Paid', 'Present'),
(3, 3, '2026-10-27', 450.00, 'Paid', 'Registered');

SET FOREIGN_KEY_CHECKS=1;