<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    redirect('index.php');
}

$res = $conn->query("SELECT * FROM memberships WHERE membershipID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    redirect('index.php');
}
$membership = $res->fetch_assoc();

$members = $conn->query('SELECT memberID, fName, lName, discount FROM members ORDER BY fName, lName');
$packages = $conn->query('SELECT packageID, packageName, fee, duration FROM packages ORDER BY packageName');

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $memberID = (int)($_POST['memberID'] ?? 0);
    $packageID = (int)($_POST['packageID'] ?? 0);
    $startDate = is_string($_POST['startDate'] ?? null) ? trim($_POST['startDate']) : '';
    $endDate = is_string($_POST['endDate'] ?? null) ? trim($_POST['endDate']) : '';
    $amountPaid = floatval($_POST['amountPaid'] ?? 0);
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : 'Active';

    if ($memberID <= 0 || $packageID <= 0 || $startDate === '' || $endDate === '' || $amountPaid <= 0) {
        $errors[] = 'Please select a member, package, and enter valid amounts.';
    }

    if (!$errors) {
        $memberRes = $conn->query("SELECT discount FROM members WHERE memberID = $memberID");
        $member = $memberRes ? $memberRes->fetch_assoc() : null;

        $packageRes = $conn->query("SELECT fee FROM packages WHERE packageID = $packageID");
        $package = $packageRes ? $packageRes->fetch_assoc() : null;

        $discountRate = $member ? floatval($member['discount']) : 0;
        $fee = $package ? floatval($package['fee']) : 0;
        $discountAmount = round($fee * $discountRate, 2);
        $netAmount = round($amountPaid - $discountAmount, 2);

        $sql = "UPDATE memberships SET `memberID` = '" . $conn->real_escape_string($memberID) . "', `packageID` = '" . $conn->real_escape_string($packageID) . "', `startDate` = '" . $conn->real_escape_string($startDate) . "', `endDate` = '" . $conn->real_escape_string($endDate) . "', `amountPaid` = '" . $conn->real_escape_string($amountPaid) . "', `discountAmount` = '" . $conn->real_escape_string($discountAmount) . "', `netAmount` = '" . $conn->real_escape_string($netAmount) . "', `status` = '" . $conn->real_escape_string($status) . "' WHERE membershipID = $id";
        if ($conn->query($sql)) {
            flash('Membership updated successfully.');
            redirect('index.php');
        } else {
            $errors[] = 'Failed to update transaction: ' . $conn->error;
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Membership - Gym Membership</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>
    <div class="container">
        <div class="py-3">
            <h2>Edit Membership</h2>
            <?php if ($errors): ?>
                <div class="alert alert-danger"><ul><?php foreach ($errors as $error): ?><li><?php echo escape($error); ?></li><?php endforeach; ?></ul></div>
            <?php endif; ?>
            <form method="post" action="edit.php?id=<?php echo escape($id); ?>">
                <div class="row g-3 mb-3">
                    <div class="col-md-6"><label class="form-label">Member</label><select name="memberID" class="form-select"><option value="">Select Member</option><?php while ($member = mysqli_fetch_assoc($members)): ?><option value="<?php echo escape($member['memberID']); ?>" data-discount="<?php echo escape($member['discount']); ?>" <?php echo (((int)($_POST['memberID'] ?? $membership['memberID'])) === (int)$member['memberID']) ? 'selected' : ''; ?>><?php echo escape($member['fName'] . ' ' . $member['lName']); ?></option><?php endwhile; ?></select></div>
                    <div class="col-md-6"><label class="form-label">Package</label><select name="packageID" class="form-select"><option value="">Select Package</option><?php mysqli_data_seek($packages, 0); while ($package = mysqli_fetch_assoc($packages)): ?><option value="<?php echo escape($package['packageID']); ?>" data-fee="<?php echo escape($package['fee']); ?>" <?php echo (((int)($_POST['packageID'] ?? $membership['packageID'])) === (int)$package['packageID']) ? 'selected' : ''; ?>><?php echo escape($package['packageName']); ?></option><?php endwhile; ?></select></div>
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-md-4"><label class="form-label">Start Date</label><input type="date" name="startDate" class="form-control" value="<?php echo escape($_POST['startDate'] ?? $membership['startDate']); ?>"></div>
                    <div class="col-md-4"><label class="form-label">End Date</label><input type="date" name="endDate" class="form-control" value="<?php echo escape($_POST['endDate'] ?? $membership['endDate']); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Amount Paid</label><input type="number" step="0.01" name="amountPaid" class="form-control" value="<?php echo escape($_POST['amountPaid'] ?? $membership['amountPaid']); ?>"></div>
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-md-4"><label class="form-label">Discount Amount</label><input type="number" step="0.01" name="discountAmount" class="form-control" value="<?php echo escape($_POST['discountAmount'] ?? $membership['discountAmount']); ?>" readonly></div>
                    <div class="col-md-4"><label class="form-label">Net Amount</label><input type="number" step="0.01" name="netAmount" class="form-control" value="<?php echo escape($_POST['netAmount'] ?? $membership['netAmount']); ?>" readonly></div>
                    <div class="col-md-4"><label class="form-label">Status</label><select name="status" class="form-select"><option value="Active" <?php echo ((($_POST['status'] ?? $membership['status']) === 'Active') ? 'selected' : ''); ?>>Active</option><option value="Expired" <?php echo ((($_POST['status'] ?? $membership['status']) === 'Expired') ? 'selected' : ''); ?>>Expired</option></select></div>
                </div>
                <div class="mb-3">
                    <button type="button" class="btn btn-outline-secondary" id="calculateButton">Recalculate Discount / Net</button>
                </div>
                <div><button type="submit" class="btn btn-primary">Update Membership</button> <a href="index.php" class="btn btn-secondary">Cancel</a></div>
            </form>
        </div>
    </div>
    <script>
        const memberOptions = Array.from(document.querySelectorAll('select[name="memberID"] option')).slice(1).map(option => ({id: option.value, discount: parseFloat(option.dataset.discount || '0')}));
        const packageOptions = Array.from(document.querySelectorAll('select[name="packageID"] option')).slice(1).map(option => ({id: option.value, fee: parseFloat(option.dataset.fee || '0')}));
        const memberSelect = document.querySelector('select[name="memberID"]');
        const packageSelect = document.querySelector('select[name="packageID"]');
        const amountPaidInput = document.querySelector('input[name="amountPaid"]');
        const discountInput = document.querySelector('input[name="discountAmount"]');
        const netInput = document.querySelector('input[name="netAmount"]');
        const calculateButton = document.getElementById('calculateButton');

        calculateButton.addEventListener('click', () => {
            const member = memberOptions.find(m => m.id === memberSelect.value);
            const packageInfo = packageOptions.find(p => p.id === packageSelect.value);
            const amountPaid = parseFloat(amountPaidInput.value) || 0;
            if (!member || !packageInfo || amountPaid <= 0) {
                alert('Select member/package and enter amount paid before calculating.');
                return;
            }
            const discountAmount = (packageInfo.fee * member.discount).toFixed(2);
            discountInput.value = discountAmount;
            netInput.value = (amountPaid - discountAmount).toFixed(2);
        });
    </script>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
