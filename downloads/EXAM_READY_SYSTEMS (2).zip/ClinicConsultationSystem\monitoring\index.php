<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';

$doctors = $mysqli->query("SELECT docID, docFName, docLName, docSpecial FROM doctors ORDER BY docLName");
$patients = $mysqli->query("SELECT patID, patFName, patLName FROM patients ORDER BY patLName");

$results = null;
$count = 0;
if ($_SERVER['REQUEST_METHOD'] === 'GET' && (!empty($_GET['action']))) {
    $where = [];
    $params = [];
    $types = '';
    if (!empty($_GET['docID']) && !is_array($_GET['docID'])) { $where[] = 'c.docID = ?'; $params[] = (int)$_GET['docID']; $types .= 'i'; }
    if (!empty($_GET['patID']) && !is_array($_GET['patID'])) { $where[] = 'c.patID = ?'; $params[] = (int)$_GET['patID']; $types .= 'i'; }
    $docSpecial = is_string($_GET['docSpecial'] ?? null) ? trim($_GET['docSpecial']) : '';
    if ($docSpecial !== '') { $where[] = 'd.docSpecial LIKE ?'; $params[] = '%'.$docSpecial.'%'; $types .= 's'; }
    $from = is_string($_GET['from'] ?? null) ? trim($_GET['from']) : '';
    $to = is_string($_GET['to'] ?? null) ? trim($_GET['to']) : '';
    if ($from !== '' && $to !== '') { $where[] = 'c.consulDate BETWEEN ? AND ?'; $params[] = $from; $params[] = $to; $types .= 'ss'; }
    $sql = 'SELECT COUNT(*) as total FROM consultations c JOIN doctors d ON c.docID=d.docID';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $stmt = $mysqli->prepare($sql);
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $results = $stmt->get_result()->fetch_assoc();
    $count = $results['total'] ?? 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Monitoring & Inquiry - Clinic Consultation</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
  <div class="mb-3">
    <h1>Monitoring & Inquiry</h1>
    <small class="text-muted">Inquire consultation statistics by attending physician, patient, and date range</small>
  </div>

  <div class="card mb-4">
    <div class="card-header fw-bold">Consultation Inquiry & Statistics</div>
    <div class="card-body">
      <form method="get" class="row g-3 mb-4">
      <div class="col-md-3">
        <label class="form-label fw-bold">Doctor:</label>
        <select class="form-select" name="docID">
          <option value="">-- All Doctors --</option>
          <?php while($d = $doctors->fetch_assoc()): ?>
            <option value="<?php echo $d['docID']; ?>"><?php echo e($d['docFName'].' '.$d['docLName'].' ('.$d['docSpecial'].')'); ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label fw-bold">Patient:</label>
        <select class="form-select" name="patID">
          <option value="">-- All Patients --</option>
          <?php while($p = $patients->fetch_assoc()): ?>
            <option value="<?php echo $p['patID']; ?>"><?php echo e($p['patFName'].' '.$p['patLName']); ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label fw-bold">Doctor Specialty:</label>
        <input class="form-control" name="docSpecial" placeholder="e.g. Cardiology">
      </div>
      <div class="col-md-3">
        <label class="form-label fw-bold">From Date:</label>
        <input class="form-control" type="date" name="from">
      </div>
      <div class="col-md-3">
        <label class="form-label fw-bold">To Date:</label>
        <input class="form-control" type="date" name="to">
      </div>
      <div class="col-md-3 align-self-end">
        <input type="hidden" name="action" value="count">
        <button class="btn btn-primary">Filter Records</button>
        <a href="index.php" class="btn btn-outline-secondary ms-1">Reset</a>
      </div>
    </form>

    <?php if ($results !== null): ?>
      <div class="row g-3 mt-2">
        <div class="col-md-4">
          <div class="">
            <div class="stat-val"><?php echo e($count); ?></div>
            <div class="stat-label">Matching Consultations</div>
          </div>
        </div>
      </div>
    <?php endif; ?>
    </div>
  </div>
</div>
<script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
