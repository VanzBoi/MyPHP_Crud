<?php
require_once '../database.php';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}
$res = $conn->query("SELECT * FROM registrations WHERE regID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$reg = $res->fetch_assoc();
$events = $conn->query("SELECT * FROM events ORDER BY evName ASC");
$parts = $conn->query("SELECT * FROM participants ORDER BY partFName ASC");
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $evCode = (int)($_POST['evCode'] ?? 0);
    $partID = (int)($_POST['partID'] ?? 0);
    $regDate = is_string($_POST['regDate'] ?? null) ? trim($_POST['regDate']) : '';
    $discount = floatval($_POST['discountRate'] ?? 0);
    $pmode = is_string($_POST['paymentMode'] ?? null) ? trim($_POST['paymentMode']) : 'Cash';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : 'Confirmed';

    if ($evCode <= 0 || $partID <= 0 || $regDate === '') {
        $err = 'Please select an event, participant, and registration date.';
    } else {
        $evRowRes = $conn->query("SELECT evRFee FROM events WHERE evCode = $evCode");
        $evRow = $evRowRes ? $evRowRes->fetch_assoc() : null;
        $baseFee = floatval($evRow['evRFee'] ?? 0);
        $finalFee = $baseFee - ($baseFee * ($discount / 100));
        if ($finalFee < 0) $finalFee = 0;

        $sql = "UPDATE registrations SET `evCode` = '" . $conn->real_escape_string($evCode) . "', `partID` = '" . $conn->real_escape_string($partID) . "', `regDate` = '" . $conn->real_escape_string($regDate) . "', `discountRate` = '" . $conn->real_escape_string($discount) . "', `feePaid` = '" . $conn->real_escape_string($finalFee) . "', `paymentMode` = '" . $conn->real_escape_string($pmode) . "', `status` = '" . $conn->real_escape_string($status) . "' WHERE regID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Failed to update transaction: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Registration</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 650px;">
        <div class="card p-4">
            <h4 class="mb-3">Edit Registration Slip</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Event</label>
                    <select name="evCode" id="evCode" class="form-select" required onchange="calculateFee()">
                        <?php while($e = $events->fetch_assoc()): ?>
                            <option value="<?php echo $e['evCode']; ?>" data-fee="<?php echo $e['evRFee']; ?>" <?php echo ($e['evCode'] == $reg['evCode']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($e['evName'] . ' - ₱' . number_format($e['evRFee'], 2)); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Participant</label>
                    <select name="partID" class="form-select" required>
                        <?php while($p = $parts->fetch_assoc()): ?>
                            <option value="<?php echo $p['partID']; ?>" <?php echo ($p['partID'] == $reg['partID']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($p['partFName'] . ' ' . $p['partLName'] . ' (' . $p['organization'] . ')'); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Registration Date</label>
                        <input type="date" name="regDate" class="form-control" value="<?php echo $reg['regDate']; ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Discount Rate (%)</label>
                        <input type="number" step="0.01" name="discountRate" id="discountRate" class="form-control" value="<?php echo $reg['discountRate']; ?>" oninput="calculateFee()">
                    </div>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Payment Mode</label>
                        <select name="paymentMode" class="form-select" required>
                            <option value="Cash" <?php echo ($reg['paymentMode'] === 'Cash') ? 'selected' : ''; ?>>Cash (Counter)</option>
                            <option value="GCash" <?php echo ($reg['paymentMode'] === 'GCash') ? 'selected' : ''; ?>>GCash / E-Wallet</option>
                            <option value="Bank Transfer" <?php echo ($reg['paymentMode'] === 'Bank Transfer') ? 'selected' : ''; ?>>Bank Transfer</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Fee Paid (₱)</label>
                        <input type="text" id="computedFeeDisplay" class="form-control fw-bold text-success" readonly value="₱<?php echo number_format($reg['feePaid'], 2); ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Registration Status</label>
                    <select name="status" class="form-select" required>
                        <option value="Confirmed" <?php echo ($reg['status'] === 'Confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                        <option value="Pending" <?php echo ($reg['status'] === 'Pending') ? 'selected' : ''; ?>>Pending Payment</option>
                    </select>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Registration</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        function calculateFee() {
            const select = document.getElementById('evCode');
            const opt = select.options[select.selectedIndex];
            const baseFee = opt ? (parseFloat(opt.getAttribute('data-fee')) || 0) : 0;
            const discount = parseFloat(document.getElementById('discountRate').value) || 0;
            let finalFee = baseFee - (baseFee * (discount / 100));
            if (finalFee < 0) finalFee = 0;
            document.getElementById('computedFeeDisplay').value = '₱' + finalFee.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
        }
    </script>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>