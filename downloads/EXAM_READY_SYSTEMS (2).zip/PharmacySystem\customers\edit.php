<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM customers WHERE customerID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = is_string($_POST['customerName'] ?? null) ? trim($_POST['customerName']) : '';
$contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';
$customerType = is_string($_POST['customerType'] ?? null) ? trim($_POST['customerType']) : '';

    $sql = "UPDATE customers SET `customerName` = '" . $conn->real_escape_string($customerName) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "', `customerType` = '" . $conn->real_escape_string($customerType) . "' WHERE customerID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Customer #<?= $id ?> - Pharmacy Inventory and Sales System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Customer #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Customer Name</label>
                <input type="text" name="customerName" class="form-control" value="<?= htmlspecialchars($row['customerName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Contact Number</label>
                <input type="text" name="contactNumber" class="form-control" value="<?= htmlspecialchars($row['contactNumber'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Customer Type</label>
                <select name="customerType" class="form-select" required>
                    <option value="Regular" <?= ($row['customerType'] ?? '') === 'Regular' ? 'selected' : '' ?>>Regular</option>
<option value="Senior Citizen" <?= ($row['customerType'] ?? '') === 'Senior Citizen' ? 'selected' : '' ?>>Senior Citizen</option>
<option value="PWD" <?= ($row['customerType'] ?? '') === 'PWD' ? 'selected' : '' ?>>PWD</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>