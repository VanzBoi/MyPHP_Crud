<?php
require_once '../database.php';
$msg = '';

$services = $conn->query("SELECT * FROM services ORDER BY serviceName ASC");
$customers = $conn->query("SELECT * FROM customers ORDER BY custLName ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $servID = (int)($_POST['serviceID'] ?? 0);
    $custID = (int)($_POST['customerID'] ?? 0);
    $oDate = is_string($_POST['orderDate'] ?? null) ? trim($_POST['orderDate']) : '';
    $weight = (float)($_POST['weightKilos'] ?? 0);
    $status = is_string($_POST['orderStatus'] ?? null) ? trim($_POST['orderStatus']) : '';

    // Fetch price per kilo
    $sRow = $conn->query("SELECT pricePerKilo FROM services WHERE serviceID = $servID")->fetch_assoc();
    $rate = $sRow ? floatval($sRow['pricePerKilo']) : 0;
    $totalAmount = $weight * $rate;

    if ($servID > 0 && $custID > 0 && $weight > 0) {
        $sql = "INSERT INTO laundry_orders (serviceID, customerID, orderDate, weightKilos, totalAmount, orderStatus) VALUES ($servID, $custID, '" . $conn->real_escape_string($oDate) . "', $weight, $totalAmount, '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php?msg=saved");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Failed to record transaction: " . htmlspecialchars($conn->error) . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New Laundry Order</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 650px;">
        <div class="card p-4 mb-3">
            <h4>Accept Laundry Order</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Select Service</label>
                    <select name="serviceID" class="form-select" required>
                        <option value="">-- Choose Service --</option>
                        <?php while($s = $services->fetch_assoc()): ?>
                        <option value="<?php echo $s['serviceID']; ?>">
                            <?php echo htmlspecialchars($s['serviceName'] . ' (' . $s['serviceType'] . ') - ₱' . number_format($s['pricePerKilo'], 2) . '/kg'); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Select Customer</label>
                    <select name="customerID" class="form-select" required>
                        <option value="">-- Choose Customer --</option>
                        <?php while($c = $customers->fetch_assoc()): ?>
                        <option value="<?php echo $c['customerID']; ?>">
                            <?php echo htmlspecialchars($c['custLName'] . ', ' . $c['custFName'] . ' (' . $c['contactNumber'] . ')'); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Order Date</label>
                        <input type="date" name="orderDate" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Weight in Kilograms (kg)</label>
                        <input type="number" step="0.01" name="weightKilos" class="form-control" required placeholder="5.5">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Order Status</label>
                    <select name="orderStatus" class="form-select">
                        <option value="Pending">Pending</option>
                        <option value="Processing">Processing</option>
                        <option value="Ready">Ready for Pickup</option>
                        <option value="Claimed">Claimed</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100">Submit Laundry Order</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to Orders</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>