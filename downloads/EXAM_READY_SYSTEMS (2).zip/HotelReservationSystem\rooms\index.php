<?php include '../database.php'; ?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Rooms Management</title>
      <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
  </head>
  <body>
    <?php include '../navbar.php'; ?>
    <div class="container">
      <div class="mb-3">
        <h1>Rooms Inventory</h1>
        <small class="text-muted">Manage available rooms, types, and rates</small>
      </div>

      <div class="card mb-4"><div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <a class="btn btn-primary" href="add.php">+ Add New Room</a>
          <?php
          $search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
          $query = "SELECT * FROM rooms";
          if ($search) {
              $safeSearch = mysqli_real_escape_string($conn, $search);
              $query .= " WHERE roomNo LIKE '%$safeSearch%' OR roomType LIKE '%$safeSearch%'";
          }
          $query .= " ORDER BY roomID DESC";
          $res = mysqli_query($conn, $query);
          ?>
          <form method="get" class="d-flex gap-2" style="max-width: 320px;">
            <input type="text" name="search" class="form-control" placeholder="Search room no or type..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn btn-primary">Search</button>
            <?php if ($search): ?>
              <a href="index.php" class="btn btn-outline-secondary">Clear</a>
            <?php endif; ?>
          </form>
        </div>

        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Room No</th>
              <th>Room Type</th>
              <th>Rate / Night</th>
              <th>Status</th>
              <th style="width: 140px;">Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php if ($res && mysqli_num_rows($res) > 0): ?>
            <?php while($r = mysqli_fetch_assoc($res)): ?>
              <tr>
                <td><?= $r['roomID'] ?></td>
                <td><strong><?= htmlspecialchars($r['roomNo']) ?></strong></td>
                <td><span class="badge bg-info text-dark"><?= htmlspecialchars($r['roomType']) ?></span></td>
                <td>₱<?= number_format($r['price'], 2) ?></td>
                <td>
                  <?php if ($r['status'] === 'Available'): ?>
                    <span class="badge bg-success">Available</span>
                  <?php else: ?>
                    <span class="badge bg-secondary"><?= htmlspecialchars($r['status']) ?></span>
                  <?php endif; ?>
                </td>
                <td>
                  <a class="btn btn-sm btn-warning" href="edit.php?id=<?= $r['roomID'] ?>">Edit</a>
                  <a class="btn btn-sm btn-danger ms-1" href="delete.php?id=<?= $r['roomID'] ?>" onclick="return confirm('Delete this room?')">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="6" class="text-center text-muted py-3">No rooms found.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
      </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
  </body>
</html>
