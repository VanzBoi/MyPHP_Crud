<?php
require_once '../database.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
if ($search !== '') {
    $stmt = $conn->prepare("SELECT t.*, a.fullName, a.studentID, d.deptCode FROM tournaments t JOIN athletes a ON t.athleteID = a.athleteID JOIN departments d ON a.deptID = d.deptID WHERE a.fullName LIKE ? OR t.sportEvent LIKE ? OR d.deptCode LIKE ? OR t.bracket LIKE ? ORDER BY t.tournamentID DESC");
    $param = "%$search%";
    $stmt->bind_param("ssss", $param, $param, $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT t.*, a.fullName, a.studentID, d.deptCode FROM tournaments t JOIN athletes a ON t.athleteID = a.athleteID JOIN departments d ON a.deptID = d.deptID ORDER BY t.tournamentID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tournament Matches</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Tournament Registrations & Brackets</h3>
            <a href="add.php" class="btn btn-primary">+ Register Athlete to Match</a>
        </div>
        <div class="card p-3 mb-3">
            <form method="GET" class="row g-2">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="Search by athlete name, sport event, college or bracket..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Search</button>
                    <?php if ($search !== ''): ?>
                        <a href="index.php" class="btn btn-outline-secondary">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <div class="card p-0">
            <table class="table table-bordered table-striped mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Athlete</th>
                        <th>College</th>
                        <th>Sport / Event</th>
                        <th>Category</th>
                        <th>Bracket Level</th>
                        <th>Match Schedule</th>
                        <th>Reg Fee (₱)</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['tournamentID']; ?></td>
                            <td><strong><?php echo htmlspecialchars($row['fullName']); ?></strong></td>
                            <td><span class="badge bg-primary"><?php echo htmlspecialchars($row['deptCode']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['sportEvent']); ?></td>
                            <td><?php echo htmlspecialchars($row['category']); ?></td>
                            <td><?php echo htmlspecialchars($row['bracket']); ?></td>
                            <td><?php echo htmlspecialchars($row['matchDate']); ?></td>
                            <td>₱<?php echo number_format($row['regFee'], 2); ?></td>
                            <td><span class="badge bg-success"><?php echo htmlspecialchars($row['matchStatus']); ?></span></td>
                            <td class="text-end">
                                <a href="edit.php?id=<?php echo $row['tournamentID']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete.php?id=<?php echo $row['tournamentID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete tournament registration?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="10" class="text-center py-4 text-muted">No tournament entries recorded.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>