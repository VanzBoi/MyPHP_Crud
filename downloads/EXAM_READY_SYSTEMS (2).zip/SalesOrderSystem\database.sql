CREATE DATABASE IF NOT EXISTS sales_order_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sales_order_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS products (
  productID INT AUTO_INCREMENT PRIMARY KEY,
  productName VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL,
  unitPrice DECIMAL(10,2) NOT NULL,
  stockQty INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
  customerID INT AUTO_INCREMENT PRIMARY KEY,
  customerName VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL,
  customerCity VARCHAR(100) NOT NULL,
  membershipLevel VARCHAR(50) DEFAULT 'Regular'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  orderID INT AUTO_INCREMENT PRIMARY KEY,
  productID INT NOT NULL,
  customerID INT NOT NULL,
  orderDate DATE NOT NULL,
  quantity INT NOT NULL,
  totalAmount DECIMAL(10,2) NOT NULL,
  paymentStatus VARCHAR(50) DEFAULT 'Paid',
  deliveryStatus VARCHAR(50) DEFAULT 'Delivered',
  FOREIGN KEY (productID) REFERENCES products(productID) ON DELETE CASCADE,
  FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO products (productName, category, unitPrice, stockQty) VALUES
('Wireless Bluetooth Earbuds', 'Electronics', 1299.00, 100),
('Mechanical Gaming Keyboard', 'Electronics', 2499.00, 60),
('Ergonomic Office Chair', 'Furniture', 4500.00, 30),
('Stainless Insulated Tumbler', 'Lifestyle', 650.00, 150);

INSERT INTO customers (customerName, contactNumber, customerCity, membershipLevel) VALUES
('Bernardo Carpio', '09171231122', 'Cebu City', 'Gold'),
('Gabriela Silang', '09182342233', 'Mandaue City', 'Silver'),
('Emilio Aguinaldo', '09223453344', 'Talisay City', 'Regular');

INSERT INTO orders (productID, customerID, orderDate, quantity, totalAmount, paymentStatus, deliveryStatus) VALUES
(1, 1, '2026-10-25', 2, 2598.00, 'Paid', 'Delivered'),
(2, 2, '2026-10-26', 1, 2499.00, 'Paid', 'Shipped'),
(3, 3, '2026-10-27', 1, 4500.00, 'Paid', 'Processing');

SET FOREIGN_KEY_CHECKS=1;