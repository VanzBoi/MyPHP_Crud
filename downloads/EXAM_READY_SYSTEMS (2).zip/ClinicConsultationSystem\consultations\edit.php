<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) redirect('index.php');

$res = $mysqli->query("SELECT * FROM consultations WHERE consulID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    redirect('index.php');
}
$row = $res->fetch_assoc();

$patients = $mysqli->query("SELECT * FROM patients ORDER BY patLName, patFName");
$doctors = $mysqli->query("SELECT * FROM doctors ORDER BY docLName, docFName");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pat = (int)($_POST['patID'] ?? 0);
    $doc = (int)($_POST['docID'] ?? 0);
    $date = is_string($_POST['consulDate'] ?? null) && trim($_POST['consulDate']) !== '' ? trim($_POST['consulDate']) : date('Y-m-d H:i:s');
    $diag = is_string($_POST['diagnosis'] ?? null) ? trim($_POST['diagnosis']) : '';
    $pres = is_string($_POST['prescription'] ?? null) ? trim($_POST['prescription']) : '';

    if ($pat <= 0 || $doc <= 0) {
        flash('error', 'Please select valid options.');
        redirect('index.php');
    } else {
        $sql = "UPDATE consultations SET patID=$pat, docID=$doc, consulDate='" . $mysqli->real_escape_string($date) . "', diagnosis='" . $mysqli->real_escape_string($diag) . "', prescription='" . $mysqli->real_escape_string($pres) . "' WHERE consulID=$id";
        if ($mysqli->query($sql)) {
            flash('success', 'Consultation updated.');
            redirect('index.php');
        } else {
            flash('error', 'Database error: ' . $mysqli->error);
            redirect('index.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Consultation - Clinic Consultation</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
  <h2>Edit Consultation</h2>
  <form method="post">
    <div class="mb-2"><label>Patient</label>
      <select class="form-select" name="patID" required>
        <?php while($p = $patients->fetch_assoc()): ?>
          <option value="<?php echo $p['patID']; ?>" <?php if($p['patID']==$row['patID']) echo 'selected'; ?>><?php echo e($p['patFName'].' '.$p['patLName']); ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="mb-2"><label>Doctor</label>
      <select class="form-select" name="docID" required>
        <?php while($d = $doctors->fetch_assoc()): ?>
          <option value="<?php echo $d['docID']; ?>" <?php if($d['docID']==$row['docID']) echo 'selected'; ?>><?php echo e($d['docFName'].' '.$d['docLName'].' ('.$d['docSpecial'].')'); ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="mb-2"><label>Date/Time</label><input class="form-control" name="consulDate" value="<?php echo e($row['consulDate']); ?>"></div>
    <div class="mb-2"><label>Diagnosis</label><textarea class="form-control" name="diagnosis"><?php echo e($row['diagnosis']); ?></textarea></div>
    <div class="mb-2"><label>Prescription</label><textarea class="form-control" name="prescription"><?php echo e($row['prescription']); ?></textarea></div>
    <button class="btn btn-primary">Update Consultation</button>
  </form>
</div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
