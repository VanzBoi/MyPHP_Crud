<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM pets WHERE petID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $petName = is_string($_POST['petName'] ?? null) ? trim($_POST['petName']) : '';
$petType = is_string($_POST['petType'] ?? null) ? trim($_POST['petType']) : '';
$breed = is_string($_POST['breed'] ?? null) ? trim($_POST['breed']) : '';
$ownerName = is_string($_POST['ownerName'] ?? null) ? trim($_POST['ownerName']) : '';
$contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    $sql = "UPDATE pets SET `petName` = '" . $conn->real_escape_string($petName) . "', `petType` = '" . $conn->real_escape_string($petType) . "', `breed` = '" . $conn->real_escape_string($breed) . "', `ownerName` = '" . $conn->real_escape_string($ownerName) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "' WHERE petID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pet #<?= $id ?> - Pet Grooming Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Pet #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Pet Name</label>
                <input type="text" name="petName" class="form-control" value="<?= htmlspecialchars($row['petName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Pet Type</label>
                <select name="petType" class="form-select" required>
                    <option value="Dog" <?= ($row['petType'] ?? '') === 'Dog' ? 'selected' : '' ?>>Dog</option>
<option value="Cat" <?= ($row['petType'] ?? '') === 'Cat' ? 'selected' : '' ?>>Cat</option>
<option value="Rabbit" <?= ($row['petType'] ?? '') === 'Rabbit' ? 'selected' : '' ?>>Rabbit</option>
<option value="Other" <?= ($row['petType'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Breed</label>
                <input type="text" name="breed" class="form-control" value="<?= htmlspecialchars($row['breed'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Owner Name</label>
                <input type="text" name="ownerName" class="form-control" value="<?= htmlspecialchars($row['ownerName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Owner Contact</label>
                <input type="text" name="contactNumber" class="form-control" value="<?= htmlspecialchars($row['contactNumber'] ?? '') ?>" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>