<?php
require_once '../database.php';

$query = "SELECT o.*, m.itemName, m.itemCategory, m.unitPrice, c.customerName, c.tableNumber 
          FROM orders o
          JOIN menu_items m ON o.itemID = m.itemID
          JOIN customers c ON o.customerID = c.customerID
          ORDER BY o.orderID DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Orders</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Customer Orders (Point of Sale)</h3>
            <a href="add.php" class="btn btn-primary">+ Place New Order</a>
        </div>
        <div class="card mb-3">
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Menu Item</th>
                        <th>Customer / Table</th>
                        <th>Date</th>
                        <th>Qty</th>
                        <th>Total Paid</th>
                        <th>Payment Mode</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $row['orderID']; ?></td>
                            <td>
                                <strong> <?php echo htmlspecialchars($row['itemName']); ?></strong>
                                <small class="text-muted d-block"><?php echo htmlspecialchars($row['itemCategory']); ?> (₱<?php echo number_format($row['unitPrice'], 2); ?>)</small>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($row['customerName']); ?>
                                <span class="badge bg-light text-dark border d-block"><?php echo htmlspecialchars($row['tableNumber']); ?></span>
                            </td>
                            <td><?php echo $row['orderDate']; ?></td>
                            <td><?php echo $row['quantity']; ?> pc(s)</td>
                            <td><strong class="text-success">₱<?php echo number_format($row['totalAmount'], 2); ?></strong></td>
                            <td><span class="badge bg-info text-dark"><?php echo htmlspecialchars($row['paymentMode']); ?></span></td>
                            <td class="text-end">
                                <a href="delete.php?id=<?php echo $row['orderID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Cancel/Void order?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No orders processed yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>