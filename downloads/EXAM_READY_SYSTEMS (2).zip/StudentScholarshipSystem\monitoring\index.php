<?php
require_once '../database.php';
require_once '../helpers.php';

$scholarshipFilter = is_string($_GET['scholarship'] ?? null) ? trim($_GET['scholarship']) : '';
$fromDate = is_string($_GET['fromDate'] ?? null) ? trim($_GET['fromDate']) : '';
$toDate = is_string($_GET['toDate'] ?? null) ? trim($_GET['toDate']) : '';

$query = 'SELECT a.*, s.fName, s.lName, s.course, sch.scholName, sch.discountRate FROM applications a
          JOIN students s ON a.studID = s.studID
          JOIN scholarships sch ON a.scholID = sch.scholID';
$where = [];
$params = [];
$types = '';

if ($scholarshipFilter !== '') {
    $where[] = 'sch.scholID = ?';
    $params[] = $scholarshipFilter;
    $types .= 'i';
}
if ($fromDate !== '') {
    $where[] = 'a.appDate >= ?';
    $params[] = $fromDate;
    $types .= 's';
}
if ($toDate !== '') {
    $where[] = 'a.appDate <= ?';
    $params[] = $toDate;
    $types .= 's';
}
if ($where) {
    $query .= ' WHERE ' . implode(' AND ', $where);
}
$query .= ' ORDER BY a.appDate DESC';
$stmt = $mysqli->prepare($query);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$applications = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$aggQuery = 'SELECT COUNT(*) AS totalApplications, SUM(a.discountAmount) AS totalDiscount, SUM(a.amountPaid) AS totalPaid, AVG(s.discountRate) AS avgDiscountRate, SUM(a.tuitionFee - a.discountAmount) AS totalNetTuition FROM applications a JOIN scholarships s ON a.scholID = s.scholID';
if ($where) {
    $aggQuery .= ' WHERE ' . implode(' AND ', $where);
}
$stmt = $mysqli->prepare($aggQuery);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$aggregates = $result->fetch_assoc();
$stmt->close();

$scholarships = $mysqli->query('SELECT scholID, scholName FROM scholarships ORDER BY scholName')->fetch_all(MYSQLI_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<div class="container mt-4">
    <?php include '../navbar.php'; ?>
    <div class="mb-3">
        <h2>Monitoring / Inquiry</h2>
        <p>Filter by scholarship or date range to see applications and summary totals.</p>
    </div>
    <form class="row g-3 mb-4" method="get" action="index.php">
        <div class="col-md-4">
            <label class="form-label">Scholarship</label>
            <select name="scholarship" class="form-select">
                <option value="">All scholarships</option>
                <?php foreach ($scholarships as $sch): ?>
                    <option value="<?= escape($sch['scholID']) ?>" <?= $scholarshipFilter == $sch['scholID'] ? 'selected' : '' ?>><?= escape($sch['scholName']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label">From Date</label>
            <input type="date" name="fromDate" class="form-control" value="<?= escape($fromDate) ?>">
        </div>
        <div class="col-md-3">
            <label class="form-label">To Date</label>
            <input type="date" name="toDate" class="form-control" value="<?= escape($toDate) ?>">
        </div>
        <div class="col-md-2 d-flex align-items-end">
            <button class="btn btn-secondary w-100" type="submit">Filter</button>
        </div>
    </form>
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card p-3 mb-3">
                <div class="fw-bold">Total Applications</div>
                <div><?= escape($aggregates['totalApplications'] ?? 0) ?></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 mb-3">
                <div class="fw-bold">Total Discount Given</div>
                <div><?= number_format($aggregates['totalDiscount'] ?? 0, 2) ?></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 mb-3">
                <div class="fw-bold">Total Amount Paid</div>
                <div><?= number_format($aggregates['totalPaid'] ?? 0, 2) ?></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 mb-3">
                <div class="fw-bold">Average Discount Rate</div>
                <div><?= number_format(($aggregates['avgDiscountRate'] ?? 0) * 100, 2) ?>%</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3 mb-3">
                <div class="fw-bold">Total Net Tuition</div>
                <div><?= number_format($aggregates['totalNetTuition'] ?? 0, 2) ?></div>
            </div>
        </div>
    </div>
    <div class="card mb-3">
        <div class="card-header fw-bold">Scholarship Applications & Grants</div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Student</th>
                        <th>Course</th>
                        <th>Scholarship</th>
                        <th>Tuition Fee</th>
                        <th>Discount Amount</th>
                        <th>Amount Paid</th>
                        <th>Application Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $index => $app): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>
                            <td><?= escape($app['fName'] . ' ' . $app['lName']) ?></td>
                            <td><?= escape($app['course']) ?></td>
                            <td><?= escape($app['scholName']) ?></td>
                            <td><?= number_format($app['tuitionFee'], 2) ?></td>
                            <td><?= number_format($app['discountAmount'], 2) ?></td>
                            <td><?= number_format($app['amountPaid'], 2) ?></td>
                            <td><?= escape($app['appDate']) ?></td>
                            <td><?= escape($app['status']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($applications)): ?>
                        <tr><td colspan="9" class="text-center">No records found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
