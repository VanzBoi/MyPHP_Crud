<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM employees WHERE empID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$emp = $res->fetch_assoc();
$positions = $conn->query("SELECT * FROM positions ORDER BY positionName ASC");
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fName = is_string($_POST['empFName'] ?? null) ? trim($_POST['empFName']) : '';
    $lName = is_string($_POST['empLName'] ?? null) ? trim($_POST['empLName']) : '';
    $posID = intval($_POST['positionID'] ?? 0);
    $dateHired = is_string($_POST['dateHired'] ?? null) ? trim($_POST['dateHired']) : '';
    $contact = is_string($_POST['contactNo'] ?? null) ? trim($_POST['contactNo']) : '';

    if ($fName === '' || $lName === '' || $posID <= 0 || $dateHired === '') {
        $err = 'Please complete all required fields.';
    } else {
        $stmt = $conn->prepare("UPDATE employees SET empFName = ?, empLName = ?, positionID = ?, dateHired = ?, contactNo = ? WHERE empID = ?");
        $stmt->bind_param("ssissi", $fName, $lName, $posID, $dateHired, $contact, $id);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Failed to update employee: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Employee</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Edit Employee Profile</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">First Name</label>
                        <input type="text" name="empFName" class="form-control" required value="<?php echo htmlspecialchars($emp['empFName']); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="empLName" class="form-control" required value="<?php echo htmlspecialchars($emp['empLName']); ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Designated Position</label>
                    <select name="positionID" class="form-select" required>
                        <?php while($p = $positions->fetch_assoc()): ?>
                            <option value="<?php echo $p['positionID']; ?>" <?php echo ($p['positionID'] == $emp['positionID']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($p['positionName']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Date Hired</label>
                    <input type="date" name="dateHired" class="form-control" value="<?php echo $emp['dateHired']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="contactNo" class="form-control" value="<?php echo htmlspecialchars($emp['contactNo']); ?>" required>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Profile</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>