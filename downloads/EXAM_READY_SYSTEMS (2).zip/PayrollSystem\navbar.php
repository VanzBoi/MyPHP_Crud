<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo $baseUrl; ?>index.php">Payroll Management System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'positions') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>positions/index.php">Positions</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'employees') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>employees/index.php">Employees</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'payroll') !== false && strpos($currentUri, 'positions') === false && strpos($currentUri, 'employees') === false && strpos($currentUri, 'monitoring') === false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>payroll/index.php">Payroll</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>