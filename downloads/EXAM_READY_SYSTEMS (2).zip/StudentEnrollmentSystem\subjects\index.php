<?php
require '../database.php';
require '../helpers.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$query = "SELECT * FROM subjects";
if ($search !== '') {
    $s = $mysqli->real_escape_string($search);
    $query .= " WHERE subjectCode LIKE '%$s%' OR subjectName LIKE '%$s%'";
}
$result = $mysqli->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Subjects</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
  <?php include '../navbar.php'; ?>
  <main class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
      <div>
        <h1 class="h3 mb-1">Subjects</h1>
        <p class="text-muted mb-0">Manage subject codes, units, fees, and totals.</p>
      </div>
      <a class="btn btn-primary" href="add.php">Add Subject</a>
    </div>

    <?php if ($message = flash()) : ?>
      <div class="alert alert-success" role="alert">
        <?= e($message) ?>
      </div>
    <?php endif; ?>

    <div class="card mb-4">
      <div class="card-body">
        <form class="row g-3 align-items-end" action="index.php" method="get">
          <div class="col-md-8">
            <label for="search" class="form-label">Search</label>
            <input id="search" name="search" value="<?= e($search) ?>" placeholder="Code or name" class="form-control">
          </div>
          <div class="col-md-4 d-grid">
            <button class="btn btn-outline-primary" type="submit">Search</button>
          </div>
        </form>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-striped table-bordered align-middle mb-0">
        <thead class="table-light">
          <tr><th>ID</th><th>Subject Code</th><th>Name</th><th>Units</th><th>Fee/Unit</th><th>Total Fee</th><th class="text-end">Actions</th></tr>
        </thead>
        <tbody>
          <?php while ($subject = $result->fetch_assoc()) : ?>
          <tr>
            <td><?= e($subject['subjectID']) ?></td>
            <td><?= e($subject['subjectCode']) ?></td>
            <td><?= e($subject['subjectName']) ?></td>
            <td><?= e($subject['units']) ?></td>
            <td><?= e(number_format($subject['feePerUnit'], 2)) ?></td>
            <td><?= e(number_format($subject['totalFee'], 2)) ?></td>
            <td class="text-end">
              <a class="btn btn-sm btn-outline-secondary me-2" href="edit.php?id=<?= e($subject['subjectID']) ?>">Edit</a>
              <a class="btn btn-sm btn-outline-danger" href="delete.php?id=<?= e($subject['subjectID']) ?>" onclick="return confirm('Delete this subject?');">Delete</a>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </main>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
