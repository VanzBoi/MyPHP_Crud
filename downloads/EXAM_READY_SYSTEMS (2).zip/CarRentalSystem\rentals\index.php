<?php
require_once '../database.php';

$query = "SELECT r.*, v.plateNumber, v.brandModel, v.dailyRate, c.custFName, c.custLName 
          FROM rentals r
          JOIN vehicles v ON r.vehicleID = v.vehicleID
          JOIN customers c ON r.customerID = c.customerID
          ORDER BY r.rentalID DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Rental Transactions</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Rental Transactions</h3>
            <a href="add.php" class="btn btn-primary">+ New Rental Booking</a>
        </div>
        <div class="card mb-3">
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>Rental #</th>
                        <th>Vehicle</th>
                        <th>Customer</th>
                        <th>Rental Period</th>
                        <th>Days</th>
                        <th>Total Fee</th>
                        <th>Mode</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $row['rentalID']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($row['brandModel']); ?></strong>
                                <small class="text-muted d-block"><?php echo htmlspecialchars($row['plateNumber']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($row['custFName'] . ' ' . $row['custLName']); ?></td>
                            <td><?php echo $row['rentalDate']; ?> to <?php echo $row['returnDate']; ?></td>
                            <td><?php echo $row['totalDays']; ?> days</td>
                            <td><strong>₱<?php echo number_format($row['totalFee'], 2); ?></strong></td>
                            <td><span class="badge bg-info text-dark"><?php echo htmlspecialchars($row['paymentMode']); ?></span></td>
                            <td class="text-end">
                                <a href="delete.php?id=<?php echo $row['rentalID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Cancel/Delete this rental record?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No rental bookings yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>