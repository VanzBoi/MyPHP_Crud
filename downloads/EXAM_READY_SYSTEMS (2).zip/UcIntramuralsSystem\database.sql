CREATE DATABASE IF NOT EXISTS `uc_intramurals` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `uc_intramurals`;

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `departments` (
  `deptID` INT AUTO_INCREMENT PRIMARY KEY,
  `deptCode` VARCHAR(50) NOT NULL UNIQUE,
  `deptName` VARCHAR(150) NOT NULL,
  `deanName` VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `athletes` (
  `athleteID` INT AUTO_INCREMENT PRIMARY KEY,
  `studentID` VARCHAR(50) NOT NULL UNIQUE,
  `fullName` VARCHAR(100) NOT NULL,
  `deptID` INT NOT NULL,
  `yearLevel` VARCHAR(50) NOT NULL,
  `gender` VARCHAR(20) NOT NULL,
  `contactNo` VARCHAR(50) NOT NULL,
  FOREIGN KEY (`deptID`) REFERENCES `departments`(`deptID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `tournaments` (
  `tournamentID` INT AUTO_INCREMENT PRIMARY KEY,
  `athleteID` INT NOT NULL,
  `sportEvent` VARCHAR(100) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `bracket` VARCHAR(50) NOT NULL,
  `matchDate` DATE NOT NULL,
  `regFee` DECIMAL(10,2) NOT NULL DEFAULT 150.00,
  `matchStatus` VARCHAR(50) DEFAULT 'Scheduled',
  FOREIGN KEY (`athleteID`) REFERENCES `athletes`(`athleteID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `departments` (`deptID`, `deptCode`, `deptName`, `deanName`) VALUES
(1, 'CCS', 'College of Computer Studies', 'Dean Jonathan O. Perez'),
(2, 'CEA', 'College of Engineering and Architecture', 'Dean Robert M. Tan'),
(3, 'CBA', 'College of Business Administration', 'Dean Elena S. Castro'),
(4, 'CCJ', 'College of Criminal Justice', 'Dean Victor L. Gomez');

INSERT INTO `athletes` (`athleteID`, `studentID`, `fullName`, `deptID`, `yearLevel`, `gender`, `contactNo`) VALUES
(1, '20-11234', 'John Cedrick Libradilla', 1, '3rd Year', 'Male', '0917-222-3344'),
(2, '21-09876', 'Beatrice Anne Ramirez', 1, '2nd Year', 'Female', '0918-333-4455'),
(3, '19-05432', 'Marcus Anthony Diaz', 2, '4th Year', 'Male', '0922-444-5566'),
(4, '22-12001', 'Patricia Mae Sy', 3, '1st Year', 'Female', '0919-555-6677');

INSERT INTO `tournaments` (`athleteID`, `sportEvent`, `category`, `bracket`, `matchDate`, `regFee`, `matchStatus`) VALUES
(1, 'Esports (Valorant)', 'Mixed Team', 'Quarterfinals', '2026-10-24', 200.00, 'Winner'),
(2, 'Badminton Singles', 'Women Division', 'Semifinals', '2026-10-25', 150.00, 'Scheduled'),
(3, 'Basketball 5v5', 'Men Division', 'Finals', '2026-10-25', 300.00, 'Scheduled'),
(4, 'Volleyball', 'Women Division', 'Eliminations', '2026-10-26', 150.00, 'Completed');

SET FOREIGN_KEY_CHECKS=1;