CREATE DATABASE IF NOT EXISTS movie_booking_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE movie_booking_db;

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS movies (
  movieID INT AUTO_INCREMENT PRIMARY KEY,
  movieTitle VARCHAR(150) NOT NULL,
  genre VARCHAR(50) NOT NULL,
  cinemaHall VARCHAR(50) NOT NULL,
  durationMinutes INT NOT NULL,
  ticketPrice DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
  customerID INT AUTO_INCREMENT PRIMARY KEY,
  custFName VARCHAR(100) NOT NULL,
  custLName VARCHAR(100) NOT NULL,
  customerType VARCHAR(50) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS bookings (
  bookingID INT AUTO_INCREMENT PRIMARY KEY,
  movieID INT NOT NULL,
  customerID INT NOT NULL,
  bookingDate DATE NOT NULL,
  numTickets INT NOT NULL,
  totalAmountPaid DECIMAL(10,2) NOT NULL,
  paymentMode VARCHAR(50) NOT NULL,
  FOREIGN KEY (movieID) REFERENCES movies(movieID) ON DELETE CASCADE,
  FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO movies (movieTitle, genre, cinemaHall, durationMinutes, ticketPrice) VALUES
('Avengers: Secret Wars', 'Action / Sci-Fi', 'Cinema 1 (IMAX)', 180, 450.00),
('Inside Out 3', 'Animation / Family', 'Cinema 2', 110, 320.00),
('The Conjuring: Final Rites', 'Horror / Thriller', 'Cinema 3', 125, 350.00),
('Dune: Part Three', 'Sci-Fi / Adventure', 'Cinema 4', 165, 400.00);

INSERT INTO customers (custFName, custLName, customerType, contactNumber) VALUES
('Joshua', 'Alcantara', 'Regular', '0917-222-3344'),
('Samantha', 'Bernardo', 'Student', '0918-444-5566'),
('Roberto', 'Castro', 'Senior', '0922-888-9900');

INSERT INTO bookings (movieID, customerID, bookingDate, numTickets, totalAmountPaid, paymentMode) VALUES
(1, 1, '2026-10-24', 2, 900.00, 'Cash'),
(1, 2, '2026-10-25', 1, 360.00, 'GCash'),
(2, 3, '2026-10-25', 2, 512.00, 'Card'),
(3, 1, '2026-10-26', 1, 350.00, 'Cash');

SET FOREIGN_KEY_CHECKS=1;