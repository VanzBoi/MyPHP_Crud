<?php
require_once '../database.php';
require_once '../helpers.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$sql = 'SELECT * FROM students';
$params = [];
if ($search !== '') {
    $sql .= ' WHERE CONCAT(fName, " ", lName, " ", course, " ", yearLevel, " ", contactNo) LIKE ?';
    $params[] = '%' . $search . '%';
}
$stmt = $mysqli->prepare($sql);
if ($params) {
    $stmt->bind_param('s', $params[0]);
}
$stmt->execute();
$result = $stmt->get_result();
$students = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Students</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<div class="container mt-4">
    <?php include '../navbar.php'; ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Students</h2>
        <a href="add.php" class="btn btn-primary">Add Student</a>
    </div>
    <?php flash(); ?>
    <form class="row g-2 mb-3" method="get" action="index.php">
        <div class="col-md-10">
            <input type="text" name="search" class="form-control" placeholder="Search students..." value="<?= escape($search) ?>">
        </div>
        <div class="col-md-2">
            <button class="btn btn-secondary w-100" type="submit">Search</button>
        </div>
    </form>
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Course</th>
                    <th>Year Level</th>
                    <th>Contact No.</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $index => $student): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= escape($student['studID']) ?></td>
                        <td><?= escape($student['fName'] . ' ' . $student['lName']) ?></td>
                        <td><?= escape($student['course']) ?></td>
                        <td><?= escape($student['yearLevel']) ?></td>
                        <td><?= escape($student['contactNo']) ?></td>
                        <td>
                            <a href="edit.php?id=<?= escape($student['studID']) ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="delete.php?id=<?= escape($student['studID']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this student?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($students)): ?>
                    <tr><td colspan="7" class="text-center">No students found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
