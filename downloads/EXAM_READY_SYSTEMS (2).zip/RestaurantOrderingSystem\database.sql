CREATE DATABASE IF NOT EXISTS restaurant_order_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE restaurant_order_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS menu_items (
  itemID INT AUTO_INCREMENT PRIMARY KEY,
  itemName VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  availability VARCHAR(20) DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
  customerID INT AUTO_INCREMENT PRIMARY KEY,
  customerName VARCHAR(100) NOT NULL,
  tableNumber VARCHAR(20) NOT NULL,
  diningType VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  orderID INT AUTO_INCREMENT PRIMARY KEY,
  itemID INT NOT NULL,
  customerID INT NOT NULL,
  orderDate DATE NOT NULL,
  quantity INT NOT NULL,
  totalAmount DECIMAL(10,2) NOT NULL,
  paymentStatus VARCHAR(50) DEFAULT 'Paid',
  FOREIGN KEY (itemID) REFERENCES menu_items(itemID) ON DELETE CASCADE,
  FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO menu_items (itemName, category, price, availability) VALUES
('Crispy Pork Sisig', 'Main Dish', 240.00, 'Available'),
('Chicken Inasal Platter', 'Main Dish', 220.00, 'Available'),
('Sinigang na Hipon', 'Soup', 320.00, 'Available'),
('Leche Flan Special', 'Dessert', 120.00, 'Available');

INSERT INTO customers (customerName, tableNumber, diningType) VALUES
('Marco Antonio', 'Table 04', 'Dine-In'),
('Valerie Soriano', 'Table 08', 'Dine-In'),
('Dennis Quizon', 'Takeout Counter', 'Take-Out');

INSERT INTO orders (itemID, customerID, orderDate, quantity, totalAmount, paymentStatus) VALUES
(1, 1, '2026-10-25', 2, 480.00, 'Paid'),
(2, 2, '2026-10-26', 3, 660.00, 'Paid'),
(3, 3, '2026-10-27', 1, 320.00, 'Paid');

SET FOREIGN_KEY_CHECKS=1;