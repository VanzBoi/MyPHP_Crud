<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $equipmentName = is_string($_POST['equipmentName'] ?? null) ? trim($_POST['equipmentName']) : '';
$category = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
$serialNumber = is_string($_POST['serialNumber'] ?? null) ? trim($_POST['serialNumber']) : '';
$conditionStatus = is_string($_POST['conditionStatus'] ?? null) ? trim($_POST['conditionStatus']) : '';

    $sql = "INSERT INTO equipment (`equipmentName`, `category`, `serialNumber`, `conditionStatus`) VALUES ('" . $conn->real_escape_string($equipmentName) . "', '" . $conn->real_escape_string($category) . "', '" . $conn->real_escape_string($serialNumber) . "', '" . $conn->real_escape_string($conditionStatus) . "')";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to add record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Equipment - Equipment Borrowing &amp; Tracking System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Add New Equipment</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Equipment Name</label>
                <input type="text" name="equipmentName" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Category</label>
                <select name="category" class="form-select" required>
                    <option value="Multimedia">Multimedia</option>
<option value="IT Hardware">IT Hardware</option>
<option value="Audio Gear">Audio Gear</option>
<option value="Laboratory">Laboratory</option>
<option value="Sports">Sports</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Serial Number</label>
                <input type="text" name="serialNumber" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Condition</label>
                <select name="conditionStatus" class="form-select" required>
                    <option value="Good">Good</option>
<option value="Fair">Fair</option>
<option value="Needs Repair">Needs Repair</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Equipment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>