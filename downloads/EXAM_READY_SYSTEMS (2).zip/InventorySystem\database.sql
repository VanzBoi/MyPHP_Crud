CREATE DATABASE IF NOT EXISTS inventory_system_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE inventory_system_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS suppliers (
  supplierID INT AUTO_INCREMENT PRIMARY KEY,
  supplierName VARCHAR(100) NOT NULL,
  contactPerson VARCHAR(100) NOT NULL,
  phone VARCHAR(50) NOT NULL,
  city VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS products (
  productID INT AUTO_INCREMENT PRIMARY KEY,
  productName VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL,
  unitCost DECIMAL(10,2) NOT NULL,
  reorderLevel INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS stock_movements (
  movementID INT AUTO_INCREMENT PRIMARY KEY,
  supplierID INT NOT NULL,
  productID INT NOT NULL,
  movementDate DATE NOT NULL,
  movementType VARCHAR(50) NOT NULL,
  quantity INT NOT NULL,
  totalValue DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (supplierID) REFERENCES suppliers(supplierID) ON DELETE CASCADE,
  FOREIGN KEY (productID) REFERENCES products(productID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO suppliers (supplierName, contactPerson, phone, city) VALUES
('Prime Logistics Supplies', 'Maricel Reyes', '09171113355', 'Cebu City'),
('Apex Industrial Trading', 'Arthur Chen', '09182224466', 'Mandaue City'),
('Global Hardware Corp', 'Sonia Dimayuga', '09223335577', 'Lapu-Lapu City');

INSERT INTO products (productName, category, unitCost, reorderLevel) VALUES
('Hydraulic Seal Kit A-1', 'Industrial', 1250.00, 20),
('Heavy Duty Caster Wheels', 'Hardware', 350.00, 50),
('Industrial Safety Goggles', 'Safety Gear', 180.00, 100),
('Power Drill Bit Set 13pc', 'Tools', 650.00, 40);

INSERT INTO stock_movements (supplierID, productID, movementDate, movementType, quantity, totalValue) VALUES
(1, 1, '2026-10-25', 'Stock In', 30, 37500.00),
(2, 2, '2026-10-26', 'Stock In', 50, 17500.00),
(3, 3, '2026-10-27', 'Stock Out', 20, 3600.00);

SET FOREIGN_KEY_CHECKS=1;