﻿# Student Scholarship Management System

A simple PHP and MySQL web application for managing scholarships, students, and applications.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\StudentScholarshipSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/StudentScholarshipSystem/
4. The database `scholarship_system` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Scholarships**: Add, view, edit, and delete scholarships records.
- **Students**: Add, view, edit, and delete students records.
- **Applications**: Manage applications transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
