<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = is_string($_POST['patFName'] ?? null) ? trim($_POST['patFName']) : '';
    $l = is_string($_POST['patLName'] ?? null) ? trim($_POST['patLName']) : '';
    $b = is_string($_POST['patBDate'] ?? null) ? trim($_POST['patBDate']) : '';
    $t = is_string($_POST['patTelNo'] ?? null) ? trim($_POST['patTelNo']) : '';
    $stmt = $mysqli->prepare("INSERT INTO patients (patFName, patLName, patBDate, patTelNo) VALUES (?,?,?,?)");
    $stmt->bind_param('ssss', $f, $l, $b, $t);
    $stmt->execute();
    flash('success','Patient added.');
    redirect('index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Patient - Clinic Consultation</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
  <h2>Add Patient</h2>
  <form method="post">
    <div class="mb-2"><label>First Name</label><input class="form-control" name="patFName" required></div>
    <div class="mb-2"><label>Last Name</label><input class="form-control" name="patLName" required></div>
    <div class="mb-2"><label>Birth Date</label><input type="date" class="form-control" name="patBDate"></div>
    <div class="mb-2"><label>Tel No</label><input class="form-control" name="patTelNo"></div>
    <button class="btn btn-primary">Save</button>
  </form>
</div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
