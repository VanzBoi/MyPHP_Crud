﻿<?php
require_once 'database.php';

$totalMovies = $conn->query("SELECT COUNT(*) FROM movies")->fetch_row()[0];
$totalCustomers = $conn->query("SELECT COUNT(*) FROM customers")->fetch_row()[0];
$totalBookings = $conn->query("SELECT COUNT(*) FROM bookings")->fetch_row()[0];
$totalRevenue = $conn->query("SELECT IFNULL(SUM(totalAmountPaid), 0) FROM bookings")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cinema Booking System - Dashboard</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="p-4 mb-4 bg-white rounded-3 border">
            <h1 class="display-6 fw-bold">Movie Theater & Cinema Box Office</h1>
            <p class="lead text-muted mb-0">Ticket Reservation & Monitoring System</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Now Showing</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalMovies; ?> Movies</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Registered Moviegoers</span>
                    <h3 class="mb-0 text-success"><?php echo $totalCustomers; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Total Bookings</span>
                    <h3 class="mb-0 text-warning"><?php echo $totalBookings; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Box Office Revenue</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalRevenue, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Movies Inventory</h5>
                    <p class="text-muted small">Add movie titles, genres, cinema hall assignments, and ticket rates.</p>
                    <a href="<?php echo $baseUrl; ?>movies/index.php" class="btn btn-outline-primary mt-auto">Open Movies &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Moviegoer Registry</h5>
                    <p class="text-muted small">Manage customer classifications: Regular, Student (20%), and Senior (20%).</p>
                    <a href="<?php echo $baseUrl; ?>customers/index.php" class="btn btn-outline-success mt-auto">Open Moviegoers &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Monitoring & Analytics</h5>
                    <p class="text-muted small">Filter sales by movie, count tickets, and view total discounts granted.</p>
                    <a href="<?php echo $baseUrl; ?>monitoring/index.php" class="btn btn-outline-dark mt-auto">Open Monitoring &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>