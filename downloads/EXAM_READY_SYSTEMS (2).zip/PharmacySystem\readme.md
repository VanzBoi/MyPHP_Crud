﻿# Pharmacy Inventory & Sales System

A simple PHP and MySQL web application for managing medicines, customers, and purchases.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\PharmacySystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/PharmacySystem/
4. The database `pharmacy_system_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Medicines**: Add, view, edit, and delete medicines records.
- **Customers**: Add, view, edit, and delete customers records.
- **Purchases**: Manage purchases transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
