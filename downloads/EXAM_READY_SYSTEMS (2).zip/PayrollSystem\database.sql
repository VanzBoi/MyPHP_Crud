CREATE DATABASE IF NOT EXISTS `payroll_system` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `payroll_system`;

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `positions` (
  `positionID` INT AUTO_INCREMENT PRIMARY KEY,
  `positionName` VARCHAR(100) NOT NULL,
  `basicSalary` DECIMAL(10,2) NOT NULL,
  `allowance` DECIMAL(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `employees` (
  `empID` INT AUTO_INCREMENT PRIMARY KEY,
  `empFName` VARCHAR(100) NOT NULL,
  `empLName` VARCHAR(100) NOT NULL,
  `positionID` INT NOT NULL,
  `dateHired` DATE NOT NULL,
  `contactNo` VARCHAR(50) NOT NULL,
  FOREIGN KEY (`positionID`) REFERENCES `positions`(`positionID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `payroll` (
  `payrollID` INT AUTO_INCREMENT PRIMARY KEY,
  `empID` INT NOT NULL,
  `payDate` DATE NOT NULL,
  `basicSalary` DECIMAL(10,2) NOT NULL,
  `allowance` DECIMAL(10,2) NOT NULL,
  `deduction` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `netPay` DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (`empID`) REFERENCES `employees`(`empID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `positions` (`positionID`, `positionName`, `basicSalary`, `allowance`) VALUES
(1, 'Lead Software Engineer', 45000.00, 5000.00),
(2, 'Database Administrator', 38000.00, 4000.00),
(3, 'IT Support Specialist', 22000.00, 2500.00),
(4, 'HR Payroll Officer', 26000.00, 3000.00);

INSERT INTO `employees` (`empID`, `empFName`, `empLName`, `positionID`, `dateHired`, `contactNo`) VALUES
(1, 'John Cedrick', 'Libradilla', 1, '2023-01-15', '0917-111-2233'),
(2, 'Maria', 'Santos', 2, '2023-04-10', '0918-222-3344'),
(3, 'Carlos', 'Reyes', 3, '2023-08-01', '0922-333-4455'),
(4, 'Angela', 'Mendoza', 4, '2024-02-15', '0919-444-5566');

INSERT INTO `payroll` (`empID`, `payDate`, `basicSalary`, `allowance`, `deduction`, `netPay`) VALUES
(1, '2026-10-15', 45000.00, 5000.00, 2500.00, 47500.00),
(2, '2026-10-15', 38000.00, 4000.00, 1800.00, 40200.00),
(3, '2026-10-15', 22000.00, 2500.00, 1100.00, 23400.00),
(4, '2026-10-15', 26000.00, 3000.00, 1300.00, 27700.00);

SET FOREIGN_KEY_CHECKS=1;