<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM menu_items WHERE itemID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$item = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = is_string($_POST['itemName'] ?? null) ? trim($_POST['itemName']) : '';
    $cat = is_string($_POST['itemCategory'] ?? null) ? trim($_POST['itemCategory']) : '';
    $price = floatval($_POST['unitPrice'] ?? 0);
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    $stmt = $conn->prepare("UPDATE menu_items SET itemName=?, itemCategory=?, unitPrice=?, status=? WHERE itemID=?");
    $stmt->bind_param("ssdsi", $name, $cat, $price, $status, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Menu Item</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Edit Menu Item</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Item Name</label>
                    <input type="text" name="itemName" class="form-control" required value="<?php echo htmlspecialchars($item['itemName']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <select name="itemCategory" class="form-select" required>
                        <?php foreach(['Hot Coffee', 'Iced Drinks', 'Pastries', 'Sandwiches & Snacks'] as $c): ?>
                        <option value="<?php echo $c; ?>" <?php echo $item['itemCategory'] === $c ? 'selected' : ''; ?>><?php echo $c; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Retail Unit Price (₱)</label>
                    <input type="number" step="0.01" name="unitPrice" class="form-control" required value="<?php echo $item['unitPrice']; ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Availability Status</label>
                    <select name="status" class="form-select">
                        <option value="Available" <?php echo $item['status'] === 'Available' ? 'selected' : ''; ?>>Available</option>
                        <option value="Out of Stock" <?php echo $item['status'] === 'Out of Stock' ? 'selected' : ''; ?>>Out of Stock</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-warning w-100">Update Item</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>