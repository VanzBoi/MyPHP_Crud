<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM departments WHERE deptID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$dept = $res->fetch_assoc();
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = strtoupper(is_string($_POST['deptCode'] ?? null) ? (is_string($_POST['deptCode'] ?? null) ? trim($_POST['deptCode']) : '') : '');
    $name = is_string($_POST['deptName'] ?? null) ? trim($_POST['deptName']) : '';
    $dean = is_string($_POST['deanName'] ?? null) ? trim($_POST['deanName']) : '';

    if ($code === '' || $name === '') {
        $err = 'Please complete all required fields.';
    } else {
        $stmt = $conn->prepare("UPDATE departments SET deptCode = ?, deptName = ?, deanName = ? WHERE deptID = ?");
        $stmt->bind_param("sssi", $code, $name, $dean, $id);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Update failed: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Department</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Edit Department Details</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Department Code</label>
                    <input type="text" name="deptCode" class="form-control" required value="<?php echo htmlspecialchars($dept['deptCode']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Complete Department Name</label>
                    <input type="text" name="deptName" class="form-control" required value="<?php echo htmlspecialchars($dept['deptName']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Dean / Department Head</label>
                    <input type="text" name="deanName" class="form-control" value="<?php echo htmlspecialchars($dept['deanName']); ?>">
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Department</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>