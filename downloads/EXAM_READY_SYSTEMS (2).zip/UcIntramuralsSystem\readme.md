﻿# Intramurals Tournament System

A simple PHP and MySQL web application for managing departments, athletes, and tournaments.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\UcIntramuralsSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/UcIntramuralsSystem/
4. The database `uc_intramurals` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Departments**: Add, view, edit, and delete departments records.
- **Athletes**: Add, view, edit, and delete athletes records.
- **Tournaments**: Manage tournaments transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
