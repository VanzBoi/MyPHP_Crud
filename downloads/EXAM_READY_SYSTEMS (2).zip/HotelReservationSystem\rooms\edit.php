<?php include '../database.php'; include '../helpers.php';
$id = (int)($_GET['id'] ?? 0);
if($_SERVER['REQUEST_METHOD']==='POST'){
  $no = is_string($_POST['roomNo'] ?? null) ? $conn->real_escape_string(trim($_POST['roomNo'])) : '';
  $type = is_string($_POST['roomType'] ?? null) ? $conn->real_escape_string(trim($_POST['roomType'])) : '';
  $price = (float)($_POST['price'] ?? 0);
  $status = is_string($_POST['status'] ?? null) ? $conn->real_escape_string(trim($_POST['status'])) : '';
  mysqli_query($conn, "UPDATE rooms SET roomNo='{$no}', roomType='{$type}', price={$price}, status='{$status}' WHERE roomID={$id}");
  set_flash('Room updated.', 'success');
  header('Location: index.php'); exit;
}
$r = mysqli_query($conn, "SELECT * FROM rooms WHERE roomID={$id}");
$row = $r ? mysqli_fetch_assoc($r) : null;
if (!$row) {
    header('Location: index.php');
    exit;
}
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Room</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
  </head>
  <body>
    <?php include '../navbar.php'; ?>
    <div class="container">
      <h4>Edit Room</h4>
      <form method="post">
        <div class="mb-2"><label>Room No</label><input name="roomNo" class="form-control" required value="<?= htmlspecialchars($row['roomNo']) ?>"></div>
        <div class="mb-2"><label>Room Type</label><input name="roomType" class="form-control" required value="<?= htmlspecialchars($row['roomType']) ?>"></div>
        <div class="mb-2"><label>Price</label><input type="number" step="0.01" name="price" class="form-control" required value="<?= htmlspecialchars($row['price']) ?>"></div>
        <div class="mb-2"><label>Status</label><select name="status" class="form-control"><option <?= $row['status']=='Available'?'selected':''?>>Available</option><option <?= $row['status']=='Occupied'?'selected':''?>>Occupied</option></select></div>
        <button class="btn btn-primary">Update</button>
        <a class="btn btn-secondary" href="index.php">Cancel</a>
      </form>
    </div>
      <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
  </body>
</html>
