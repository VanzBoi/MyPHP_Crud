<?php 
include_once __DIR__ . '/helpers.php';
if (!isset($baseUrl)) {
    require_once __DIR__ . '/database.php';
}
$navBase = rtrim($baseUrl, '/');
$currentUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
  <div class="container-fluid container">
    <a class="navbar-brand nav-brand" href="<?php echo $navBase; ?>/index.php">Hotel Reservation</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/guests') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/guests/index.php">Guests</a></li>
        <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/rooms') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/rooms/index.php">Rooms</a></li>
        <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/reservations') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/reservations/index.php">Reservations</a></li>
        <li class="nav-item"><a class="nav-link <?php echo (strpos($currentUri, '/monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/monitoring/index.php">Monitoring</a></li>
      </ul>
    </div>
  </div>
</nav>

<?php display_flash(); ?>