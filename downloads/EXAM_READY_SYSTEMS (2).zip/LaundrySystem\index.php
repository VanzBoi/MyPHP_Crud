﻿<?php
require_once 'database.php';

$totalServices = $conn->query("SELECT COUNT(*) FROM services")->fetch_row()[0];
$totalCustomers = $conn->query("SELECT COUNT(*) FROM customers")->fetch_row()[0];
$totalOrders = $conn->query("SELECT COUNT(*) FROM laundry_orders")->fetch_row()[0];
$totalRevenue = $conn->query("SELECT IFNULL(SUM(totalAmount), 0) FROM laundry_orders")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laundry System - Dashboard</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="p-4 mb-4 bg-white rounded-3 border">
            <h1 class="display-6 fw-bold">FreshClean Laundry Services</h1>
            <p class="lead text-muted mb-0">Dry Cleaning, Wash & Ironing Management</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Service Packages</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalServices; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Registered Customers</span>
                    <h3 class="mb-0 text-success"><?php echo $totalCustomers; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Total Laundry Orders</span>
                    <h3 class="mb-0 text-warning"><?php echo $totalOrders; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Total Revenue</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalRevenue, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Laundry Services</h5>
                    <p class="text-muted small">Manage wash types, per-kilo pricing, and service specifications.</p>
                    <a href="<?php echo $baseUrl; ?>services/index.php" class="btn btn-outline-primary mt-auto">Open Services &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Customer Profiles</h5>
                    <p class="text-muted small">Maintain client directory, contact numbers, and pickup/delivery addresses.</p>
                    <a href="<?php echo $baseUrl; ?>customers/index.php" class="btn btn-outline-success mt-auto">Open Customers &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Operations & Monitoring</h5>
                    <p class="text-muted small">Filter orders by service category and inspect total kilograms washed.</p>
                    <a href="<?php echo $baseUrl; ?>monitoring/index.php" class="btn btn-outline-dark mt-auto">Open Monitoring &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>