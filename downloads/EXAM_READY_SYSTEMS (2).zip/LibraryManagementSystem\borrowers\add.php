<?php
require_once '../database.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = is_string($_POST['fname'] ?? null) ? trim($_POST['fname']) : '';
    $lname = is_string($_POST['lname'] ?? null) ? trim($_POST['lname']) : '';
    $course = is_string($_POST['course'] ?? null) ? trim($_POST['course']) : '';
    $contact = is_string($_POST['contactNo'] ?? null) ? trim($_POST['contactNo']) : '';

    if ($fname === '' || $lname === '') {
        $err = 'Please enter borrower name.';
    } else {
        $stmt = $conn->prepare("INSERT INTO borrowers (fname, lname, course, contactNo) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fname, $lname, $course, $contact);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Failed to register borrower: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Borrower</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Register New Borrower</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">First Name</label>
                        <input type="text" name="fname" class="form-control" required placeholder="e.g. John Cedrick">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="lname" class="form-control" required placeholder="e.g. Libradilla">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Course / Academic Program</label>
                    <input type="text" name="course" class="form-control" required placeholder="e.g. BS Information Technology">
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="contactNo" class="form-control" required placeholder="e.g. 0917-123-4567">
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Save Borrower</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>