<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM customers WHERE customerID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$cust = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = is_string($_POST['custFName'] ?? null) ? trim($_POST['custFName']) : '';
    $lname = is_string($_POST['custLName'] ?? null) ? trim($_POST['custLName']) : '';
    $contact = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';
    $license = is_string($_POST['licenseNumber'] ?? null) ? trim($_POST['licenseNumber']) : '';

    $stmt = $conn->prepare("UPDATE customers SET custFName=?, custLName=?, contactNumber=?, licenseNumber=? WHERE customerID=?");
    $stmt->bind_param("ssssi", $fname, $lname, $contact, $license, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Customer</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Edit Customer</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">First Name</label>
                        <input type="text" name="custFName" class="form-control" required value="<?php echo htmlspecialchars($cust['custFName']); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="custLName" class="form-control" required value="<?php echo htmlspecialchars($cust['custLName']); ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="contactNumber" class="form-control" required value="<?php echo htmlspecialchars($cust['contactNumber']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Driver's License Number</label>
                    <input type="text" name="licenseNumber" class="form-control" required value="<?php echo htmlspecialchars($cust['licenseNumber']); ?>">
                </div>
                <button type="submit" class="btn btn-warning w-100">Update Customer</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>