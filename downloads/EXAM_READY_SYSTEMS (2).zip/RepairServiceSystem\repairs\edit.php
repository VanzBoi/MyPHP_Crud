<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM repairs WHERE repairID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$e1List = $conn->query("SELECT techID, techName FROM technicians ORDER BY techName ASC");
$e2List = $conn->query("SELECT applianceID, brandModel FROM appliances ORDER BY brandModel ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $techID = (int)($_POST['techID'] ?? 0);
    $applianceID = (int)($_POST['applianceID'] ?? 0);
    $repairDate = is_string($_POST['repairDate'] ?? null) ? trim($_POST['repairDate']) : '';
    $issueReported = is_string($_POST['issueReported'] ?? null) ? trim($_POST['issueReported']) : '';
    $totalCost = is_string($_POST['totalCost'] ?? null) ? trim($_POST['totalCost']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($techID <= 0 || $applianceID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "UPDATE repairs SET `techID` = '" . $conn->real_escape_string($techID) . "', `applianceID` = '" . $conn->real_escape_string($applianceID) . "', `repairDate` = '" . $conn->real_escape_string($repairDate) . "', `issueReported` = '" . $conn->real_escape_string($issueReported) . "', `totalCost` = '" . $conn->real_escape_string($totalCost) . "', `status` = '" . $conn->real_escape_string($status) . "' WHERE repairID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Repair Job #<?= $id ?> - Repair Service Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Repair Job #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Technician <span class="text-danger">*</span></label>
            <select name="techID" class="form-select" required>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['techID'] ?>" <?= ($row['techID'] == $e1Row['techID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e1Row['techName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Device/Appliance <span class="text-danger">*</span></label>
            <select name="applianceID" class="form-select" required>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['applianceID'] ?>" <?= ($row['applianceID'] == $e2Row['applianceID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e2Row['brandModel']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Job Date</label>
                <input type="date" name="repairDate" class="form-control" value="<?= htmlspecialchars($row['repairDate'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Issue Reported</label>
                <input type="text" name="issueReported" class="form-control" value="<?= htmlspecialchars($row['issueReported'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Total Cost (₱)</label>
                <input type="number" step="0.01" name="totalCost" class="form-control" value="<?= htmlspecialchars($row['totalCost'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Job Status</label>
                <select name="status" class="form-select" required>
                    <option value="Diagnostic" <?= ($row['status'] ?? '') === 'Diagnostic' ? 'selected' : '' ?>>Diagnostic</option>
<option value="In Progress" <?= ($row['status'] ?? '') === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
<option value="Repaired" <?= ($row['status'] ?? '') === 'Repaired' ? 'selected' : '' ?>>Repaired</option>
<option value="Released" <?= ($row['status'] ?? '') === 'Released' ? 'selected' : '' ?>>Released</option>
<option value="Cancelled" <?= ($row['status'] ?? '') === 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>