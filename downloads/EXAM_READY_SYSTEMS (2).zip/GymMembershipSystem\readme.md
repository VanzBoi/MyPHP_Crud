﻿# Gym Membership Management System

A simple PHP and MySQL web application for managing packages, members, and memberships.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\GymMembershipSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/GymMembershipSystem/
4. The database `gym_membership_system` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Packages**: Add, view, edit, and delete packages records.
- **Members**: Add, view, edit, and delete members records.
- **Memberships**: Manage memberships transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
