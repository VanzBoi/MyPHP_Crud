<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';

$q = is_string($_GET['q'] ?? null) ? trim($_GET['q']) : '';
if ($q !== '') {
    $safeQ = $mysqli->real_escape_string($q);
    $res = $mysqli->query("SELECT * FROM doctors WHERE docFName LIKE '%$safeQ%' OR docLName LIKE '%$safeQ%' OR docSpecial LIKE '%$safeQ%' ORDER BY docID DESC");
} else {
    $res = $mysqli->query("SELECT * FROM doctors ORDER BY docID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Doctors Management - Clinic Consultation</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
  <div class="mb-3">
    <h1>Doctors Management</h1>
    <small class="text-muted">Manage registered physicians and medical specialties</small>
  </div>

  <div class="card mb-4"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <a class="btn btn-primary" href="add.php">+ Add New Doctor</a>
      <form class="d-flex gap-2" method="get" style="max-width: 340px;">
        <input class="form-control" name="q" placeholder="Search name or specialty..." value="<?php echo e($q); ?>">
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if ($q): ?>
          <a href="index.php" class="btn btn-outline-secondary">Clear</a>
        <?php endif; ?>
      </form>
    </div>

    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Full Name</th>
          <th>Specialization</th>
          <th style="width: 140px;">Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php if ($res && $res->num_rows > 0): ?>
        <?php while ($row = $res->fetch_assoc()): ?>
          <tr>
            <td><?php echo e($row['docID']); ?></td>
            <td><strong>Dr. <?php echo e($row['docFName'] . ' ' . $row['docLName']); ?></strong></td>
            <td><span class="badge bg-info text-dark"><?php echo e($row['docSpecial']); ?></span></td>
            <td>
              <a class="btn btn-sm btn-warning" href="edit.php?id=<?php echo $row['docID']; ?>">Edit</a>
              <a class="btn btn-sm btn-danger ms-1" href="delete.php?id=<?php echo $row['docID']; ?>" onclick="return confirm('Delete doctor?');">Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="4" class="text-center text-muted py-3">No doctors found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  </div>
</div>
<script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
