<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM registrations WHERE registrationID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$e1List = $conn->query("SELECT workshopID, workshopTitle FROM workshops ORDER BY workshopTitle ASC");
$e2List = $conn->query("SELECT participantID, fullName FROM participants ORDER BY fullName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $workshopID = (int)($_POST['workshopID'] ?? 0);
    $participantID = (int)($_POST['participantID'] ?? 0);
    $registrationDate = is_string($_POST['registrationDate'] ?? null) ? trim($_POST['registrationDate']) : '';
    $amountPaid = is_string($_POST['amountPaid'] ?? null) ? trim($_POST['amountPaid']) : '';
    $paymentStatus = is_string($_POST['paymentStatus'] ?? null) ? trim($_POST['paymentStatus']) : '';
    $attendanceStatus = is_string($_POST['attendanceStatus'] ?? null) ? trim($_POST['attendanceStatus']) : '';

    if ($workshopID <= 0 || $participantID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "UPDATE registrations SET `workshopID` = '" . $conn->real_escape_string($workshopID) . "', `participantID` = '" . $conn->real_escape_string($participantID) . "', `registrationDate` = '" . $conn->real_escape_string($registrationDate) . "', `amountPaid` = '" . $conn->real_escape_string($amountPaid) . "', `paymentStatus` = '" . $conn->real_escape_string($paymentStatus) . "', `attendanceStatus` = '" . $conn->real_escape_string($attendanceStatus) . "' WHERE registrationID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Registration #<?= $id ?> - ICT Congress &amp; Workshop Registration System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Registration #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Workshop <span class="text-danger">*</span></label>
            <select name="workshopID" class="form-select" required>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['workshopID'] ?>" <?= ($row['workshopID'] == $e1Row['workshopID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e1Row['workshopTitle']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Participant <span class="text-danger">*</span></label>
            <select name="participantID" class="form-select" required>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['participantID'] ?>" <?= ($row['participantID'] == $e2Row['participantID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e2Row['fullName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Registration Date</label>
                <input type="date" name="registrationDate" class="form-control" value="<?= htmlspecialchars($row['registrationDate'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Amount Paid (₱)</label>
                <input type="number" step="0.01" name="amountPaid" class="form-control" value="<?= htmlspecialchars($row['amountPaid'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Payment Status</label>
                <select name="paymentStatus" class="form-select" required>
                    <option value="Paid" <?= ($row['paymentStatus'] ?? '') === 'Paid' ? 'selected' : '' ?>>Paid</option>
<option value="Pending" <?= ($row['paymentStatus'] ?? '') === 'Pending' ? 'selected' : '' ?>>Pending</option>
<option value="Waived" <?= ($row['paymentStatus'] ?? '') === 'Waived' ? 'selected' : '' ?>>Waived</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Attendance</label>
                <select name="attendanceStatus" class="form-select" required>
                    <option value="Registered" <?= ($row['attendanceStatus'] ?? '') === 'Registered' ? 'selected' : '' ?>>Registered</option>
<option value="Present" <?= ($row['attendanceStatus'] ?? '') === 'Present' ? 'selected' : '' ?>>Present</option>
<option value="Absent" <?= ($row['attendanceStatus'] ?? '') === 'Absent' ? 'selected' : '' ?>>Absent</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>