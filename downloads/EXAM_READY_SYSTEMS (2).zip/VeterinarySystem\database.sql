CREATE DATABASE IF NOT EXISTS veterinary_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE veterinary_db;

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS veterinarians (
  vetID INT AUTO_INCREMENT PRIMARY KEY,
  vetFName VARCHAR(100) NOT NULL,
  vetLName VARCHAR(100) NOT NULL,
  specialization VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS pets (
  petID INT AUTO_INCREMENT PRIMARY KEY,
  petName VARCHAR(100) NOT NULL,
  speciesBreed VARCHAR(100) NOT NULL,
  petAge VARCHAR(50) NOT NULL,
  ownerName VARCHAR(100) NOT NULL,
  ownerContact VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS treatments (
  treatmentID INT AUTO_INCREMENT PRIMARY KEY,
  vetID INT NOT NULL,
  petID INT NOT NULL,
  treatmentDate DATE NOT NULL,
  diagnosis VARCHAR(255) NOT NULL,
  medication VARCHAR(255) NOT NULL,
  treatmentFee DECIMAL(10,2) NOT NULL,
  status VARCHAR(50) DEFAULT 'Completed',
  FOREIGN KEY (vetID) REFERENCES veterinarians(vetID) ON DELETE CASCADE,
  FOREIGN KEY (petID) REFERENCES pets(petID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO veterinarians (vetFName, vetLName, specialization, contactNumber) VALUES
('Gabriel', 'Reyes', 'Surgery & Trauma', '0917-101-2020'),
('Elena', 'Santos', 'Canine & Feline Medicine', '0918-303-4040'),
('Marco', 'Dela Cruz', 'Dermatology & Allergy', '0922-505-6060');

INSERT INTO pets (petName, speciesBreed, petAge, ownerName, ownerContact) VALUES
('Brownie', 'Dog - Golden Retriever', '3 years', 'Ana Gomez', '0917-123-4567'),
('Milo', 'Cat - Persian', '2 years', 'John Perez', '0918-987-6543'),
('Luna', 'Dog - Shih Tzu', '1 year', 'Carla Lim', '0922-777-8888'),
('Simba', 'Cat - Domestic Shorthair', '4 years', 'David Tan', '0920-555-4444');

INSERT INTO treatments (vetID, petID, treatmentDate, diagnosis, medication, treatmentFee, status) VALUES
(1, 1, '2026-10-22', 'Post-Op Knee Checkup', 'Anti-inflammatory 20mg', 1500.00, 'Completed'),
(2, 2, '2026-10-23', 'Annual Rabies & 5-in-1 Vaccine', 'Rabies Shot + Vitamins', 850.00, 'Completed'),
(3, 3, '2026-10-24', 'Flea & Skin Dermatitis', 'Medicated Shampoo + Ointment', 1200.00, 'Completed'),
(2, 4, '2026-10-25', 'Ear Mite Infection', 'Ear Drops (Twice Daily)', 650.00, 'Completed');

SET FOREIGN_KEY_CHECKS=1;