<?php
// Global navigation bar
$cur = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= $baseUrl ?>index.php">Warehouse Inventory &amp; Stock Management System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (strpos($cur, '/index.php') !== false && strpos($cur, '/suppliers') === false && strpos($cur, '/products') === false && strpos($cur, '/stock_movements') === false && strpos($cur, '/monitoring') === false) ? 'active' : '' ?>" href="<?= $baseUrl ?>index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/suppliers/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>suppliers/index.php">Supplier</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/products/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>products/index.php">Product</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/stock_movements/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>stock_movements/index.php">Stock Movement</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/monitoring/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>