<?php
require_once '../database.php';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}
$res = $conn->query("SELECT * FROM payroll WHERE payrollID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$pay = $res->fetch_assoc();
$employees = $conn->query("SELECT e.*, p.positionName FROM employees e JOIN positions p ON e.positionID = p.positionID ORDER BY e.empFName ASC");
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $empID = (int)($_POST['empID'] ?? 0);
    $payDate = is_string($_POST['payDate'] ?? null) ? trim($_POST['payDate']) : '';
    $basic = floatval($_POST['basicSalary'] ?? 0);
    $allowance = floatval($_POST['allowance'] ?? 0);
    $deduction = floatval($_POST['deduction'] ?? 0);
    $netPay = $basic + $allowance - $deduction;

    if ($empID <= 0 || $payDate === '') {
        $err = 'Please select an employee and pay date.';
    } else {
        $sql = "UPDATE payroll SET `empID` = '" . $conn->real_escape_string($empID) . "', `payDate` = '" . $conn->real_escape_string($payDate) . "', `basicSalary` = '" . $conn->real_escape_string($basic) . "', `allowance` = '" . $conn->real_escape_string($allowance) . "', `deduction` = '" . $conn->real_escape_string($deduction) . "', `netPay` = '" . $conn->real_escape_string($netPay) . "' WHERE payrollID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Failed to update transaction: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Payroll</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 650px;">
        <div class="card p-4">
            <h4 class="mb-3">Edit Payroll Slip</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Employee</label>
                    <select name="empID" class="form-select" required>
                        <?php while($e = $employees->fetch_assoc()): ?>
                            <option value="<?php echo $e['empID']; ?>" <?php echo ($e['empID'] == $pay['empID']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($e['empFName'] . ' ' . $e['empLName'] . ' (' . $e['positionName'] . ')'); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Pay Date</label>
                    <input type="date" name="payDate" class="form-control" value="<?php echo $pay['payDate']; ?>" required>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Basic Salary (₱)</label>
                        <input type="number" step="0.01" name="basicSalary" id="basicSalary" class="form-control" value="<?php echo $pay['basicSalary']; ?>" required oninput="calculateNet()">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Allowance (₱)</label>
                        <input type="number" step="0.01" name="allowance" id="allowance" class="form-control" value="<?php echo $pay['allowance']; ?>" oninput="calculateNet()">
                    </div>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Deductions (₱)</label>
                        <input type="number" step="0.01" name="deduction" id="deduction" class="form-control" value="<?php echo $pay['deduction']; ?>" oninput="calculateNet()">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Net Pay (₱)</label>
                        <input type="text" id="netPayDisplay" class="form-control fw-bold text-success" readonly value="₱<?php echo number_format($pay['netPay'], 2); ?>">
                    </div>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Slip</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        function calculateNet() {
            const basic = parseFloat(document.getElementById('basicSalary').value) || 0;
            const allowance = parseFloat(document.getElementById('allowance').value) || 0;
            const deduction = parseFloat(document.getElementById('deduction').value) || 0;
            const net = (basic + allowance) - deduction;
            document.getElementById('netPayDisplay').value = '₱' + net.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
        }
    </script>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>