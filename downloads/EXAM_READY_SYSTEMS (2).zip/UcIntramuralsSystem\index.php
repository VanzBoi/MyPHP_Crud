﻿<?php
require_once 'database.php';

$totalDepts = $conn->query("SELECT COUNT(*) FROM departments")->fetch_row()[0];
$totalAthletes = $conn->query("SELECT COUNT(*) FROM athletes")->fetch_row()[0];
$totalTournaments = $conn->query("SELECT COUNT(*) FROM tournaments")->fetch_row()[0];
$totalFees = $conn->query("SELECT IFNULL(SUM(regFee), 0) FROM tournaments")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>UC Intramurals System - Dashboard</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="p-4 mb-4 bg-white rounded-3 border">
            <h1 class="display-6 fw-bold">University Intramurals Tournament System</h1>
            <p class="lead text-muted mb-0">Department Rosters & Sports Bracket Management</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Colleges & Departments</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalDepts; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Registered Athletes</span>
                    <h3 class="mb-0 text-success"><?php echo $totalAthletes; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Tournament Registrations</span>
                    <h3 class="mb-0 text-dark"><?php echo $totalTournaments; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Total Registration Fees</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalFees, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>College Departments</h5>
                    <p class="text-muted small">Manage university academic units, college codes, and assigned college deans.</p>
                    <a href="<?php echo $baseUrl; ?>departments/index.php" class="btn btn-outline-primary mt-auto">Open Departments &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Student Athlete Profiles</h5>
                    <p class="text-muted small">Maintain official team rosters, student IDs, year levels, and emergency contacts.</p>
                    <a href="<?php echo $baseUrl; ?>athletes/index.php" class="btn btn-outline-success mt-auto">Open Athletes &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Tournaments & Standings</h5>
                    <p class="text-muted small">Schedule matches, manage tournament brackets, and analyze department registration summaries.</p>
                    <a href="<?php echo $baseUrl; ?>monitoring/index.php" class="btn btn-outline-dark mt-auto">Open Monitoring &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>