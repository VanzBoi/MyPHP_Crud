<?php include '../database.php'; include '../helpers.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($_SERVER['REQUEST_METHOD']==='POST'){
  $guest = (int)($_POST['guestID'] ?? 0);
  $room = (int)($_POST['roomID'] ?? 0);
  $in = is_string($_POST['checkIn'] ?? null) ? trim($_POST['checkIn']) : '';
  $out = is_string($_POST['checkOut'] ?? null) ? trim($_POST['checkOut']) : '';

  $validDates = false;
  $nights = 0;
  if ($in !== '' && $out !== '') {
    try {
      $d1 = new DateTime($in);
      $d2 = new DateTime($out);
      $nights = max(0, $d2->diff($d1)->days);
      $validDates = true;
    } catch (\Exception $e) {
      set_flash('Invalid reservation dates provided.', 'error');
    }
  } else {
    set_flash('Please provide valid check-in and check-out dates.', 'error');
  }

  if ($guest > 0 && $room > 0 && $validDates) {
    $r = mysqli_query($conn, "SELECT price FROM rooms WHERE roomID={$room}");
    $rr = $r ? mysqli_fetch_assoc($r) : null;
    $price = $rr ? (float)$rr['price'] : 0;
    $total = $nights * $price;
    $escIn = mysqli_real_escape_string($conn, $in);
    $escOut = mysqli_real_escape_string($conn, $out);
    if (mysqli_query($conn, "UPDATE reservations SET guestID={$guest}, roomID={$room}, checkIn='{$escIn}', checkOut='{$escOut}', totalPaid={$total} WHERE reserveID={$id}")) {
      set_flash('Reservation updated. Total: '.number_format($total,2), 'success');
      header('Location: index.php'); exit;
    } else {
      set_flash('Failed to update reservation: ' . mysqli_error($conn), 'error');
    }
  }
}
$res = mysqli_query($conn, "SELECT * FROM reservations WHERE reserveID={$id}");
$row = $res ? mysqli_fetch_assoc($res) : null;
if (!$row) {
    header('Location: index.php');
    exit;
}
$guests = mysqli_query($conn, "SELECT guestID,fName,lName FROM guests");
$rooms = mysqli_query($conn, "SELECT roomID,roomNo,roomType,price FROM rooms");
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Reservation</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
  </head>
  <body>
    <?php include '../navbar.php'; ?>
    <div class="container">
      <h4>Edit Reservation</h4>
      <form method="post">
        <div class="mb-2"><label>Guest</label><select name="guestID" class="form-control" required>
          <?php while($g = mysqli_fetch_assoc($guests)): ?>
            <option value="<?= $g['guestID'] ?>" <?= $g['guestID']==$row['guestID']?'selected':''?>><?= htmlspecialchars($g['fName'].' '.$g['lName']) ?></option>
          <?php endwhile; ?>
        </select></div>
        <div class="mb-2"><label>Room</label><select name="roomID" class="form-control" required>
          <?php while($rm = mysqli_fetch_assoc($rooms)): ?>
            <option value="<?= $rm['roomID'] ?>" <?= $rm['roomID']==$row['roomID']?'selected':''?>><?= htmlspecialchars($rm['roomNo'].' - '.$rm['roomType'].' ('.number_format($rm['price'],2).')') ?></option>
          <?php endwhile; ?>
        </select></div>
        <div class="mb-2"><label>Check-in</label><input type="date" name="checkIn" class="form-control" required value="<?= $row['checkIn'] ?>"></div>
        <div class="mb-2"><label>Check-out</label><input type="date" name="checkOut" class="form-control" required value="<?= $row['checkOut'] ?>"></div>
        <button class="btn btn-primary">Update</button>
        <a class="btn btn-secondary" href="index.php">Cancel</a>
      </form>
    </div>
      <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
  </body>
</html>
