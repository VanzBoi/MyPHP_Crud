﻿<?php
require_once 'database.php';

$totalVehicles = $conn->query("SELECT COUNT(*) FROM vehicles")->fetch_row()[0];
$totalCustomers = $conn->query("SELECT COUNT(*) FROM customers")->fetch_row()[0];
$totalRentals = $conn->query("SELECT COUNT(*) FROM rentals")->fetch_row()[0];
$totalRevenue = $conn->query("SELECT IFNULL(SUM(totalFee), 0) FROM rentals")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Rental System - Dashboard</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="p-4 mb-4 bg-white rounded-3 border">
            <h1 class="display-6 fw-bold">Car Rental Management System</h1>
            <p class="lead text-muted mb-0">Vehicle Fleet and Customer Reservation Portal</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Total Vehicles</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalVehicles; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Registered Customers</span>
                    <h3 class="mb-0 text-success"><?php echo $totalCustomers; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Total Rentals</span>
                    <h3 class="mb-0 text-warning"><?php echo $totalRentals; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Total Revenue</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalRevenue, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Vehicle Management</h5>
                    <p class="text-muted small">Add, update, search, and manage rental fleet inventory.</p>
                    <a href="<?php echo $baseUrl; ?>vehicles/index.php" class="btn btn-outline-primary mt-auto">Manage Vehicles &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Customer Records</h5>
                    <p class="text-muted small">Add customer details, driver licenses, and contact information.</p>
                    <a href="<?php echo $baseUrl; ?>customers/index.php" class="btn btn-outline-success mt-auto">Manage Customers &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Rental Transactions & Report</h5>
                    <p class="text-muted small">Process vehicle bookings and view the monitoring report.</p>
                    <a href="<?php echo $baseUrl; ?>monitoring/index.php" class="btn btn-outline-dark mt-auto">Open Monitoring &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>