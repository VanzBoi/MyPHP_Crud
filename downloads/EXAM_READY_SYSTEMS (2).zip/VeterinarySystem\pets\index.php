<?php
require_once '../database.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
if ($search !== '') {
    $stmt = $conn->prepare("SELECT * FROM pets WHERE petName LIKE ? OR speciesBreed LIKE ? OR ownerName LIKE ? ORDER BY petID DESC");
    $param = "%$search%";
    $stmt->bind_param("sss", $param, $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM pets ORDER BY petID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pets & Patients</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Pets & Patients Registry</h3>
            <a href="add.php" class="btn btn-primary">+ Register New Pet</a>
        </div>
        <div class="card p-3 mb-3">
            <form method="GET" class="row g-2">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="Search by pet name, breed, or owner..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-secondary w-100">Search</button>
                </div>
            </form>
        </div>
        <div class="card mb-3">
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Pet Name</th>
                        <th>Species & Breed</th>
                        <th>Age</th>
                        <th>Owner Name</th>
                        <th>Owner Contact</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['petID']; ?></td>
                            <td><strong> <?php echo htmlspecialchars($row['petName']); ?></strong></td>
                            <td><?php echo htmlspecialchars($row['speciesBreed']); ?></td>
                            <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($row['petAge']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['ownerName']); ?></td>
                            <td><?php echo htmlspecialchars($row['ownerContact']); ?></td>
                            <td class="text-end">
                                <a href="edit.php?id=<?php echo $row['petID']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete.php?id=<?php echo $row['petID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete pet record?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">No pets registered.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>