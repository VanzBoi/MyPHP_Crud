CREATE DATABASE IF NOT EXISTS car_rental_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE car_rental_db;

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS vehicles (
  vehicleID INT AUTO_INCREMENT PRIMARY KEY,
  plateNumber VARCHAR(50) NOT NULL UNIQUE,
  brandModel VARCHAR(100) NOT NULL,
  vehicleType VARCHAR(50) NOT NULL,
  dailyRate DECIMAL(10,2) NOT NULL,
  status VARCHAR(20) DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
  customerID INT AUTO_INCREMENT PRIMARY KEY,
  custFName VARCHAR(100) NOT NULL,
  custLName VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL,
  licenseNumber VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rentals (
  rentalID INT AUTO_INCREMENT PRIMARY KEY,
  vehicleID INT NOT NULL,
  customerID INT NOT NULL,
  rentalDate DATE NOT NULL,
  returnDate DATE NOT NULL,
  totalDays INT NOT NULL,
  totalFee DECIMAL(10,2) NOT NULL,
  paymentMode VARCHAR(50) NOT NULL,
  FOREIGN KEY (vehicleID) REFERENCES vehicles(vehicleID) ON DELETE CASCADE,
  FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO vehicles (plateNumber, brandModel, vehicleType, dailyRate, status) VALUES
('ABC-1234', 'Toyota Vios', 'Sedan', 1500.00, 'Available'),
('XYZ-8888', 'Mitsubishi Montero', 'SUV', 2800.00, 'Available'),
('VAN-5555', 'Toyota HiAce Grandia', 'Van', 3500.00, 'Available'),
('SED-9921', 'Honda City', 'Sedan', 1600.00, 'Available');

INSERT INTO customers (custFName, custLName, contactNumber, licenseNumber) VALUES
('Carlos', 'Mendoza', '09171112233', 'N01-12-345678'),
('Patricia', 'Reyes', '09182223344', 'N02-98-765432'),
('Michael', 'Tan', '09223334455', 'N03-55-123456');

INSERT INTO rentals (vehicleID, customerID, rentalDate, returnDate, totalDays, totalFee, paymentMode) VALUES
(1, 1, '2026-10-20', '2026-10-23', 3, 4500.00, 'Cash'),
(2, 2, '2026-10-21', '2026-10-25', 4, 11200.00, 'GCash'),
(3, 3, '2026-10-22', '2026-10-24', 2, 7000.00, 'Card');

SET FOREIGN_KEY_CHECKS=1;