<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo $baseUrl; ?>index.php">UC Intramurals Tournament System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'departments') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>departments/index.php">Departments</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'athletes') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>athletes/index.php">Athletes</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'tournaments') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>tournaments/index.php">Tournaments</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>