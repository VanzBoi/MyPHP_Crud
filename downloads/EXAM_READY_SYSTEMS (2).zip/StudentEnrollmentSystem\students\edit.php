<?php
require '../database.php';
require '../helpers.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    redirect('index.php');
}

$stmt = $mysqli->prepare('SELECT * FROM students WHERE studentID = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
if (!$student) {
    redirect('index.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = is_string($_POST['fname'] ?? null) ? trim($_POST['fname']) : '';
    $lname = is_string($_POST['lname'] ?? null) ? trim($_POST['lname']) : '';
    $course = is_string($_POST['course'] ?? null) ? trim($_POST['course']) : '';
    $yearLevel = is_string($_POST['yearLevel'] ?? null) ? trim($_POST['yearLevel']) : '';
    $contactNo = is_string($_POST['contactNo'] ?? null) ? trim($_POST['contactNo']) : '';

    if ($fname === '') $errors[] = 'First name is required.';
    if ($lname === '') $errors[] = 'Last name is required.';
    if ($course === '') $errors[] = 'Course is required.';
    if ($yearLevel === '' || !ctype_digit($yearLevel)) $errors[] = 'Valid year level is required.';
    if ($contactNo === '') $errors[] = 'Contact number is required.';

    if (!$errors) {
        $stmt = $mysqli->prepare('UPDATE students SET fname = ?, lname = ?, course = ?, yearLevel = ?, contactNo = ? WHERE studentID = ?');
        $stmt->bind_param('sssisi', $fname, $lname, $course, $yearLevel, $contactNo, $id);
        $stmt->execute();
        flash('Student updated successfully.');
        redirect('index.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Student</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
  <?php include '../navbar.php'; ?>
  <main class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="h3 mb-0">Edit Student</h1>
      </div>
      <a class="btn btn-secondary" href="index.php">Back to Students</a>
    </div>

    <?php if ($errors) : ?>
      <div class="alert alert-danger">
        <ul class="mb-0">
          <?php foreach ($errors as $error) : ?>
            <li><?= e($error) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form class="row g-3" action="edit.php?id=<?= e($id) ?>" method="post">
      <div class="col-md-6">
        <label for="fname" class="form-label">First Name</label>
        <input id="fname" name="fname" value="<?= e($_POST['fname'] ?? $student['fname']) ?>" required class="form-control">
      </div>
      <div class="col-md-6">
        <label for="lname" class="form-label">Last Name</label>
        <input id="lname" name="lname" value="<?= e($_POST['lname'] ?? $student['lname']) ?>" required class="form-control">
      </div>
      <div class="col-md-6">
        <label for="course" class="form-label">Course</label>
        <input id="course" name="course" value="<?= e($_POST['course'] ?? $student['course']) ?>" required class="form-control">
      </div>
      <div class="col-md-3">
        <label for="yearLevel" class="form-label">Year Level</label>
        <input id="yearLevel" name="yearLevel" value="<?= e($_POST['yearLevel'] ?? $student['yearLevel']) ?>" required class="form-control">
      </div>
      <div class="col-md-3">
        <label for="contactNo" class="form-label">Contact Number</label>
        <input id="contactNo" name="contactNo" value="<?= e($_POST['contactNo'] ?? $student['contactNo']) ?>" required class="form-control">
      </div>
      <div class="col-12 d-grid">
        <button class="btn btn-primary" type="submit">Update Student</button>
      </div>
    </form>
  </main>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
