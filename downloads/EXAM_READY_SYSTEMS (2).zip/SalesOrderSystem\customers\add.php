<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = is_string($_POST['customerName'] ?? null) ? trim($_POST['customerName']) : '';
$contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';
$customerCity = is_string($_POST['customerCity'] ?? null) ? trim($_POST['customerCity']) : '';
$membershipLevel = is_string($_POST['membershipLevel'] ?? null) ? trim($_POST['membershipLevel']) : '';

    $sql = "INSERT INTO customers (`customerName`, `contactNumber`, `customerCity`, `membershipLevel`) VALUES ('" . $conn->real_escape_string($customerName) . "', '" . $conn->real_escape_string($contactNumber) . "', '" . $conn->real_escape_string($customerCity) . "', '" . $conn->real_escape_string($membershipLevel) . "')";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to add record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Customer - Sales &amp; Order Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Add New Customer</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Customer Name</label>
                <input type="text" name="customerName" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Contact Number</label>
                <input type="text" name="contactNumber" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">City</label>
                <input type="text" name="customerCity" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Membership</label>
                <select name="membershipLevel" class="form-select" required>
                    <option value="Regular">Regular</option>
<option value="Silver">Silver</option>
<option value="Gold">Gold</option>
<option value="VIP">VIP</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Customer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>