<?php
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/helpers.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Enrollment System</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
  <?php include 'navbar.php'; ?>
  <main class="container">
    <div class="page-heading mb-4">
      <h1>Student Enrollment System</h1>
      <p class="text-muted">Manage student registrations, subject offerings, enrollment billing, and monitoring.</p>
    </div>

    <?php if ($message = flash()) : ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= e($message) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>

    <div class="card mb-3">
      <div class="card-header fw-bold">System Navigation</div>
      <div class="card-body">
        <div class="list-group">
          <a href="students/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Students Management</span> <span class="text-muted">&rarr;</span></a>
          <a href="subjects/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Subjects Management</span> <span class="text-muted">&rarr;</span></a>
          <a href="enrollment/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Enrollments Management</span> <span class="text-muted">&rarr;</span></a>
          <a href="monitoring/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Monitoring & Reports</span> <span class="badge bg-primary">Monitoring</span></a>
        </div>
      </div>
    </div>
  </main>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
