<?php
require_once __DIR__ . '/../database.php';

$sql = "SELECT t.*, e1.fullName AS e1_title, e2.typeName AS e2_title 
        FROM `clearances` t 
        JOIN `residents` e1 ON t.residentID = e1.residentID 
        JOIN `clearance_types` e2 ON t.typeID = e2.typeID 
        ORDER BY t.clearanceID DESC";
$records = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Clearance Issuances - Barangay Clearance & Certification System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Manage Clearance Issuances</h3>
            <a href="add.php" class="btn btn-primary">+ Record New Clearance Issuance</a>
        </div>

        <div class="card border-0 shadow-sm bg-white">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0 align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Resident</th>
                            <th>Clearance Type</th>
                            <th>Date Issued</th>
<th>Purpose</th>
<th>Amount Paid</th>
<th>Status</th>

                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records && $records->num_rows > 0): ?>
                            <?php while ($r = $records->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['clearanceID'] ?></td>
                                    <td class="fw-bold"><?= htmlspecialchars($r['e1_title']) ?></td>
                                    <td><?= htmlspecialchars($r['e2_title']) ?></td>
                                    <td><?= htmlspecialchars($r['issueDate']) ?></td>
<td><?= htmlspecialchars($r['purpose']) ?></td>
<td><?= htmlspecialchars($r['amountPaid']) ?></td>
<td><?= htmlspecialchars($r['status']) ?></td>

                                    <td class="text-end">
                                        <a href="delete.php?id=<?= $r['clearanceID'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this transaction record?');">Delete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">No transaction records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>
