<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $packageName = is_string($_POST['packageName'] ?? null) ? trim($_POST['packageName']) : '';
    $description = is_string($_POST['description'] ?? null) ? trim($_POST['description']) : '';
    $duration = intval($_POST['duration'] ?? 0);
    $fee = floatval($_POST['fee'] ?? 0);
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : 'Active';

    if ($packageName === '' || $duration <= 0 || $fee <= 0) {
        $errors[] = 'Please provide the package name, duration, and fee.';
    }

    if (!$errors) {
        $stmt = mysqli_prepare($conn, 'INSERT INTO packages (packageName, description, duration, fee, status) VALUES (?, ?, ?, ?, ?)');
        mysqli_stmt_bind_param($stmt, 'ssids', $packageName, $description, $duration, $fee, $status);
        mysqli_stmt_execute($stmt);
        flash('Package added successfully.');
        redirect('index.php');
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Package - Gym Membership</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>
    <div class="container">
        <div class="py-3">
            <h2>Add Package</h2>
            <?php if ($errors): ?>
                <div class="alert alert-danger"><ul><?php foreach ($errors as $error): ?><li><?php echo escape($error); ?></li><?php endforeach; ?></ul></div>
            <?php endif; ?>
            <form method="post" action="add.php">
                <div class="mb-3"><label class="form-label">Package Name</label><input type="text" name="packageName" class="form-control" value="<?php echo escape($_POST['packageName'] ?? ''); ?>"></div>
                <div class="mb-3"><label class="form-label">Description</label><textarea name="description" class="form-control"><?php echo escape($_POST['description'] ?? ''); ?></textarea></div>
                <div class="row g-3">
                    <div class="col-md-4"><label class="form-label">Duration (Months)</label><input type="number" name="duration" class="form-control" value="<?php echo escape($_POST['duration'] ?? ''); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Fee</label><input type="number" step="0.01" name="fee" class="form-control" value="<?php echo escape($_POST['fee'] ?? ''); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Status</label><select name="status" class="form-select"><option value="Active" <?php echo (($_POST['status'] ?? '') === 'Active') ? 'selected' : ''; ?>>Active</option><option value="Inactive" <?php echo (($_POST['status'] ?? '') === 'Inactive') ? 'selected' : ''; ?>>Inactive</option></select></div>
                </div>
                <div class="mt-4"><button type="submit" class="btn btn-primary">Save Package</button> <a href="index.php" class="btn btn-secondary">Cancel</a></div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
