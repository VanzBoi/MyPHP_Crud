﻿<?php
require_once 'database.php';

$totalRoles = $conn->query("SELECT COUNT(*) FROM roles")->fetch_row()[0];
$totalUsers = $conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0];
$totalAssigns = $conn->query("SELECT COUNT(*) FROM assignments")->fetch_row()[0];
$totalStipend = $conn->query("SELECT IFNULL(SUM(allowance), 0) FROM assignments")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Role & Access System - Dashboard</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="p-4 mb-4 bg-white rounded-3 border">
            <h1 class="display-6 fw-bold">User Role & Access Assignment System</h1>
            <p class="lead text-muted mb-0">Institutional Roles, Personnel Accounts & Privilege Assignments</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">System Security Roles</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalRoles; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Registered Personnel</span>
                    <h3 class="mb-0 text-success"><?php echo $totalUsers; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Active Assignments</span>
                    <h3 class="mb-0 text-dark"><?php echo $totalAssigns; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Total Stipend Allowances</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalStipend, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Roles & Permissions</h5>
                    <p class="text-muted small">Define security access levels, department categories, and role stipend rates.</p>
                    <a href="<?php echo $baseUrl; ?>roles/index.php" class="btn btn-outline-primary mt-auto">Open Roles &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>User Profiles</h5>
                    <p class="text-muted small">Manage faculty, staff, and student accounts, official emails, and mobile contacts.</p>
                    <a href="<?php echo $baseUrl; ?>users/index.php" class="btn btn-outline-success mt-auto">Open Users &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Access Monitoring</h5>
                    <p class="text-muted small">Track active role authorizations per department, inspect stipend grants, and view summaries.</p>
                    <a href="<?php echo $baseUrl; ?>monitoring/index.php" class="btn btn-outline-dark mt-auto">Open Monitoring &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>