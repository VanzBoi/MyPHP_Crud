<?php include '../database.php'; ?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reservations Management</title>
      <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
  </head>
  <body>
    <?php include '../navbar.php'; ?>
    <div class="container">
      <div class="mb-3">
        <h1>Reservations Management</h1>
        <small class="text-muted">Process guest bookings and compute total payments</small>
      </div>

      <div class="card mb-4"><div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <a class="btn btn-primary" href="add.php">+ Process New Reservation</a>
          <a class="btn btn-outline-primary" href="../monitoring/index.php">View Monitoring Report &rarr;</a>
        </div>

        <?php
        $q = "SELECT r.*, g.fName, g.lName, rm.roomNo, rm.roomType FROM reservations r
              JOIN guests g ON r.guestID=g.guestID
              JOIN rooms rm ON r.roomID=rm.roomID
              ORDER BY r.reserveID DESC";
        $res = mysqli_query($conn, $q);
        ?>
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Guest Name</th>
              <th>Room Assigned</th>
              <th>Check-In</th>
              <th>Check-Out</th>
              <th>Total Paid</th>
              <th style="width: 140px;">Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php if ($res && mysqli_num_rows($res) > 0): ?>
            <?php while($r = mysqli_fetch_assoc($res)): ?>
              <tr>
                <td><?= $r['reserveID'] ?></td>
                <td><strong><?= htmlspecialchars($r['fName'].' '.$r['lName']) ?></strong></td>
                <td><span class="badge bg-info text-dark"><?= htmlspecialchars($r['roomNo'].' ('.$r['roomType'].')') ?></span></td>
                <td><?= htmlspecialchars($r['checkIn']) ?></td>
                <td><?= htmlspecialchars($r['checkOut']) ?></td>
                <td><strong class="text-success fs-6">₱<?= number_format($r['totalPaid'], 2) ?></strong></td>
                <td>
                  <a class="btn btn-sm btn-warning" href="edit.php?id=<?= $r['reserveID'] ?>">Edit</a>
                  <a class="btn btn-sm btn-danger ms-1" href="delete.php?id=<?= $r['reserveID'] ?>" onclick="return confirm('Delete this reservation?')">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="7" class="text-center text-muted py-3">No reservations found.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
      </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
  </body>
</html>
