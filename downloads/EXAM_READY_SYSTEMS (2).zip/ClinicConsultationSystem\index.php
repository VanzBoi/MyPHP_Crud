<?php
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/helpers.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Clinic Consultation System</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container">
  <div class="page-heading mb-4">
    <h1>Clinic Consultation System</h1>
    <p class="text-muted">Manage doctor registries, patient profiles, medical consultations, and analytics.</p>
  </div>

  <div class="card mb-3">
    <div class="card-header fw-bold">System Navigation</div>
    <div class="card-body">
      <div class="list-group">
        <a href="doctors/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Doctors Management</span> <span class="text-muted">&rarr;</span></a>
        <a href="patients/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Patients Management</span> <span class="text-muted">&rarr;</span></a>
        <a href="consultations/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Consultations Logging</span> <span class="text-muted">&rarr;</span></a>
        <a href="monitoring/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Monitoring & Inquiry</span> <span class="badge bg-primary">Monitoring</span></a>
      </div>
    </div>
  </div>
</div>
<script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
