﻿# Hotel Reservation Management System

A simple PHP and MySQL web application for managing rooms, guests, and reservations.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\HotelReservationSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/HotelReservationSystem/
4. The database `hotel_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Rooms**: Add, view, edit, and delete rooms records.
- **Guests**: Add, view, edit, and delete guests records.
- **Reservations**: Manage reservations transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
