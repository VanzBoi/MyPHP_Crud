-- Simple schema for Hotel Reservation System
CREATE DATABASE IF NOT EXISTS `hotel_db` DEFAULT CHARACTER SET utf8mb4;
USE `hotel_db`;

CREATE TABLE IF NOT EXISTS `guests` (
  `guestID` INT AUTO_INCREMENT PRIMARY KEY,
  `fName` VARCHAR(100) NOT NULL,
  `lName` VARCHAR(100) NOT NULL,
  `address` TEXT,
  `contactNo` VARCHAR(50)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `rooms` (
  `roomID` INT AUTO_INCREMENT PRIMARY KEY,
  `roomNo` VARCHAR(50) NOT NULL,
  `roomType` VARCHAR(50) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `status` VARCHAR(20) NOT NULL DEFAULT 'Available'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `reservations` (
  `reserveID` INT AUTO_INCREMENT PRIMARY KEY,
  `guestID` INT NOT NULL,
  `roomID` INT NOT NULL,
  `checkIn` DATE NOT NULL,
  `checkOut` DATE NOT NULL,
  `totalPaid` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  FOREIGN KEY (`guestID`) REFERENCES `guests`(`guestID`) ON DELETE CASCADE,
  FOREIGN KEY (`roomID`) REFERENCES `rooms`(`roomID`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- sample data
INSERT INTO `guests` (`fName`,`lName`,`address`,`contactNo`) VALUES
('Juan','Dela Cruz','Cebu City','09171234567'),
('Maria','Santos','Mandaue','09181234567');

INSERT INTO `rooms` (`roomNo`,`roomType`,`price`,`status`) VALUES
('101','Standard',1500.00,'Available'),
('102','Deluxe',2500.00,'Available'),
('201','VIP',5000.00,'Available');
