<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$query = 'SELECT * FROM packages';
$params = [];
if ($search !== '') {
    $query .= ' WHERE packageName LIKE ? OR description LIKE ?';
    $params = ["%{$search}%", "%{$search}%"];
}
$stmt = mysqli_prepare($conn, $query);
if ($params) {
    mysqli_stmt_bind_param($stmt, 'ss', ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Packages - Gym Membership</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Packages</h2>
            <a href="add.php" class="btn btn-success">Add Package</a>
        </div>
        <?php if ($flash = flash()): ?>
            <div class="alert alert-<?php echo escape($flash['type'] ?? 'success'); ?>"><?php echo escape($flash['message'] ?? ''); ?></div>
        <?php endif; ?>
        <form class="row g-2 mb-3" method="get" action="index.php">
            <div class="col-md-10">
                <input type="search" name="search" class="form-control" placeholder="Search packages by name or description" value="<?php echo escape($search); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Search</button>
            </div>
        </form>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Package Name</th>
                        <th>Description</th>
                        <th>Duration (Months)</th>
                        <th>Fee</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($package = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo escape($package['packageID']); ?></td>
                            <td><?php echo escape($package['packageName']); ?></td>
                            <td><?php echo escape($package['description']); ?></td>
                            <td><?php echo escape($package['duration']); ?></td>
                            <td><?php echo escape($package['fee']); ?></td>
                            <td><?php echo escape($package['status']); ?></td>
                            <td>
                                <a href="edit.php?id=<?php echo escape($package['packageID']); ?>" class="btn btn-sm btn-primary">Edit</a>
                                <a href="delete.php?id=<?php echo escape($package['packageID']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this package?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
