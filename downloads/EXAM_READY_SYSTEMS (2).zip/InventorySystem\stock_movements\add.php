<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT supplierID, supplierName FROM suppliers ORDER BY supplierName ASC");
$e2List = $conn->query("SELECT productID, productName FROM products ORDER BY productName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $supplierID = (int)($_POST['supplierID'] ?? 0);
    $productID = (int)($_POST['productID'] ?? 0);
    $movementDate = is_string($_POST['movementDate'] ?? null) ? trim($_POST['movementDate']) : '';
    $movementType = is_string($_POST['movementType'] ?? null) ? trim($_POST['movementType']) : '';
    $quantity = is_string($_POST['quantity'] ?? null) ? trim($_POST['quantity']) : '';
    $totalValue = is_string($_POST['totalValue'] ?? null) ? trim($_POST['totalValue']) : '';

    if ($supplierID <= 0 || $productID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "INSERT INTO stock_movements (`supplierID`, `productID`, `movementDate`, `movementType`, `quantity`, `totalValue`) VALUES ('" . $conn->real_escape_string($supplierID) . "', '" . $conn->real_escape_string($productID) . "', '" . $conn->real_escape_string($movementDate) . "', '" . $conn->real_escape_string($movementType) . "', '" . $conn->real_escape_string($quantity) . "', '" . $conn->real_escape_string($totalValue) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Stock Movement - Warehouse Inventory &amp; Stock Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Record New Stock Movement</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Supplier <span class="text-danger">*</span></label>
            <select name="supplierID" class="form-select" required>
                <option value="">-- Select Supplier --</option>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['supplierID'] ?>"><?= htmlspecialchars($e1Row['supplierName']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Product <span class="text-danger">*</span></label>
            <select name="productID" class="form-select" required>
                <option value="">-- Select Product --</option>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['productID'] ?>"><?= htmlspecialchars($e2Row['productName']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Date</label>
                <input type="date" name="movementDate" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Movement Type</label>
                <select name="movementType" class="form-select" required>
                    <option value="Stock In">Stock In</option>
<option value="Stock Out">Stock Out</option>
<option value="Adjustment">Adjustment</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Quantity</label>
                <input type="number"  name="quantity" class="form-control" value="1" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Total Value (₱)</label>
                <input type="number" step="0.01" name="totalValue" class="form-control" value="0" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Submit Stock Movement</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>