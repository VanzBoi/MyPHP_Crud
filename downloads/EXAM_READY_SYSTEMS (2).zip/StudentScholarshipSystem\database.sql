-- ScholarshipSystem database schema and sample data
CREATE DATABASE IF NOT EXISTS scholarship_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE scholarship_system;

CREATE TABLE IF NOT EXISTS students (
  studID INT AUTO_INCREMENT PRIMARY KEY,
  fName VARCHAR(100) NOT NULL,
  lName VARCHAR(100) NOT NULL,
  course VARCHAR(100) NOT NULL,
  yearLevel VARCHAR(50) NOT NULL,
  contactNo VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS scholarships (
  scholID INT AUTO_INCREMENT PRIMARY KEY,
  scholName VARCHAR(150) NOT NULL,
  discountRate DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  description TEXT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS applications (
  appID INT AUTO_INCREMENT PRIMARY KEY,
  studID INT NOT NULL,
  scholID INT NOT NULL,
  tuitionFee DECIMAL(10,2) NOT NULL,
  discountAmount DECIMAL(10,2) NOT NULL,
  amountPaid DECIMAL(10,2) NOT NULL,
  appDate DATE NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Pending',
  FOREIGN KEY (studID) REFERENCES students(studID) ON DELETE CASCADE,
  FOREIGN KEY (scholID) REFERENCES scholarships(scholID) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO students (fName, lName, course, yearLevel, contactNo) VALUES
('Maria', 'Santos', 'BSIT', '2nd Year', '09171234567'),
('John', 'Dela Cruz', 'BSCS', '3rd Year', '09181234567');

INSERT INTO scholarships (scholName, discountRate, description) VALUES
('Academic Excellence', 0.50, '50% discount for high-performing students'),
('Sports Scholarship', 0.25, '25% discount for varsity athletes');

INSERT INTO applications (studID, scholID, tuitionFee, discountAmount, amountPaid, appDate, status) VALUES
(1, 1, 20000.00, 10000.00, 10000.00, '2024-08-15', 'Approved'),
(2, 2, 18000.00, 4500.00, 13500.00, '2024-08-16', 'Pending');
