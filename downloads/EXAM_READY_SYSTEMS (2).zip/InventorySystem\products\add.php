<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName = is_string($_POST['productName'] ?? null) ? trim($_POST['productName']) : '';
$category = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
$unitCost = is_string($_POST['unitCost'] ?? null) ? trim($_POST['unitCost']) : '';
$reorderLevel = is_string($_POST['reorderLevel'] ?? null) ? trim($_POST['reorderLevel']) : '';

    $sql = "INSERT INTO products (`productName`, `category`, `unitCost`, `reorderLevel`) VALUES ('" . $conn->real_escape_string($productName) . "', '" . $conn->real_escape_string($category) . "', '" . $conn->real_escape_string($unitCost) . "', '" . $conn->real_escape_string($reorderLevel) . "')";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to add record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product - Warehouse Inventory &amp; Stock Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Add New Product</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Product Name</label>
                <input type="text" name="productName" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Category</label>
                <select name="category" class="form-select" required>
                    <option value="Industrial">Industrial</option>
<option value="Hardware">Hardware</option>
<option value="Safety Gear">Safety Gear</option>
<option value="Tools">Tools</option>
<option value="Electrical">Electrical</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Unit Cost (₱)</label>
                <input type="number" step="0.01" name="unitCost" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Reorder Level</label>
                <input type="number"  name="reorderLevel" class="form-control" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Product</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>