<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM movies WHERE movieID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$m = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = is_string($_POST['movieTitle'] ?? null) ? trim($_POST['movieTitle']) : '';
    $genre = is_string($_POST['genre'] ?? null) ? trim($_POST['genre']) : '';
    $hall = is_string($_POST['cinemaHall'] ?? null) ? trim($_POST['cinemaHall']) : '';
    $dur = intval($_POST['durationMinutes'] ?? 0);
    $price = floatval($_POST['ticketPrice'] ?? 0);

    $stmt = $conn->prepare("UPDATE movies SET movieTitle=?, genre=?, cinemaHall=?, durationMinutes=?, ticketPrice=? WHERE movieID=?");
    $stmt->bind_param("sssddi", $title, $genre, $hall, $dur, $price, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Movie</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Edit Movie</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Movie Title</label>
                    <input type="text" name="movieTitle" class="form-control" required value="<?php echo htmlspecialchars($m['movieTitle']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Genre</label>
                    <select name="genre" class="form-select" required>
                        <?php foreach(['Action / Adventure', 'Animation / Family', 'Horror / Thriller', 'Sci-Fi / Fantasy', 'Comedy / Romance'] as $g): ?>
                        <option value="<?php echo $g; ?>" <?php echo $m['genre'] === $g ? 'selected' : ''; ?>><?php echo $g; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Cinema Hall</label>
                    <input type="text" name="cinemaHall" class="form-control" required value="<?php echo htmlspecialchars($m['cinemaHall']); ?>">
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Duration (minutes)</label>
                        <input type="number" name="durationMinutes" class="form-control" required value="<?php echo $m['durationMinutes']; ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Ticket Price (₱)</label>
                        <input type="number" step="0.01" name="ticketPrice" class="form-control" required value="<?php echo $m['ticketPrice']; ?>">
                    </div>
                </div>
                <button type="submit" class="btn btn-warning w-100">Update Movie</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>