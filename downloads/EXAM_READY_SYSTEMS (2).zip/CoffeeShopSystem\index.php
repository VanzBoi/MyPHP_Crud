﻿<?php
require_once 'database.php';

$totalItems = $conn->query("SELECT COUNT(*) FROM menu_items")->fetch_row()[0];
$totalCustomers = $conn->query("SELECT COUNT(*) FROM customers")->fetch_row()[0];
$totalOrders = $conn->query("SELECT COUNT(*) FROM orders")->fetch_row()[0];
$totalSales = $conn->query("SELECT IFNULL(SUM(totalAmount), 0) FROM orders")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Coffee Shop Order System - Dashboard</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="p-4 mb-4 bg-white rounded-3 border">
            <h1 class="display-6 fw-bold">Artisan Cafe & Coffee Shop POS</h1>
            <p class="lead text-muted mb-0">Food & Beverage Ordering System</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Menu Offerings</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalItems; ?> Items</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Active Tables / Patrons</span>
                    <h3 class="mb-0 text-success"><?php echo $totalCustomers; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Completed Orders</span>
                    <h3 class="mb-0 text-warning"><?php echo $totalOrders; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Gross Sales Revenue</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalSales, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Menu Item Management</h5>
                    <p class="text-muted small">Add coffee beverages, pastries, iced drinks, and retail prices.</p>
                    <a href="<?php echo $baseUrl; ?>menu_items/index.php" class="btn btn-outline-primary mt-auto">Open Menu &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Table & Customer Directory</h5>
                    <p class="text-muted small">Assign orders to tables, dine-in patrons, or takeout customers.</p>
                    <a href="<?php echo $baseUrl; ?>customers/index.php" class="btn btn-outline-success mt-auto">Open Customers &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Category Sales Monitoring</h5>
                    <p class="text-muted small">Filter sales by food/drink category and view the sales summary and statistics.</p>
                    <a href="<?php echo $baseUrl; ?>monitoring/index.php" class="btn btn-outline-dark mt-auto">Open Monitoring &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>