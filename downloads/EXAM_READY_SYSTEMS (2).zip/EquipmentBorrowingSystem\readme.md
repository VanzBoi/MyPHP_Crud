﻿# Equipment Borrowing & Tracking System

A simple PHP and MySQL web application for managing equipment, borrowers, and borrow logs.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\EquipmentBorrowingSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/EquipmentBorrowingSystem/
4. The database `equipment_borrow_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Equipment**: Add, view, edit, and delete equipment records.
- **Borrowers**: Add, view, edit, and delete borrowers records.
- **Borrow Logs**: Manage borrow logs transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
