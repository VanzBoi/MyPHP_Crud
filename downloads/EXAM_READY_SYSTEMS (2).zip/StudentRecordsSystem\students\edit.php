<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM students WHERE studentID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentNumber = is_string($_POST['studentNumber'] ?? null) ? trim($_POST['studentNumber']) : '';
$fullName = is_string($_POST['fullName'] ?? null) ? trim($_POST['fullName']) : '';
$yearLevel = is_string($_POST['yearLevel'] ?? null) ? trim($_POST['yearLevel']) : '';
$contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    $sql = "UPDATE students SET `studentNumber` = '" . $conn->real_escape_string($studentNumber) . "', `fullName` = '" . $conn->real_escape_string($fullName) . "', `yearLevel` = '" . $conn->real_escape_string($yearLevel) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "' WHERE studentID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student #<?= $id ?> - Student Academic Records &amp; Grading System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Student #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Student Number</label>
                <input type="text" name="studentNumber" class="form-control" value="<?= htmlspecialchars($row['studentNumber'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Full Name</label>
                <input type="text" name="fullName" class="form-control" value="<?= htmlspecialchars($row['fullName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Year Level</label>
                <select name="yearLevel" class="form-select" required>
                    <option value="1st Year" <?= ($row['yearLevel'] ?? '') === '1st Year' ? 'selected' : '' ?>>1st Year</option>
<option value="2nd Year" <?= ($row['yearLevel'] ?? '') === '2nd Year' ? 'selected' : '' ?>>2nd Year</option>
<option value="3rd Year" <?= ($row['yearLevel'] ?? '') === '3rd Year' ? 'selected' : '' ?>>3rd Year</option>
<option value="4th Year" <?= ($row['yearLevel'] ?? '') === '4th Year' ? 'selected' : '' ?>>4th Year</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Contact Number</label>
                <input type="text" name="contactNumber" class="form-control" value="<?= htmlspecialchars($row['contactNumber'] ?? '') ?>" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>