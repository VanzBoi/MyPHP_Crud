-- Database schema for Student Enrollment System

CREATE DATABASE IF NOT EXISTS enrollmentdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE enrollmentdb;

CREATE TABLE IF NOT EXISTS students (
  studentID INT AUTO_INCREMENT PRIMARY KEY,
  fname VARCHAR(100) NOT NULL,
  lname VARCHAR(100) NOT NULL,
  course VARCHAR(100) NOT NULL,
  yearLevel INT NOT NULL,
  contactNo VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS subjects (
  subjectID INT AUTO_INCREMENT PRIMARY KEY,
  subjectCode VARCHAR(50) NOT NULL,
  subjectName VARCHAR(150) NOT NULL,
  units INT NOT NULL,
  feePerUnit DECIMAL(10,2) NOT NULL,
  totalFee DECIMAL(12,2) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS enrollment (
  enrollID INT AUTO_INCREMENT PRIMARY KEY,
  studentID INT NOT NULL,
  subjectID INT NOT NULL,
  enrollDate DATE NOT NULL,
  amountPaid DECIMAL(12,2) NOT NULL,
  balance DECIMAL(12,2) NOT NULL,
  paymentMode VARCHAR(50) NOT NULL,
  FOREIGN KEY (studentID) REFERENCES students(studentID) ON DELETE CASCADE,
  FOREIGN KEY (subjectID) REFERENCES subjects(subjectID) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO students (fname, lname, course, yearLevel, contactNo) VALUES
('Maria', 'Santos', 'BSIT', 2, '09171234567'),
('Juan', 'Dela Cruz', 'BSCS', 1, '09181234567');

INSERT INTO subjects (subjectCode, subjectName, units, feePerUnit, totalFee) VALUES
('IT101', 'Introduction to Programming', 3, 250.00, 750.00),
('CS102', 'Data Structures', 4, 300.00, 1200.00);

INSERT INTO enrollment (studentID, subjectID, enrollDate, amountPaid, balance, paymentMode) VALUES
(1, 1, CURDATE(), 500.00, 250.00, 'Cash');
