<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM athletes WHERE athleteID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$ath = $res->fetch_assoc();
$depts = $conn->query("SELECT * FROM departments ORDER BY deptCode ASC");
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sID = is_string($_POST['studentID'] ?? null) ? trim($_POST['studentID']) : '';
    $name = is_string($_POST['fullName'] ?? null) ? trim($_POST['fullName']) : '';
    $deptID = intval($_POST['deptID'] ?? 0);
    $year = is_string($_POST['yearLevel'] ?? null) ? trim($_POST['yearLevel']) : '';
    $gender = is_string($_POST['gender'] ?? null) ? trim($_POST['gender']) : '';
    $contact = is_string($_POST['contactNo'] ?? null) ? trim($_POST['contactNo']) : '';

    if ($sID === '' || $name === '' || $deptID <= 0) {
        $err = 'Please complete all required fields.';
    } else {
        $stmt = $conn->prepare("UPDATE athletes SET studentID = ?, fullName = ?, deptID = ?, yearLevel = ?, gender = ?, contactNo = ? WHERE athleteID = ?");
        $stmt->bind_param("ssisssi", $sID, $name, $deptID, $year, $gender, $contact, $id);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Update failed: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Athlete</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Edit Athlete Profile</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">University Student ID</label>
                    <input type="text" name="studentID" class="form-control" required value="<?php echo htmlspecialchars($ath['studentID']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="fullName" class="form-control" required value="<?php echo htmlspecialchars($ath['fullName']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">College Department</label>
                    <select name="deptID" class="form-select" required>
                        <?php while($d = $depts->fetch_assoc()): ?>
                            <option value="<?php echo $d['deptID']; ?>" <?php echo ($d['deptID'] == $ath['deptID']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($d['deptCode'] . ' - ' . $d['deptName']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Year Level</label>
                        <select name="yearLevel" class="form-select" required>
                            <option value="1st Year" <?php echo ($ath['yearLevel'] === '1st Year') ? 'selected' : ''; ?>>1st Year</option>
                            <option value="2nd Year" <?php echo ($ath['yearLevel'] === '2nd Year') ? 'selected' : ''; ?>>2nd Year</option>
                            <option value="3rd Year" <?php echo ($ath['yearLevel'] === '3rd Year') ? 'selected' : ''; ?>>3rd Year</option>
                            <option value="4th Year" <?php echo ($ath['yearLevel'] === '4th Year') ? 'selected' : ''; ?>>4th Year</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Gender</label>
                        <select name="gender" class="form-select" required>
                            <option value="Male" <?php echo ($ath['gender'] === 'Male') ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo ($ath['gender'] === 'Female') ? 'selected' : ''; ?>>Female</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="contactNo" class="form-control" value="<?php echo htmlspecialchars($ath['contactNo']); ?>" required>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Profile</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>