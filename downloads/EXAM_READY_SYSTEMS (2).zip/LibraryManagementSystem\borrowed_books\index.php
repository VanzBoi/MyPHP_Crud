<?php
require_once '../database.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
if ($search !== '') {
    $stmt = $conn->prepare("SELECT bb.*, b.title, b.author, br.fname, br.lname, br.course FROM borrowed_books bb JOIN books b ON bb.bookID = b.bookID JOIN borrowers br ON bb.borrowerID = br.borrowerID WHERE b.title LIKE ? OR br.fname LIKE ? OR br.lname LIKE ? OR br.course LIKE ? ORDER BY bb.borrowID DESC");
    $param = "%$search%";
    $stmt->bind_param("ssss", $param, $param, $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT bb.*, b.title, b.author, br.fname, br.lname, br.course FROM borrowed_books bb JOIN books b ON bb.bookID = b.bookID JOIN borrowers br ON bb.borrowerID = br.borrowerID ORDER BY bb.borrowID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Borrowed Books Records</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Borrowed Books Circulation</h3>
            <a href="add.php" class="btn btn-primary">+ Issue Book Loan</a>
        </div>
        <div class="card p-3 mb-3">
            <form method="GET" class="row g-2">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="Search by book title, borrower name, or course..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Search</button>
                    <?php if ($search !== ''): ?>
                        <a href="index.php" class="btn btn-outline-secondary">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <div class="card p-0">
            <table class="table table-bordered table-striped mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Book Title</th>
                        <th>Borrower</th>
                        <th>Course</th>
                        <th>Borrow Date</th>
                        <th>Due Date</th>
                        <th>Return Date</th>
                        <th>Fine (₱)</th>
                        <th>Loan Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['borrowID']; ?></td>
                            <td><strong><?php echo htmlspecialchars($row['title']); ?></strong></td>
                            <td><?php echo htmlspecialchars($row['fname'] . ' ' . $row['lname']); ?></td>
                            <td><span class="badge bg-secondary"><?php echo htmlspecialchars($row['course']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['borrowDate']); ?></td>
                            <td><?php echo htmlspecialchars($row['dueDate']); ?></td>
                            <td><?php echo $row['returnDate'] ? htmlspecialchars($row['returnDate']) : '<span class="text-muted">Not Returned</span>'; ?></td>
                            <td>₱<?php echo number_format($row['fine'], 2); ?></td>
                            <td>
                                <?php if ($row['loanStatus'] === 'Returned'): ?>
                                    <span class="badge bg-success">Returned</span>
                                <?php elseif ($row['loanStatus'] === 'Overdue'): ?>
                                    <span class="badge bg-danger">Overdue</span>
                                <?php else: ?>
                                    <span class="badge bg-primary">Borrowed</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <a href="edit.php?id=<?php echo $row['borrowID']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete.php?id=<?php echo $row['borrowID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete loan record?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="10" class="text-center py-4 text-muted">No borrowed books recorded.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>