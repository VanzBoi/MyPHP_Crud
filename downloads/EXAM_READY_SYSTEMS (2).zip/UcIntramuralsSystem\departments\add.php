<?php
require_once '../database.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = strtoupper(is_string($_POST['deptCode'] ?? null) ? (is_string($_POST['deptCode'] ?? null) ? trim($_POST['deptCode']) : '') : '');
    $name = is_string($_POST['deptName'] ?? null) ? trim($_POST['deptName']) : '';
    $dean = is_string($_POST['deanName'] ?? null) ? trim($_POST['deanName']) : '';

    if ($code === '' || $name === '') {
        $err = 'Please fill out all required fields.';
    } else {
        $stmt = $conn->prepare("INSERT INTO departments (deptCode, deptName, deanName) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $code, $name, $dean);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Department code already exists or database error: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Department</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Add New College Department</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Department Code</label>
                    <input type="text" name="deptCode" class="form-control" required placeholder="e.g. CCS, CBA, CEA">
                </div>
                <div class="mb-3">
                    <label class="form-label">Complete Department Name</label>
                    <input type="text" name="deptName" class="form-control" required placeholder="e.g. College of Computer Studies">
                </div>
                <div class="mb-3">
                    <label class="form-label">Dean / Department Head</label>
                    <input type="text" name="deanName" class="form-control" placeholder="e.g. Dean Jonathan O. Perez">
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Save Department</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>