<?php
require_once __DIR__ . '/database.php';

$countE1 = $conn->query("SELECT COUNT(*) AS total FROM `residents`")->fetch_assoc()['total'] ?? 0;
$countE2 = $conn->query("SELECT COUNT(*) AS total FROM `clearance_types`")->fetch_assoc()['total'] ?? 0;
$countTr = $conn->query("SELECT COUNT(*) AS total FROM `clearances`")->fetch_assoc()['total'] ?? 0;
$sumTotal = $conn->query("SELECT IFNULL(SUM(amountPaid), 0) AS total FROM `clearances`")->fetch_assoc()['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Clearance & Certification System - Dashboard</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/navbar.php'; ?>

    <div class="container my-4">
        <div class="p-4 mb-4 bg-light rounded-3 border">
            <h1 class="display-6 fw-bold mb-2">Barangay Clearance & Certification System</h1>
            <p class="lead text-muted mb-0">Universal College Capstone & Skills Test Management System</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3 shadow-sm border-0 bg-white">
                    <span class="text-muted small fw-semibold text-uppercase">Residents</span>
                    <h2 class="fw-bold text-primary mb-2"><?= $countE1 ?></h2>
                    <a href="<?= $baseUrl ?>residents/index.php" class="btn btn-outline-primary btn-sm">Manage Residents &rarr;</a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 shadow-sm border-0 bg-white">
                    <span class="text-muted small fw-semibold text-uppercase">Clearance Types</span>
                    <h2 class="fw-bold text-success mb-2"><?= $countE2 ?></h2>
                    <a href="<?= $baseUrl ?>clearance_types/index.php" class="btn btn-outline-success btn-sm">Manage Clearance Types &rarr;</a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 shadow-sm border-0 bg-white">
                    <span class="text-muted small fw-semibold text-uppercase">Clearance Issuances</span>
                    <h2 class="fw-bold text-info mb-2"><?= $countTr ?></h2>
                    <a href="<?= $baseUrl ?>clearances/index.php" class="btn btn-outline-info btn-sm">View Clearance Issuances &rarr;</a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 shadow-sm border-0 bg-white">
                    <span class="text-muted small fw-semibold text-uppercase">Total Clearance Fees Collected</span>
                    <h2 class="fw-bold text-warning mb-2">₱<?= number_format((float)$sumTotal, 2) ?></h2>
                    <a href="<?= $baseUrl ?>monitoring/index.php" class="btn btn-outline-warning btn-sm">View Analytics &rarr;</a>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm p-4 bg-white">
            <h4 class="fw-bold mb-3">Quick Actions</h4>
            <div class="d-flex flex-wrap gap-2">
                <a href="<?= $baseUrl ?>residents/add.php" class="btn btn-primary">+ Add New Resident</a>
                <a href="<?= $baseUrl ?>clearance_types/add.php" class="btn btn-success">+ Add New Clearance Type</a>
                <a href="<?= $baseUrl ?>clearances/add.php" class="btn btn-info text-white">+ Record New Clearance Issuance</a>
                <a href="<?= $baseUrl ?>monitoring/index.php" class="btn btn-secondary">Generate Monitoring Report</a>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>
