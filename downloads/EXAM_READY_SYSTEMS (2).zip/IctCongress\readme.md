﻿# ICT Congress Registration System

A simple PHP and MySQL web application for managing workshops, participants, and registrations.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\IctCongress\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/IctCongress/
4. The database `congress_system_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Workshops**: Add, view, edit, and delete workshops records.
- **Participants**: Add, view, edit, and delete participants records.
- **Registrations**: Manage registrations transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
