<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT serviceID, serviceName FROM services ORDER BY serviceName ASC");
$e2List = $conn->query("SELECT clientID, clientName FROM clients ORDER BY clientName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $serviceID = (int)($_POST['serviceID'] ?? 0);
    $clientID = (int)($_POST['clientID'] ?? 0);
    $appointmentDate = is_string($_POST['appointmentDate'] ?? null) ? trim($_POST['appointmentDate']) : '';
    $appointmentTime = is_string($_POST['appointmentTime'] ?? null) ? trim($_POST['appointmentTime']) : '';
    $totalFee = is_string($_POST['totalFee'] ?? null) ? trim($_POST['totalFee']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($serviceID <= 0 || $clientID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "INSERT INTO appointments (`serviceID`, `clientID`, `appointmentDate`, `appointmentTime`, `totalFee`, `status`) VALUES ('" . $conn->real_escape_string($serviceID) . "', '" . $conn->real_escape_string($clientID) . "', '" . $conn->real_escape_string($appointmentDate) . "', '" . $conn->real_escape_string($appointmentTime) . "', '" . $conn->real_escape_string($totalFee) . "', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Appointment - Professional Service Appointment System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Record New Appointment</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Service <span class="text-danger">*</span></label>
            <select name="serviceID" class="form-select" required>
                <option value="">-- Select Service --</option>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['serviceID'] ?>"><?= htmlspecialchars($e1Row['serviceName']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Client <span class="text-danger">*</span></label>
            <select name="clientID" class="form-select" required>
                <option value="">-- Select Client --</option>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['clientID'] ?>"><?= htmlspecialchars($e2Row['clientName']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Date</label>
                <input type="date" name="appointmentDate" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Time Slot</label>
                <input type="text" name="appointmentTime" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Total Fee (₱)</label>
                <input type="number" step="0.01" name="totalFee" class="form-control" value="0" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Status</label>
                <select name="status" class="form-select" required>
                    <option value="Pending">Pending</option>
<option value="Confirmed">Confirmed</option>
<option value="Completed">Completed</option>
<option value="Cancelled">Cancelled</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Submit Appointment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>