<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM roles WHERE roleID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $roleName = is_string($_POST['roleName'] ?? null) ? trim($_POST['roleName']) : '';
$department = is_string($_POST['department'] ?? null) ? trim($_POST['department']) : '';
$accessLevel = is_string($_POST['accessLevel'] ?? null) ? trim($_POST['accessLevel']) : '';
$stipendAllowance = is_string($_POST['stipendAllowance'] ?? null) ? trim($_POST['stipendAllowance']) : '';

    $sql = "UPDATE roles SET `roleName` = '" . $conn->real_escape_string($roleName) . "', `department` = '" . $conn->real_escape_string($department) . "', `accessLevel` = '" . $conn->real_escape_string($accessLevel) . "', `stipendAllowance` = '" . $conn->real_escape_string($stipendAllowance) . "' WHERE roleID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Role #<?= $id ?> - User Role &amp; Access Assignment System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Role #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Role Title</label>
                <input type="text" name="roleName" class="form-control" value="<?= htmlspecialchars($row['roleName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Department</label>
                <select name="department" class="form-select" required>
                    <option value="IT Services" <?= ($row['department'] ?? '') === 'IT Services' ? 'selected' : '' ?>>IT Services</option>
<option value="Academic Affairs" <?= ($row['department'] ?? '') === 'Academic Affairs' ? 'selected' : '' ?>>Academic Affairs</option>
<option value="College Faculty" <?= ($row['department'] ?? '') === 'College Faculty' ? 'selected' : '' ?>>College Faculty</option>
<option value="Student Affairs" <?= ($row['department'] ?? '') === 'Student Affairs' ? 'selected' : '' ?>>Student Affairs</option>
<option value="Finance" <?= ($row['department'] ?? '') === 'Finance' ? 'selected' : '' ?>>Finance</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Access Level</label>
                <select name="accessLevel" class="form-select" required>
                    <option value="Super Admin (Level 3)" <?= ($row['accessLevel'] ?? '') === 'Super Admin (Level 3)' ? 'selected' : '' ?>>Super Admin (Level 3)</option>
<option value="Manager (Level 2)" <?= ($row['accessLevel'] ?? '') === 'Manager (Level 2)' ? 'selected' : '' ?>>Manager (Level 2)</option>
<option value="Staff (Level 1)" <?= ($row['accessLevel'] ?? '') === 'Staff (Level 1)' ? 'selected' : '' ?>>Staff (Level 1)</option>
<option value="Viewer (Level 1)" <?= ($row['accessLevel'] ?? '') === 'Viewer (Level 1)' ? 'selected' : '' ?>>Viewer (Level 1)</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Standard Allowance (₱)</label>
                <input type="number" step="0.01" name="stipendAllowance" class="form-control" value="<?= htmlspecialchars($row['stipendAllowance'] ?? '') ?>" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>