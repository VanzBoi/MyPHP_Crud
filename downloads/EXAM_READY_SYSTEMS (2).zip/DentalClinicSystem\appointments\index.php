﻿<?php
require_once __DIR__ . '/../database.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$where = "1=1";
if ($search !== '') {
    $s = $conn->real_escape_string($search);
    $where .= " AND (e1.dentistName LIKE '%$s%' OR e2.patientName LIKE '%$s%')";
}

$sql = "SELECT t.*, e1.dentistName AS e1_title, e2.patientName AS e2_title 
        FROM appointments t
        JOIN dentists e1 ON t.dentistID = e1.dentistID
        JOIN patients e2 ON t.patientID = e2.patientID
        WHERE $where
        ORDER BY t.appointmentID DESC";
$res = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment List - Dental Clinic Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="fw-bold mb-0">Appointment Records</h3>
                <small class="text-muted">Transaction Management</small>
            </div>
            <a href="add.php" class="btn btn-warning fw-semibold btn-sm">+ New Appointment</a>
        </div>

        <div class="card mb-4">
            <div class="card-body p-3">
                <form method="GET" class="row g-2">
                    <div class="col-md-10">
                        <input type="text" name="search" class="form-control form-control-sm" placeholder="Search by Dentist or Patient..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-dark btn-sm w-100">Search</button>
                        <?php if ($search !== ''): ?>
                            <a href="index.php" class="btn btn-outline-secondary btn-sm">Reset</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="table table-striped table-bordered align-middle mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Dentist</th>
<th>Patient</th>
<th>Date</th>
<th>Time Slot</th>
<th>Service Rendered</th>
<th>Total Fee (₱)</th>
<th>Status</th>

                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($res && $res->num_rows > 0): ?>
                            <?php while ($r = $res->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['appointmentID'] ?></td>
                                    <td><?= htmlspecialchars($r['e1_title'] ?? '') ?></td>
<td><?= htmlspecialchars($r['e2_title'] ?? '') ?></td>
<td><?= htmlspecialchars($r['appointmentDate']) ?></td>
<td><?= htmlspecialchars($r['appointmentTime']) ?></td>
<td><?= htmlspecialchars($r['serviceRendered']) ?></td>
<td>₱<?= number_format($r['totalFee'], 2) ?></td>
<td><?= htmlspecialchars($r['status']) ?></td>

                                    <td class="text-end">
                                        <a href="edit.php?id=<?= $r['appointmentID'] ?>" class="btn btn-outline-primary btn-sm py-0 px-2">Edit</a>
                                        <a href="delete.php?id=<?= $r['appointmentID'] ?>" class="btn btn-outline-danger btn-sm py-0 px-2" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="12" class="text-center py-4 text-muted">No transactions recorded yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer class="text-center">
        <div class="container">
            <p class="mb-0">&copy; <?= date('Y') ?> Dental Clinic Management System</p>
        </div>
    </footer>
    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>