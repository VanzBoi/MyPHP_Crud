<?php
require_once '../database.php';
$msg = '';

$movies = $conn->query("SELECT * FROM movies ORDER BY movieTitle ASC");
$customers = $conn->query("SELECT * FROM customers ORDER BY custLName ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $movieID = (int)($_POST['movieID'] ?? 0);
    $custID = (int)($_POST['customerID'] ?? 0);
    $bDate = is_string($_POST['bookingDate'] ?? null) ? trim($_POST['bookingDate']) : '';
    $tickets = (int)($_POST['numTickets'] ?? 0);
    $mode = is_string($_POST['paymentMode'] ?? null) ? trim($_POST['paymentMode']) : '';

    // Fetch movie base ticket price
    $mRow = $conn->query("SELECT ticketPrice FROM movies WHERE movieID = $movieID")->fetch_assoc();
    $basePrice = $mRow ? floatval($mRow['ticketPrice']) : 0;

    // Fetch customer type for discount
    $cRow = $conn->query("SELECT customerType FROM customers WHERE customerID = $custID")->fetch_assoc();
    $custType = $cRow['customerType'] ?? 'Regular';

    $discountRate = ($custType === 'Student' || $custType === 'Senior') ? 0.20 : 0.00;
    $pricePerTicket = $basePrice * (1.0 - $discountRate);
    $totalAmount = $tickets * $pricePerTicket;

    if ($movieID > 0 && $custID > 0 && $tickets > 0) {
        $sql = "INSERT INTO bookings (movieID, customerID, bookingDate, numTickets, totalAmountPaid, paymentMode) VALUES ($movieID, $custID, '" . $conn->real_escape_string($bDate) . "', $tickets, $totalAmount, '" . $conn->real_escape_string($mode) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php?msg=booked");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Failed to record transaction: " . htmlspecialchars($conn->error) . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Movie Ticket</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 650px;">
        <div class="card p-4 mb-3">
            <h4>Book Movie Tickets</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Select Movie</label>
                    <select name="movieID" class="form-select" required>
                        <option value="">-- Choose Movie --</option>
                        <?php while($m = $movies->fetch_assoc()): ?>
                        <option value="<?php echo $m['movieID']; ?>">
                            <?php echo htmlspecialchars($m['movieTitle'] . ' (' . $m['cinemaHall'] . ') - ₱' . number_format($m['ticketPrice'], 2)); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Select Moviegoer</label>
                    <select name="customerID" class="form-select" required>
                        <option value="">-- Choose Moviegoer --</option>
                        <?php while($c = $customers->fetch_assoc()): ?>
                        <option value="<?php echo $c['customerID']; ?>">
                            <?php echo htmlspecialchars($c['custLName'] . ', ' . $c['custFName'] . ' [' . $c['customerType'] . ']'); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                    <small class="text-muted">Students and Seniors automatically receive 20% off.</small>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Booking Date</label>
                        <input type="date" name="bookingDate" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Number of Tickets</label>
                        <input type="number" name="numTickets" class="form-control" required min="1" value="1">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Payment Mode</label>
                    <select name="paymentMode" class="form-select">
                        <option value="Cash">Cash</option>
                        <option value="GCash">GCash</option>
                        <option value="Credit Card">Credit Card</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100">Confirm Ticket Purchase</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to Bookings</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>