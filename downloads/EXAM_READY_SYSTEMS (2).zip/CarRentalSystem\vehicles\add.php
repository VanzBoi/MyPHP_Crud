<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $plate = is_string($_POST['plateNumber'] ?? null) ? trim($_POST['plateNumber']) : '';
    $model = is_string($_POST['brandModel'] ?? null) ? trim($_POST['brandModel']) : '';
    $type = is_string($_POST['vehicleType'] ?? null) ? trim($_POST['vehicleType']) : '';
    $rate = floatval($_POST['dailyRate'] ?? 0);
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($plate && $model && $rate > 0) {
        $stmt = $conn->prepare("INSERT INTO vehicles (plateNumber, brandModel, vehicleType, dailyRate, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssds", $plate, $model, $type, $rate, $status);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
    } else {
        $msg = "<div class='alert alert-warning'>Please fill all required fields.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Vehicle</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Add New Vehicle</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Plate Number</label>
                    <input type="text" name="plateNumber" class="form-control" required placeholder="e.g. ABC-1234">
                </div>
                <div class="mb-3">
                    <label class="form-label">Brand & Model</label>
                    <input type="text" name="brandModel" class="form-control" required placeholder="e.g. Toyota Vios">
                </div>
                <div class="mb-3">
                    <label class="form-label">Vehicle Type</label>
                    <select name="vehicleType" class="form-select" required>
                        <option value="Sedan">Sedan</option>
                        <option value="SUV">SUV</option>
                        <option value="Van">Van</option>
                        <option value="Pickup">Pickup</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Daily Rental Rate (₱)</label>
                    <input type="number" step="0.01" name="dailyRate" class="form-control" required placeholder="1500.00">
                </div>
                <div class="mb-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="Available">Available</option>
                        <option value="Rented">Rented</option>
                        <option value="Maintenance">Maintenance</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100">Save Vehicle</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>