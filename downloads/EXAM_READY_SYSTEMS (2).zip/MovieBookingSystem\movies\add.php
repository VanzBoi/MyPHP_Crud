<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = is_string($_POST['movieTitle'] ?? null) ? trim($_POST['movieTitle']) : '';
    $genre = is_string($_POST['genre'] ?? null) ? trim($_POST['genre']) : '';
    $hall = is_string($_POST['cinemaHall'] ?? null) ? trim($_POST['cinemaHall']) : '';
    $dur = intval($_POST['durationMinutes'] ?? 0);
    $price = floatval($_POST['ticketPrice'] ?? 0);

    if ($title && $genre && $price > 0) {
        $stmt = $conn->prepare("INSERT INTO movies (movieTitle, genre, cinemaHall, durationMinutes, ticketPrice) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdd", $title, $genre, $hall, $dur, $price);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Movie</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Add New Movie</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Movie Title</label>
                    <input type="text" name="movieTitle" class="form-control" required placeholder="e.g. Avengers: Secret Wars">
                </div>
                <div class="mb-3">
                    <label class="form-label">Genre</label>
                    <select name="genre" class="form-select" required>
                        <option value="Action / Adventure">Action / Adventure</option>
                        <option value="Animation / Family">Animation / Family</option>
                        <option value="Horror / Thriller">Horror / Thriller</option>
                        <option value="Sci-Fi / Fantasy">Sci-Fi / Fantasy</option>
                        <option value="Comedy / Romance">Comedy / Romance</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Cinema Hall</label>
                    <input type="text" name="cinemaHall" class="form-control" required placeholder="e.g. Cinema 1 (IMAX)">
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Duration (minutes)</label>
                        <input type="number" name="durationMinutes" class="form-control" required value="120">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Ticket Price (₱)</label>
                        <input type="number" step="0.01" name="ticketPrice" class="form-control" required placeholder="350.00">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100">Save Movie</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>