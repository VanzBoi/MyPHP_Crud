﻿# Veterinary Clinic Management System

A simple PHP and MySQL web application for managing veterinarians, pets, and treatments.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\VeterinarySystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/VeterinarySystem/
4. The database `veterinary_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Veterinarians**: Add, view, edit, and delete veterinarians records.
- **Pets**: Add, view, edit, and delete pets records.
- **Treatments**: Manage treatments transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
