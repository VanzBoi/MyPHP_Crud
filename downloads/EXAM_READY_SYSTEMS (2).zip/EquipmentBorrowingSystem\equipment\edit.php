<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM equipment WHERE equipmentID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $equipmentName = is_string($_POST['equipmentName'] ?? null) ? trim($_POST['equipmentName']) : '';
$category = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
$serialNumber = is_string($_POST['serialNumber'] ?? null) ? trim($_POST['serialNumber']) : '';
$conditionStatus = is_string($_POST['conditionStatus'] ?? null) ? trim($_POST['conditionStatus']) : '';

    $sql = "UPDATE equipment SET `equipmentName` = '" . $conn->real_escape_string($equipmentName) . "', `category` = '" . $conn->real_escape_string($category) . "', `serialNumber` = '" . $conn->real_escape_string($serialNumber) . "', `conditionStatus` = '" . $conn->real_escape_string($conditionStatus) . "' WHERE equipmentID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Equipment #<?= $id ?> - Equipment Borrowing &amp; Tracking System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Equipment #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Equipment Name</label>
                <input type="text" name="equipmentName" class="form-control" value="<?= htmlspecialchars($row['equipmentName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Category</label>
                <select name="category" class="form-select" required>
                    <option value="Multimedia" <?= ($row['category'] ?? '') === 'Multimedia' ? 'selected' : '' ?>>Multimedia</option>
<option value="IT Hardware" <?= ($row['category'] ?? '') === 'IT Hardware' ? 'selected' : '' ?>>IT Hardware</option>
<option value="Audio Gear" <?= ($row['category'] ?? '') === 'Audio Gear' ? 'selected' : '' ?>>Audio Gear</option>
<option value="Laboratory" <?= ($row['category'] ?? '') === 'Laboratory' ? 'selected' : '' ?>>Laboratory</option>
<option value="Sports" <?= ($row['category'] ?? '') === 'Sports' ? 'selected' : '' ?>>Sports</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Serial Number</label>
                <input type="text" name="serialNumber" class="form-control" value="<?= htmlspecialchars($row['serialNumber'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Condition</label>
                <select name="conditionStatus" class="form-select" required>
                    <option value="Good" <?= ($row['conditionStatus'] ?? '') === 'Good' ? 'selected' : '' ?>>Good</option>
<option value="Fair" <?= ($row['conditionStatus'] ?? '') === 'Fair' ? 'selected' : '' ?>>Fair</option>
<option value="Needs Repair" <?= ($row['conditionStatus'] ?? '') === 'Needs Repair' ? 'selected' : '' ?>>Needs Repair</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>