<?php include '../database.php'; include '../helpers.php';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $f = is_string($_POST['fName'] ?? null) ? $conn->real_escape_string(trim($_POST['fName'])) : '';
  $l = is_string($_POST['lName'] ?? null) ? $conn->real_escape_string(trim($_POST['lName'])) : '';
  $a = is_string($_POST['address'] ?? null) ? $conn->real_escape_string(trim($_POST['address'])) : '';
  $c = is_string($_POST['contactNo'] ?? null) ? $conn->real_escape_string(trim($_POST['contactNo'])) : '';
  mysqli_query($conn, "INSERT INTO guests (fName,lName,address,contactNo) VALUES ('{$f}','{$l}','{$a}','{$c}')");
  set_flash('Guest added successfully.', 'success');
  header('Location: index.php'); exit;
}
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Guest</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
  </head>
  <body>
    <?php include '../navbar.php'; ?>
    <div class="container">
      <h4>Add Guest</h4>
      <form method="post">
        <div class="mb-2"><label>First name</label><input required name="fName" class="form-control"></div>
        <div class="mb-2"><label>Last name</label><input required name="lName" class="form-control"></div>
        <div class="mb-2"><label>Address</label><textarea name="address" class="form-control"></textarea></div>
        <div class="mb-2"><label>Contact</label><input name="contactNo" class="form-control"></div>
        <button class="btn btn-primary">Save</button>
        <a class="btn btn-secondary" href="index.php">Cancel</a>
      </form>
    </div>
      <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
  </body>
</html>
