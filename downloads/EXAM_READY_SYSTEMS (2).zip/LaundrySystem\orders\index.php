<?php
require_once '../database.php';

$query = "SELECT o.*, s.serviceName, s.serviceType, s.pricePerKilo, c.custFName, c.custLName, c.contactNumber 
          FROM laundry_orders o
          JOIN services s ON o.serviceID = s.serviceID
          JOIN customers c ON o.customerID = c.customerID
          ORDER BY o.orderID DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laundry Orders</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Laundry Orders & Processing</h3>
            <a href="add.php" class="btn btn-primary">+ New Laundry Order</a>
        </div>
        <div class="card mb-3">
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Service</th>
                        <th>Customer</th>
                        <th>Date</th>
                        <th>Weight</th>
                        <th>Total Fee</th>
                        <th>Status</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $row['orderID']; ?></td>
                            <td>
                                <strong> <?php echo htmlspecialchars($row['serviceName']); ?></strong>
                                <small class="text-muted d-block"><?php echo htmlspecialchars($row['serviceType']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($row['custFName'] . ' ' . $row['custLName']); ?></td>
                            <td><?php echo $row['orderDate']; ?></td>
                            <td><?php echo number_format($row['weightKilos'], 2); ?> kg</td>
                            <td><strong class="text-success">₱<?php echo number_format($row['totalAmount'], 2); ?></strong></td>
                            <td>
                                <span class="badge <?php 
                                    if ($row['orderStatus'] === 'Claimed') echo 'bg-success';
                                    elseif ($row['orderStatus'] === 'Ready') echo 'bg-info text-dark';
                                    elseif ($row['orderStatus'] === 'Processing') echo 'bg-warning text-dark';
                                    else echo 'bg-secondary';
                               ?>">
                                    <?php echo htmlspecialchars($row['orderStatus']); ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <a href="delete.php?id=<?php echo $row['orderID']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this order?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">No laundry orders recorded yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>