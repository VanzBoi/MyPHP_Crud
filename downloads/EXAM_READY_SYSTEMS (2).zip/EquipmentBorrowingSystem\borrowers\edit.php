<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM borrowers WHERE borrowerID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $borrowerName = is_string($_POST['borrowerName'] ?? null) ? trim($_POST['borrowerName']) : '';
$idNumber = is_string($_POST['idNumber'] ?? null) ? trim($_POST['idNumber']) : '';
$department = is_string($_POST['department'] ?? null) ? trim($_POST['department']) : '';
$contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    $sql = "UPDATE borrowers SET `borrowerName` = '" . $conn->real_escape_string($borrowerName) . "', `idNumber` = '" . $conn->real_escape_string($idNumber) . "', `department` = '" . $conn->real_escape_string($department) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "' WHERE borrowerID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Borrower #<?= $id ?> - Equipment Borrowing &amp; Tracking System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Borrower #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Borrower Name</label>
                <input type="text" name="borrowerName" class="form-control" value="<?= htmlspecialchars($row['borrowerName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">ID Number</label>
                <input type="text" name="idNumber" class="form-control" value="<?= htmlspecialchars($row['idNumber'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Department</label>
                <select name="department" class="form-select" required>
                    <option value="CCS" <?= ($row['department'] ?? '') === 'CCS' ? 'selected' : '' ?>>CCS</option>
<option value="COE" <?= ($row['department'] ?? '') === 'COE' ? 'selected' : '' ?>>COE</option>
<option value="CBA" <?= ($row['department'] ?? '') === 'CBA' ? 'selected' : '' ?>>CBA</option>
<option value="CAS" <?= ($row['department'] ?? '') === 'CAS' ? 'selected' : '' ?>>CAS</option>
<option value="Senior High" <?= ($row['department'] ?? '') === 'Senior High' ? 'selected' : '' ?>>Senior High</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Contact Number</label>
                <input type="text" name="contactNumber" class="form-control" value="<?= htmlspecialchars($row['contactNumber'] ?? '') ?>" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>