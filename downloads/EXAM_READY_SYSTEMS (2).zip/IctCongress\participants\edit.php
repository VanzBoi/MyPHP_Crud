<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM participants WHERE participantID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = is_string($_POST['fullName'] ?? null) ? trim($_POST['fullName']) : '';
$campus = is_string($_POST['campus'] ?? null) ? trim($_POST['campus']) : '';
$email = is_string($_POST['email'] ?? null) ? trim($_POST['email']) : '';
$contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    $sql = "UPDATE participants SET `fullName` = '" . $conn->real_escape_string($fullName) . "', `campus` = '" . $conn->real_escape_string($campus) . "', `email` = '" . $conn->real_escape_string($email) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "' WHERE participantID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Participant #<?= $id ?> - ICT Congress &amp; Workshop Registration System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Participant #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Participant Name</label>
                <input type="text" name="fullName" class="form-control" value="<?= htmlspecialchars($row['fullName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Campus</label>
                <select name="campus" class="form-select" required>
                    <option value="UC-Main" <?= ($row['campus'] ?? '') === 'UC-Main' ? 'selected' : '' ?>>UC-Main</option>
<option value="UC-Banilad" <?= ($row['campus'] ?? '') === 'UC-Banilad' ? 'selected' : '' ?>>UC-Banilad</option>
<option value="UC-LM" <?= ($row['campus'] ?? '') === 'UC-LM' ? 'selected' : '' ?>>UC-LM</option>
<option value="UC-PT" <?= ($row['campus'] ?? '') === 'UC-PT' ? 'selected' : '' ?>>UC-PT</option>
<option value="Other" <?= ($row['campus'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Email</label>
                <input type="text" name="email" class="form-control" value="<?= htmlspecialchars($row['email'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Contact Number</label>
                <input type="text" name="contactNumber" class="form-control" value="<?= htmlspecialchars($row['contactNumber'] ?? '') ?>" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>