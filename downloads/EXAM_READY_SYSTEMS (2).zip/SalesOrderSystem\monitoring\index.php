<?php
require_once __DIR__ . '/../database.php';

// Filter parameter
$filterVal = is_string($_GET['filter'] ?? null) ? trim($_GET['filter']) : '';

$where = "1=1";
if ($filterVal !== '') {
    $esc = $conn->real_escape_string($filterVal);
    $where .= " AND t.productID = '$esc'";
}

// Count total records
$totalCount = $conn->query("SELECT COUNT(*) AS total FROM orders t WHERE $where")->fetch_assoc()['total'] ?? 0;

// Get total sum
$totalAmount = $conn->query("SELECT IFNULL(SUM(totalAmount), 0) AS total FROM orders t WHERE $where")->fetch_assoc()['total'] ?? 0;

// Calculate average or percentage
$avgValue = ($totalCount > 0) ? ($totalAmount / $totalCount) : 0;

// Dropdown options
$filterOptions = $conn->query("SELECT productID, productName FROM products ORDER BY productName ASC");

// Query transactions
$sql = "SELECT t.*, e1.productName AS e1_title, e2.customerName AS e2_title 
        FROM orders t
        JOIN products e1 ON t.productID = e1.productID
        JOIN customers e2 ON t.customerID = e2.customerID
        WHERE $where
        ORDER BY t.orderID DESC";
$records = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitoring & Reports - Sales &amp; Order Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="fw-bold mb-0">System Monitoring & Analytical Summary</h3>
            </div>
            <a href="<?= $baseUrl ?>orders/add.php" class="btn btn-warning btn-sm fw-semibold">+ Record New Order</a>
        </div>

        <!-- Filter Card -->
        <div class="card mb-4">
            <div class="card-body p-3">
                <form method="GET" class="row g-2 align-items-center">
                    <div class="col-auto">
                        <label class="col-form-label fw-bold">Filter by Product:</label>
                    </div>
                    <div class="col-md-6">
                        <select name="filter" class="form-select form-select-sm" onchange="this.form.submit()">
                            <option value="">-- All Product (Show All) --</option>
                            <?php if ($filterOptions): ?>
                                <?php while ($opt = $filterOptions->fetch_assoc()): ?>
                                    <option value="<?= $opt['productID'] ?>" <?= ($filterVal == $opt['productID']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($opt['productName']) ?>
                                    </option>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-auto">
                        <?php if ($filterVal !== ''): ?>
                            <a href="index.php" class="btn btn-outline-secondary btn-sm">Reset Filter</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="card p-3 bg-white ">
                    <div class="text-muted small text-uppercase fw-bold">Total Transactions</div>
                    <div class="fs-2 fw-bold text-dark my-1"><?= number_format($totalCount) ?></div>
                    <small class="text-muted">Total records matching active filter</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 bg-white ">
                    <div class="text-muted small text-uppercase fw-bold">Total Amount (₱)</div>
                    <div class="fs-2 fw-bold text-success my-1">₱<?= number_format($totalAmount, 2) ?></div>
                    <small class="text-muted">Calculated sum of transaction amount</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 bg-white ">
                    <div class="text-muted small text-uppercase fw-bold">Average Order Value</div>
                    <div class="fs-2 fw-bold text-info my-1">₱<?= number_format($avgValue, 2) ?></div>
                    <small class="text-muted">Calculated average per transaction</small>
                </div>
            </div>
        </div>

        <!-- Detail Table -->
        <div class="card">
            <div class="card-header fw-bold bg-white py-3 d-flex justify-content-between align-items-center">
                <h6 class="mb-0 fw-bold">Filtered Transaction Breakdown</h6>
                <span class="badge bg-secondary"><?= $totalCount ?> items</span>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-bordered align-middle mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Product</th>
                            <th>Customer</th>
                            <th>Amount / Fee</th>
                            <th>Status / Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records && $records->num_rows > 0): ?>
                            <?php while ($r = $records->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['orderID'] ?></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($r['e1_title'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($r['e2_title'] ?? '') ?></td>
                                    <td class="text-success fw-bold">₱<?= number_format($r['totalAmount'] ?? 0, 2) ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark border">Active Record</span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">No records match the selected filter.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer class="text-center">
        <div class="container">
            <p class="mb-0">&copy; <?= date('Y') ?> Sales &amp; Order Management System</p>
        </div>
    </footer>
    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>