<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM bookings WHERE bookingID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$e1List = $conn->query("SELECT serviceID, serviceName FROM services ORDER BY serviceName ASC");
$e2List = $conn->query("SELECT petID, petName FROM pets ORDER BY petName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $serviceID = (int)($_POST['serviceID'] ?? 0);
    $petID = (int)($_POST['petID'] ?? 0);
    $bookingDate = is_string($_POST['bookingDate'] ?? null) ? trim($_POST['bookingDate']) : '';
    $totalPrice = is_string($_POST['totalPrice'] ?? null) ? trim($_POST['totalPrice']) : '';
    $paymentMethod = is_string($_POST['paymentMethod'] ?? null) ? trim($_POST['paymentMethod']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($serviceID <= 0 || $petID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "UPDATE bookings SET `serviceID` = '" . $conn->real_escape_string($serviceID) . "', `petID` = '" . $conn->real_escape_string($petID) . "', `bookingDate` = '" . $conn->real_escape_string($bookingDate) . "', `totalPrice` = '" . $conn->real_escape_string($totalPrice) . "', `paymentMethod` = '" . $conn->real_escape_string($paymentMethod) . "', `status` = '" . $conn->real_escape_string($status) . "' WHERE bookingID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Booking #<?= $id ?> - Pet Grooming Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Booking #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Service <span class="text-danger">*</span></label>
            <select name="serviceID" class="form-select" required>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['serviceID'] ?>" <?= ($row['serviceID'] == $e1Row['serviceID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e1Row['serviceName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Pet <span class="text-danger">*</span></label>
            <select name="petID" class="form-select" required>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['petID'] ?>" <?= ($row['petID'] == $e2Row['petID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e2Row['petName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Date</label>
                <input type="date" name="bookingDate" class="form-control" value="<?= htmlspecialchars($row['bookingDate'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Total Price (₱)</label>
                <input type="number" step="0.01" name="totalPrice" class="form-control" value="<?= htmlspecialchars($row['totalPrice'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Payment Mode</label>
                <select name="paymentMethod" class="form-select" required>
                    <option value="Cash" <?= ($row['paymentMethod'] ?? '') === 'Cash' ? 'selected' : '' ?>>Cash</option>
<option value="GCash" <?= ($row['paymentMethod'] ?? '') === 'GCash' ? 'selected' : '' ?>>GCash</option>
<option value="Card" <?= ($row['paymentMethod'] ?? '') === 'Card' ? 'selected' : '' ?>>Card</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Status</label>
                <select name="status" class="form-select" required>
                    <option value="Confirmed" <?= ($row['status'] ?? '') === 'Confirmed' ? 'selected' : '' ?>>Confirmed</option>
<option value="In Progress" <?= ($row['status'] ?? '') === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
<option value="Completed" <?= ($row['status'] ?? '') === 'Completed' ? 'selected' : '' ?>>Completed</option>
<option value="Cancelled" <?= ($row['status'] ?? '') === 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>