<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$query = 'SELECT m.*, mem.fName, mem.lName, p.packageName, p.fee, p.duration FROM memberships m JOIN members mem ON m.memberID = mem.memberID JOIN packages p ON m.packageID = p.packageID';
$params = [];
if ($search !== '') {
    $query .= ' WHERE mem.fName LIKE ? OR mem.lName LIKE ? OR p.packageName LIKE ?';
    $params = ["%{$search}%", "%{$search}%", "%{$search}%"];
}
$stmt = mysqli_prepare($conn, $query);
if ($params) {
    mysqli_stmt_bind_param($stmt, 'sss', ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Memberships - Gym Membership</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Memberships</h2>
            <a href="add.php" class="btn btn-success">Add Membership</a>
        </div>
        <?php if ($flash = flash()): ?>
            <div class="alert alert-<?php echo escape($flash['type']); ?>"><?php echo escape($flash['message']); ?></div>
        <?php endif; ?>
        <form class="row g-2 mb-3" method="get" action="index.php">
            <div class="col-md-10">
                <input type="search" name="search" class="form-control" placeholder="Search memberships by member or package" value="<?php echo escape($search); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Search</button>
            </div>
        </form>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Member</th>
                        <th>Package</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Amount Paid</th>
                        <th>Discount Amount</th>
                        <th>Net Amount</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($membership = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo escape($membership['membershipID']); ?></td>
                            <td><?php echo escape($membership['fName'] . ' ' . $membership['lName']); ?></td>
                            <td><?php echo escape($membership['packageName']); ?></td>
                            <td><?php echo escape($membership['startDate']); ?></td>
                            <td><?php echo escape($membership['endDate']); ?></td>
                            <td><?php echo escape($membership['amountPaid']); ?></td>
                            <td><?php echo escape($membership['discountAmount']); ?></td>
                            <td><?php echo escape($membership['netAmount']); ?></td>
                            <td><?php echo escape($membership['status']); ?></td>
                            <td>
                                <a href="edit.php?id=<?php echo escape($membership['membershipID']); ?>" class="btn btn-sm btn-primary">Edit</a>
                                <a href="delete.php?id=<?php echo escape($membership['membershipID']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this membership?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
