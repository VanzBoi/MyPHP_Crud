<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = is_string($_POST['vetFName'] ?? null) ? trim($_POST['vetFName']) : '';
    $lname = is_string($_POST['vetLName'] ?? null) ? trim($_POST['vetLName']) : '';
    $spec = is_string($_POST['specialization'] ?? null) ? trim($_POST['specialization']) : '';
    $contact = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    if ($fname && $lname && $spec) {
        $stmt = $conn->prepare("INSERT INTO veterinarians (vetFName, vetLName, specialization, contactNumber) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fname, $lname, $spec, $contact);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Veterinarian</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Add New Veterinarian</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">First Name</label>
                        <input type="text" name="vetFName" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="vetLName" class="form-control" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Specialization</label>
                    <select name="specialization" class="form-select" required>
                        <option value="General Veterinary Medicine">General Veterinary Medicine</option>
                        <option value="Surgery & Trauma">Surgery & Trauma</option>
                        <option value="Canine & Feline Medicine">Canine & Feline Medicine</option>
                        <option value="Dermatology & Allergy">Dermatology & Allergy</option>
                        <option value="Dentistry">Dentistry</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="contactNumber" class="form-control" required placeholder="0917-000-0000">
                </div>
                <button type="submit" class="btn btn-primary w-100">Save Doctor Record</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>