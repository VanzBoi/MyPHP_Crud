<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM positions WHERE positionID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$pos = $res->fetch_assoc();
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = is_string($_POST['positionName'] ?? null) ? trim($_POST['positionName']) : '';
    $basic = floatval($_POST['basicSalary'] ?? 0);
    $allowance = floatval($_POST['allowance'] ?? 0);

    if ($name === '' || $basic <= 0) {
        $err = 'Please fill out all required fields.';
    } else {
        $stmt = $conn->prepare("UPDATE positions SET positionName = ?, basicSalary = ?, allowance = ? WHERE positionID = ?");
        $stmt->bind_param("sddi", $name, $basic, $allowance, $id);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Update failed: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Position</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Edit Position</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Position Title</label>
                    <input type="text" name="positionName" class="form-control" required value="<?php echo htmlspecialchars($pos['positionName']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Monthly Basic Salary (₱)</label>
                    <input type="number" step="0.01" name="basicSalary" class="form-control" required value="<?php echo $pos['basicSalary']; ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Standard Allowance (₱)</label>
                    <input type="number" step="0.01" name="allowance" class="form-control" value="<?php echo $pos['allowance']; ?>">
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Position</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>