<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$filter = is_string($_GET['package'] ?? null) ? trim($_GET['package']) : '';
$query = 'SELECT m.*, mem.fName, mem.lName, p.packageName, p.duration FROM memberships m JOIN members mem ON m.memberID = mem.memberID JOIN packages p ON m.packageID = p.packageID';
$params = [];
if ($filter !== '') {
    $query .= ' WHERE p.packageName = ?';
    $params[] = $filter;
}
$stmt = mysqli_prepare($conn, $query);
if ($params) {
    mysqli_stmt_bind_param($stmt, 's', ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$packages = mysqli_query($conn, 'SELECT DISTINCT packageName FROM packages ORDER BY packageName');

$totals = [
    'count' => 0,
    'active' => 0,
    'amountPaid' => 0.00,
    'discountAmount' => 0.00,
    'netAmount' => 0.00,
];
$memberships = [];
while ($row = mysqli_fetch_assoc($result)) {
    $memberships[] = $row;
    $totals['count']++;
    if (strtolower($row['status']) === 'active') {
        $totals['active']++;
    }
    $totals['amountPaid'] += floatval($row['amountPaid']);
    $totals['discountAmount'] += floatval($row['discountAmount']);
    $totals['netAmount'] += floatval($row['netAmount']);
}
$totals['averageNet'] = $totals['count'] ? round($totals['netAmount'] / $totals['count'], 2) : 0.00;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Monitoring - Gym Membership</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>
    <div class="container">
        <div class="py-3">
            <h2>Monitoring / Inquiry</h2>
            <form class="row g-3 mb-3" method="get" action="index.php">
                <div class="col-md-8">
                    <select name="package" class="form-select">
                        <option value="">All Packages</option>
                        <?php while ($pkg = mysqli_fetch_assoc($packages)): ?>
                            <option value="<?php echo escape($pkg['packageName']); ?>" <?php echo ($filter === $pkg['packageName']) ? 'selected' : ''; ?>><?php echo escape($pkg['packageName']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-4"><button type="submit" class="btn btn-primary w-100">Filter</button></div>
            </form>
            <div class="row g-3 mb-4">
                <div class="col-md-4"><div class="card text-bg-light p-3"><strong>Total Applications</strong><div><?php echo escape($totals['count']); ?></div></div></div>
                <div class="col-md-4"><div class="card text-bg-light p-3"><strong>Active Applications</strong><div><?php echo escape($totals['active']); ?></div></div></div>
                <div class="col-md-4"><div class="card text-bg-light p-3"><strong>Average Net Amount</strong><div><?php echo escape(number_format($totals['averageNet'], 2)); ?></div></div></div>
                <div class="col-md-4"><div class="card text-bg-light p-3"><strong>Total Amount Paid</strong><div><?php echo escape(number_format($totals['amountPaid'], 2)); ?></div></div></div>
                <div class="col-md-4"><div class="card text-bg-light p-3"><strong>Total Discounts Given</strong><div><?php echo escape(number_format($totals['discountAmount'], 2)); ?></div></div></div>
                <div class="col-md-4"><div class="card text-bg-light p-3"><strong>Total Net Amount</strong><div><?php echo escape(number_format($totals['netAmount'], 2)); ?></div></div></div>
            </div>
            <div class="card mb-3">
                <div class="card-header fw-bold">Monitoring & Membership Inquiry</div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Member</th>
                                <th>Package</th>
                                <th>Duration</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Amount Paid</th>
                                <th>Discount Amount</th>
                                <th>Net Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($memberships)): ?>
                                <tr><td colspan="9" class="text-center">No memberships found.</td></tr>
                            <?php else: ?>
                                <?php foreach ($memberships as $membership): ?>
                                    <tr>
                                        <td><?php echo escape($membership['fName'] . ' ' . $membership['lName']); ?></td>
                                        <td><?php echo escape($membership['packageName']); ?></td>
                                        <td><?php echo escape($membership['duration']); ?></td>
                                        <td><?php echo escape($membership['startDate']); ?></td>
                                        <td><?php echo escape($membership['endDate']); ?></td>
                                        <td><?php echo escape($membership['amountPaid']); ?></td>
                                        <td><?php echo escape($membership['discountAmount']); ?></td>
                                        <td><?php echo escape($membership['netAmount']); ?></td>
                                        <td><?php echo escape($membership['status']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
