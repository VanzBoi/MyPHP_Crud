﻿# Event Registration Management System

A simple PHP and MySQL web application for managing events, participants, and registrations.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\EventRegistrationSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/EventRegistrationSystem/
4. The database `event_registration` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Events**: Add, view, edit, and delete events records.
- **Participants**: Add, view, edit, and delete participants records.
- **Registrations**: Manage registrations transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
