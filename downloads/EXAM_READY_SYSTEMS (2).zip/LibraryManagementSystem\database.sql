CREATE DATABASE IF NOT EXISTS `librarydb` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `librarydb`;

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `books` (
  `bookID` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `author` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `copies` INT NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `borrowers` (
  `borrowerID` INT AUTO_INCREMENT PRIMARY KEY,
  `fname` VARCHAR(100) NOT NULL,
  `lname` VARCHAR(100) NOT NULL,
  `course` VARCHAR(100) NOT NULL,
  `contactNo` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `borrowed_books` (
  `borrowID` INT AUTO_INCREMENT PRIMARY KEY,
  `borrowerID` INT NOT NULL,
  `bookID` INT NOT NULL,
  `borrowDate` DATE NOT NULL,
  `dueDate` DATE NOT NULL,
  `returnDate` DATE DEFAULT NULL,
  `fine` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `loanStatus` VARCHAR(50) DEFAULT 'Borrowed',
  FOREIGN KEY (`borrowerID`) REFERENCES `borrowers`(`borrowerID`) ON DELETE CASCADE,
  FOREIGN KEY (`bookID`) REFERENCES `books`(`bookID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `books` (`bookID`, `title`, `author`, `category`, `price`, `copies`) VALUES
(1, 'Introduction to Algorithms and Data Structures', 'Thomas H. Cormen', 'Computer Science', 850.00, 5),
(2, 'Clean Code: Handbook of Agile Software Craftsmanship', 'Robert C. Martin', 'Software Engineering', 750.00, 3),
(3, 'Database System Concepts (7th Edition)', 'Abraham Silberschatz', 'Information Technology', 900.00, 4),
(4, 'Modern Operating Systems', 'Andrew S. Tanenbaum', 'Computer Engineering', 800.00, 2);

INSERT INTO `borrowers` (`borrowerID`, `fname`, `lname`, `course`, `contactNo`) VALUES
(1, 'John Cedrick', 'Libradilla', 'BS Information Technology', '0917-111-2222'),
(2, 'Maria Angela', 'Reyes', 'BS Computer Science', '0918-333-4444'),
(3, 'Carlos', 'Santos', 'BS Computer Engineering', '0922-555-6666'),
(4, 'Beatrice', 'Tan', 'BS Information Systems', '0919-777-8888');

INSERT INTO `borrowed_books` (`borrowerID`, `bookID`, `borrowDate`, `dueDate`, `returnDate`, `fine`, `loanStatus`) VALUES
(1, 1, '2026-10-20', '2026-10-27', NULL, 0.00, 'Borrowed'),
(2, 2, '2026-10-15', '2026-10-22', '2026-10-24', 40.00, 'Returned'),
(3, 3, '2026-10-18', '2026-10-25', NULL, 20.00, 'Overdue'),
(4, 4, '2026-10-22', '2026-10-29', NULL, 0.00, 'Borrowed');

SET FOREIGN_KEY_CHECKS=1;