<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `clearance_types` WHERE `typeID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $typeName = is_string($_POST['typeName'] ?? null) ? trim($_POST['typeName']) : '';
    $fee = is_string($_POST['fee'] ?? null) ? trim($_POST['fee']) : '';
    $requirements = is_string($_POST['requirements'] ?? null) ? trim($_POST['requirements']) : '';
    $validityMonths = is_string($_POST['validityMonths'] ?? null) ? trim($_POST['validityMonths']) : '';

    if ($typeName === '' || $fee === '') {
        $error = "Please fill in all required fields.";
    } else {
        $sql = "UPDATE `clearance_types` SET `typeName` = '" . $conn->real_escape_string($typeName) . "', `fee` = '" . $conn->real_escape_string($fee) . "', `requirements` = '" . $conn->real_escape_string($requirements) . "', `validityMonths` = '" . $conn->real_escape_string($validityMonths) . "' WHERE `typeID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Clearance Type - Barangay Clearance & Certification System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Clearance Type</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4 border-0 shadow-sm bg-white">
            <form method="POST">
                
            <div class="mb-3">
                <label class="form-label fw-semibold">Clearance Name</label>
                <input type="text" name="typeName" class="form-control"  required value="<?= htmlspecialchars($record['typeName'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Standard Fee</label>
                <input type="number" name="fee" class="form-control" step="0.01" required value="<?= htmlspecialchars($record['fee'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Requirements</label>
                <input type="text" name="requirements" class="form-control"  required value="<?= htmlspecialchars($record['requirements'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Validity (Months)</label>
                <input type="number" name="validityMonths" class="form-control" step="0.01" required value="<?= htmlspecialchars($record['validityMonths'] ?? '') ?>">
            </div>

                <div class="d-flex gap-2 pt-2">
                    <button type="submit" class="btn btn-primary">Update Clearance Type</button>
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>
