<?php
require_once '../database.php';
require_once '../helpers.php';

$scholName = '';
$discountRate = '';
$description = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $scholName = is_string($_POST['scholName'] ?? null) ? trim($_POST['scholName']) : '';
    $discountRate = is_string($_POST['discountRate'] ?? null) ? trim($_POST['discountRate']) : '';
    $description = is_string($_POST['description'] ?? null) ? trim($_POST['description']) : '';

    if ($scholName === '' || $discountRate === '') {
        set_flash('Scholarship name and discount rate are required.', 'error');
    } elseif (!is_numeric($discountRate) || $discountRate < 0 || $discountRate > 100) {
        set_flash('Discount rate must be a number between 0 and 100.', 'error');
    } else {
        $rate = $discountRate / 100;
        $stmt = $mysqli->prepare('INSERT INTO scholarships (scholName, discountRate, description) VALUES (?, ?, ?)');
        $stmt->bind_param('sds', $scholName, $rate, $description);
        $stmt->execute();
        $stmt->close();
        set_flash('Scholarship added successfully.');
        redirect('index.php');
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Scholarship</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<div class="container mt-4">
    <?php include '../navbar.php'; ?>
    <div class="mb-3">
        <h2>Add Scholarship</h2>
    </div>
    <?php flash(); ?>
    <form method="post">
        <div class="mb-3">
            <label class="form-label">Scholarship Name</label>
            <input type="text" name="scholName" class="form-control" value="<?= escape($scholName) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Discount Rate (%)</label>
            <input type="text" name="discountRate" class="form-control" value="<?= escape($discountRate) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="3"><?= escape($description) ?></textarea>
        </div>
        <button class="btn btn-success" type="submit">Save</button>
        <a href="index.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
