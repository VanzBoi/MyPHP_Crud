<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT roleID, roleName FROM roles ORDER BY roleName ASC");
$e2List = $conn->query("SELECT userID, fullName FROM users ORDER BY fullName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $roleID = (int)($_POST['roleID'] ?? 0);
    $userID = (int)($_POST['userID'] ?? 0);
    $assignedDate = is_string($_POST['assignedDate'] ?? null) ? trim($_POST['assignedDate']) : '';
    $allowance = is_string($_POST['allowance'] ?? null) ? trim($_POST['allowance']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($roleID <= 0 || $userID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "INSERT INTO assignments (`roleID`, `userID`, `assignedDate`, `allowance`, `status`) VALUES ('" . $conn->real_escape_string($roleID) . "', '" . $conn->real_escape_string($userID) . "', '" . $conn->real_escape_string($assignedDate) . "', '" . $conn->real_escape_string($allowance) . "', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Assignment - User Role &amp; Access Assignment System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Record New Assignment</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Role <span class="text-danger">*</span></label>
            <select name="roleID" class="form-select" required>
                <option value="">-- Select Role --</option>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['roleID'] ?>"><?= htmlspecialchars($e1Row['roleName']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">User <span class="text-danger">*</span></label>
            <select name="userID" class="form-select" required>
                <option value="">-- Select User --</option>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['userID'] ?>"><?= htmlspecialchars($e2Row['fullName']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Assigned Date</label>
                <input type="date" name="assignedDate" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Stipend / Allowance (₱)</label>
                <input type="number" step="0.01" name="allowance" class="form-control" value="0" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Status</label>
                <select name="status" class="form-select" required>
                    <option value="Active">Active</option>
<option value="Suspended">Suspended</option>
<option value="Revoked">Revoked</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Submit Assignment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>