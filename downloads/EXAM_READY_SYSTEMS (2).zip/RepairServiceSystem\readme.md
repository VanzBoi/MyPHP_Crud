﻿# Repair Service Management System

A simple PHP and MySQL web application for managing technicians, appliances, and repairs.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\RepairServiceSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/RepairServiceSystem/
4. The database `repair_service_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Technicians**: Add, view, edit, and delete technicians records.
- **Appliances**: Add, view, edit, and delete appliances records.
- **Repairs**: Manage repairs transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
