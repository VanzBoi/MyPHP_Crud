﻿<?php
require_once '../database.php';

$posFilter = intval($_GET['positionID'] ?? 0);
$where = ($posFilter > 0) ? "WHERE pos.positionID = $posFilter" : "";

$positions = $conn->query("SELECT * FROM positions ORDER BY positionName ASC");

// Summary statistics
$totalEmployees = $conn->query("SELECT COUNT(*) FROM employees e JOIN positions pos ON e.positionID = pos.positionID $where")->fetch_row()[0];
$totalBasic = $conn->query("SELECT IFNULL(SUM(p.basicSalary), 0) FROM payroll p JOIN employees e ON p.empID = e.empID JOIN positions pos ON e.positionID = pos.positionID $where")->fetch_row()[0];
$totalDeductions = $conn->query("SELECT IFNULL(SUM(p.deduction), 0) FROM payroll p JOIN employees e ON p.empID = e.empID JOIN positions pos ON e.positionID = pos.positionID $where")->fetch_row()[0];
$totalNet = $conn->query("SELECT IFNULL(SUM(p.netPay), 0) FROM payroll p JOIN employees e ON p.empID = e.empID JOIN positions pos ON e.positionID = pos.positionID $where")->fetch_row()[0];

// Report breakdown
$query = "SELECT pos.positionName, COUNT(p.payrollID) AS totalSlips, IFNULL(SUM(p.basicSalary), 0) AS sumBasic, IFNULL(SUM(p.allowance), 0) AS sumAllowance, IFNULL(SUM(p.deduction), 0) AS sumDeduction, IFNULL(SUM(p.netPay), 0) AS sumNet FROM positions pos LEFT JOIN employees e ON pos.positionID = e.positionID LEFT JOIN payroll p ON e.empID = p.empID " . (($posFilter > 0) ? "WHERE pos.positionID = $posFilter" : "") . " GROUP BY pos.positionID ORDER BY sumNet DESC";
$report = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payroll Monitoring & Analytics</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <h3 class="mb-3">Payroll Operations & Analytics Report</h3>
        
        <div class="card p-3 mb-4">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-md-9">
                    <select name="positionID" class="form-select">
                        <option value="0">-- All Job Positions (Systemwide) --</option>
                        <?php while($p = $positions->fetch_assoc()): ?>
                            <option value="<?php echo $p['positionID']; ?>" <?php echo ($p['positionID'] == $posFilter) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($p['positionName']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Filter Report</button>
                    <?php if ($posFilter > 0): ?>
                        <a href="index.php" class="btn btn-outline-secondary">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Covered Personnel</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalEmployees; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Total Basic Payroll</span>
                    <h3 class="mb-0 text-dark">₱<?php echo number_format($totalBasic, 2); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Total Deductions</span>
                    <h3 class="mb-0 text-danger">-₱<?php echo number_format($totalDeductions, 2); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Net Payout Disbursed</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalNet, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="card p-0">
            <div class="card-header fw-bold">Departmental Position Summary</div>
            <table class="table table-bordered table-striped mb-0">
                <thead>
                    <tr>
                        <th>Job Position</th>
                        <th>Processed Slips</th>
                        <th>Total Basic (₱)</th>
                        <th>Total Allowances (₱)</th>
                        <th>Total Deductions (₱)</th>
                        <th>Total Net Pay (₱)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($report && $report->num_rows > 0): ?>
                        <?php while($r = $report->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($r['positionName']); ?></strong></td>
                            <td><?php echo $r['totalSlips']; ?></td>
                            <td>₱<?php echo number_format($r['sumBasic'], 2); ?></td>
                            <td>₱<?php echo number_format($r['sumAllowance'], 2); ?></td>
                            <td class="text-danger">-₱<?php echo number_format($r['sumDeduction'], 2); ?></td>
                            <td class="text-success fw-bold">₱<?php echo number_format($r['sumNet'], 2); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center py-4 text-muted">No data available.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>