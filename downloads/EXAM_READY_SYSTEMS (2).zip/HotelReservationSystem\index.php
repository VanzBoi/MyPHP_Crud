<?php include 'database.php'; ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
  </head>
  <body>
    <?php include 'navbar.php'; ?>
    <div class="container">
      <div class="page-heading mb-4">
        <h1>Hotel Reservation System</h1>
        <p class="text-muted">Manage hotel guests, room inventory, reservations, and analytics.</p>
      </div>

      <div class="card mb-3">
        <div class="card-header fw-bold">System Navigation</div>
        <div class="card-body">
          <div class="list-group">
            <a href="guests/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Guests</span> <span class="text-muted">&rarr;</span></a>
            <a href="rooms/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Rooms</span> <span class="text-muted">&rarr;</span></a>
            <a href="reservations/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Reservations</span> <span class="text-muted">&rarr;</span></a>
            <a href="monitoring/index.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"><span>Monitoring & Reports</span> <span class="badge bg-primary">Monitoring</span></a>
          </div>
        </div>
      </div>
    </div>

    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
  </body>
</html>
