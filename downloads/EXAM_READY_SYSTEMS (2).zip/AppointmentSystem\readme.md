﻿# Professional Appointment System

A simple PHP and MySQL web application for managing services, clients, and appointments.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\AppointmentSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/AppointmentSystem/
4. The database `appointment_system_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Services**: Add, view, edit, and delete services records.
- **Clients**: Add, view, edit, and delete clients records.
- **Appointments**: Manage appointments transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
