<?php
require_once '../database.php';
require_once '../helpers.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$sql = 'SELECT a.*, s.fName, s.lName, s.course, sch.scholName, sch.discountRate FROM applications a
        JOIN students s ON a.studID = s.studID
        JOIN scholarships sch ON a.scholID = sch.scholID';
$params = [];
if ($search !== '') {
    $sql .= ' WHERE CONCAT(s.fName, " ", s.lName) LIKE ? OR sch.scholName LIKE ? OR a.status LIKE ?';
    $term = '%' . $search . '%';
    $params = [$term, $term, $term];
}
$sql .= ' ORDER BY a.appDate DESC';
$stmt = $mysqli->prepare($sql);
if ($params) {
    $stmt->bind_param('sss', $params[0], $params[1], $params[2]);
}
$stmt->execute();
$result = $stmt->get_result();
$applications = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Applications</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<div class="container mt-4">
    <?php include '../navbar.php'; ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Applications</h2>
        <a href="add.php" class="btn btn-warning">Add Application</a>
    </div>
    <?php flash(); ?>
    <form class="row g-2 mb-3" method="get" action="index.php">
        <div class="col-md-10">
            <input type="text" name="search" class="form-control" placeholder="Search by student, scholarship, or status..." value="<?= escape($search) ?>">
        </div>
        <div class="col-md-2">
            <button class="btn btn-secondary w-100" type="submit">Search</button>
        </div>
    </form>
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Student</th>
                    <th>Course</th>
                    <th>Scholarship</th>
                    <th>Tuition Fee</th>
                    <th>Discount</th>
                    <th>Amount Paid</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($applications as $index => $app): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= escape($app['fName'] . ' ' . $app['lName']) ?></td>
                        <td><?= escape($app['course']) ?></td>
                        <td><?= escape($app['scholName']) ?></td>
                        <td><?= number_format($app['tuitionFee'], 2) ?></td>
                        <td><?= number_format($app['discountAmount'], 2) ?></td>
                        <td><?= number_format($app['amountPaid'], 2) ?></td>
                        <td><?= escape($app['appDate']) ?></td>
                        <td><?= escape($app['status']) ?></td>
                        <td>
                            <a href="edit.php?id=<?= escape($app['appID']) ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="delete.php?id=<?= escape($app['appID']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this application?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($applications)): ?>
                    <tr><td colspan="10" class="text-center">No applications found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
