<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo $baseUrl; ?>index.php">Veterinary Clinic System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'veterinarians') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>veterinarians/index.php">Veterinarians</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'pets') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>pets/index.php">Pets & Patients</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'treatments') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>treatments/index.php">Treatments</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>