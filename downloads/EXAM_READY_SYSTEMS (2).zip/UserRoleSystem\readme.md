﻿# User Role & Access Assignment System

A simple PHP and MySQL web application for managing roles, users, and assignments.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\UserRoleSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/UserRoleSystem/
4. The database `user_roles_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Roles**: Add, view, edit, and delete roles records.
- **Users**: Add, view, edit, and delete users records.
- **Assignments**: Manage assignments transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
