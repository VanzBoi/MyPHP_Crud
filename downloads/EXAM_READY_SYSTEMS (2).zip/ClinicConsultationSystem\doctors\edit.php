<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    redirect('index.php');
}

$stmt = $mysqli->prepare("SELECT * FROM doctors WHERE docID = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
if (!$row) redirect('index.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = is_string($_POST['docFName'] ?? null) ? trim($_POST['docFName']) : '';
    $l = is_string($_POST['docLName'] ?? null) ? trim($_POST['docLName']) : '';
    $addr = is_string($_POST['docAddress'] ?? null) ? trim($_POST['docAddress']) : '';
    $spec = is_string($_POST['docSpecial'] ?? null) ? trim($_POST['docSpecial']) : '';
    $up = $mysqli->prepare("UPDATE doctors SET docFName=?, docLName=?, docAddress=?, docSpecial=? WHERE docID=?");
    $up->bind_param('ssssi', $f, $l, $addr, $spec, $id);
    $up->execute();
    flash('success','Doctor updated.');
    redirect('index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Doctor - Clinic Consultation</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
  <h2>Edit Doctor</h2>
  <form method="post">
    <div class="mb-2">
      <label>First Name</label>
      <input class="form-control" name="docFName" value="<?php echo e($row['docFName']); ?>" required>
    </div>
    <div class="mb-2">
      <label>Last Name</label>
      <input class="form-control" name="docLName" value="<?php echo e($row['docLName']); ?>" required>
    </div>
    <div class="mb-2">
      <label>Address</label>
      <input class="form-control" name="docAddress" value="<?php echo e($row['docAddress']); ?>">
    </div>
    <div class="mb-2">
      <label>Specialization</label>
      <input class="form-control" name="docSpecial" value="<?php echo e($row['docSpecial']); ?>">
    </div>
    <button class="btn btn-primary">Update</button>
  </form>
</div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
