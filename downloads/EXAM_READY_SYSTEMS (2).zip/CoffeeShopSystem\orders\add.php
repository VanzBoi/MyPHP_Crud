<?php
require_once '../database.php';
$msg = '';

$items = $conn->query("SELECT * FROM menu_items WHERE status = 'Available' ORDER BY itemName ASC");
$customers = $conn->query("SELECT * FROM customers ORDER BY customerName ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemID = (int)($_POST['itemID'] ?? 0);
    $custID = (int)($_POST['customerID'] ?? 0);
    $oDate = is_string($_POST['orderDate'] ?? null) ? trim($_POST['orderDate']) : '';
    $qty = (int)($_POST['quantity'] ?? 0);
    $mode = is_string($_POST['paymentMode'] ?? null) ? trim($_POST['paymentMode']) : '';

    // Fetch unit price
    $iRow = $conn->query("SELECT unitPrice FROM menu_items WHERE itemID = $itemID")->fetch_assoc();
    $price = $iRow ? floatval($iRow['unitPrice']) : 0;
    $totalAmount = $qty * $price;

    if ($itemID > 0 && $custID > 0 && $qty > 0) {
        $sql = "INSERT INTO orders (itemID, customerID, orderDate, quantity, totalAmount, paymentMode) VALUES ($itemID, $custID, '" . $conn->real_escape_string($oDate) . "', $qty, $totalAmount, '" . $conn->real_escape_string($mode) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php?msg=ordered");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Failed to record transaction: " . htmlspecialchars($conn->error) . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Place Order</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 650px;">
        <div class="card p-4 mb-3">
            <h4>Place New Cafe Order</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Select Menu Item</label>
                    <select name="itemID" class="form-select" required>
                        <option value="">-- Choose Item --</option>
                        <?php while($item = $items->fetch_assoc()): ?>
                        <option value="<?php echo $item['itemID']; ?>">
                            <?php echo htmlspecialchars($item['itemName'] . ' (' . $item['itemCategory'] . ') - ₱' . number_format($item['unitPrice'], 2)); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Select Customer / Table</label>
                    <select name="customerID" class="form-select" required>
                        <option value="">-- Choose Customer / Table --</option>
                        <?php while($c = $customers->fetch_assoc()): ?>
                        <option value="<?php echo $c['customerID']; ?>">
                            <?php echo htmlspecialchars($c['customerName'] . ' [' . $c['tableNumber'] . ']'); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Order Date</label>
                        <input type="date" name="orderDate" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Quantity</label>
                        <input type="number" name="quantity" class="form-control" required min="1" value="1">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Payment Mode</label>
                    <select name="paymentMode" class="form-select">
                        <option value="Cash">Cash</option>
                        <option value="GCash">GCash</option>
                        <option value="Credit Card">Credit Card</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100">Charge Order</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to Orders</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>