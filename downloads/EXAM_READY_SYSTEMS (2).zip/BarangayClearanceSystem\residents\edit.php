<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `residents` WHERE `residentID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = is_string($_POST['fullName'] ?? null) ? trim($_POST['fullName']) : '';
    $birthDate = is_string($_POST['birthDate'] ?? null) ? trim($_POST['birthDate']) : '';
    $civilStatus = is_string($_POST['civilStatus'] ?? null) ? trim($_POST['civilStatus']) : '';
    $address = is_string($_POST['address'] ?? null) ? trim($_POST['address']) : '';
    $contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    if ($fullName === '' || $birthDate === '') {
        $error = "Please fill in all required fields.";
    } else {
        $sql = "UPDATE `residents` SET `fullName` = '" . $conn->real_escape_string($fullName) . "', `birthDate` = '" . $conn->real_escape_string($birthDate) . "', `civilStatus` = '" . $conn->real_escape_string($civilStatus) . "', `address` = '" . $conn->real_escape_string($address) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "' WHERE `residentID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Resident - Barangay Clearance & Certification System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Resident</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4 border-0 shadow-sm bg-white">
            <form method="POST">
                
            <div class="mb-3">
                <label class="form-label fw-semibold">Full Name</label>
                <input type="text" name="fullName" class="form-control"  required value="<?= htmlspecialchars($record['fullName'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Birth Date</label>
                <input type="date" name="birthDate" class="form-control"  required value="<?= htmlspecialchars($record['birthDate'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Civil Status</label>
                <input type="text" name="civilStatus" class="form-control"  required value="<?= htmlspecialchars($record['civilStatus'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Purok / Address</label>
                <input type="text" name="address" class="form-control"  required value="<?= htmlspecialchars($record['address'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Contact Number</label>
                <input type="text" name="contactNumber" class="form-control"  required value="<?= htmlspecialchars($record['contactNumber'] ?? '') ?>">
            </div>

                <div class="d-flex gap-2 pt-2">
                    <button type="submit" class="btn btn-primary">Update Resident</button>
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>
