<?php
require_once '../database.php';

$catFilter = is_string($_GET['category'] ?? null) ? trim($_GET['category']) : '';
$where = ($catFilter !== '') ? "WHERE b.category = '" . $conn->real_escape_string($catFilter) . "'" : "";

$categories = $conn->query("SELECT DISTINCT category FROM books ORDER BY category ASC");

$totalBooks = $conn->query("SELECT COUNT(*) FROM books b $where")->fetch_row()[0];
$totalLoans = $conn->query("SELECT COUNT(*) FROM borrowed_books bb JOIN books b ON bb.bookID = b.bookID $where")->fetch_row()[0];
$totalActive = $conn->query("SELECT COUNT(*) FROM borrowed_books bb JOIN books b ON bb.bookID = b.bookID " . (($catFilter !== '') ? "$where AND bb.loanStatus = 'Borrowed'" : "WHERE bb.loanStatus = 'Borrowed'"))->fetch_row()[0];
$totalFines = $conn->query("SELECT IFNULL(SUM(bb.fine), 0) FROM borrowed_books bb JOIN books b ON bb.bookID = b.bookID $where")->fetch_row()[0];

$query = "SELECT b.category, COUNT(DISTINCT b.bookID) AS totalTitles, COUNT(bb.borrowID) AS totalCirculations, IFNULL(SUM(bb.fine), 0) AS sumFines FROM books b LEFT JOIN borrowed_books bb ON b.bookID = bb.bookID " . (($catFilter !== '') ? "WHERE b.category = '" . $conn->real_escape_string($catFilter) . "'" : "") . " GROUP BY b.category ORDER BY totalCirculations DESC";
$report = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Library Circulation Monitoring</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <h3 class="mb-3">Library Circulation & Overdue Monitoring</h3>

        <div class="card p-3 mb-4">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-md-9">
                    <select name="category" class="form-select">
                        <option value="">-- All Book Categories (Entire Catalog) --</option>
                        <?php while($c = $categories->fetch_assoc()): ?>
                            <option value="<?php echo htmlspecialchars($c['category']); ?>" <?php echo ($c['category'] === $catFilter) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($c['category']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-secondary w-100">Filter Category</button>
                    <?php if ($catFilter !== ''): ?>
                        <a href="index.php" class="btn btn-outline-secondary">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Catalog Titles</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalBooks; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">All-Time Loans</span>
                    <h3 class="mb-0 text-dark"><?php echo $totalLoans; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Active Borrowed Books</span>
                    <h3 class="mb-0 text-warning"><?php echo $totalActive; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <span class="text-muted small">Total Overdue Fines</span>
                    <h3 class="mb-0 text-danger">₱<?php echo number_format($totalFines, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="card p-0">
            <div class="card-header fw-bold">Circulation Summary by Category</div>
            <table class="table table-bordered table-striped mb-0">
                <thead>
                    <tr>
                        <th>Book Category</th>
                        <th>Catalog Titles</th>
                        <th>Circulation Count</th>
                        <th>Collected Fines (₱)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($report && $report->num_rows > 0): ?>
                        <?php while($r = $report->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($r['category']); ?></strong></td>
                            <td><?php echo $r['totalTitles']; ?></td>
                            <td><?php echo $r['totalCirculations']; ?></td>
                            <td class="text-danger">₱<?php echo number_format($r['sumFines'], 2); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="4" class="text-center py-4 text-muted">No circulation data found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>