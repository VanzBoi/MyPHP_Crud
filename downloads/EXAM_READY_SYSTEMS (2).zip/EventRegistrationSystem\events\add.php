<?php
require_once '../database.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = is_string($_POST['evName'] ?? null) ? trim($_POST['evName']) : '';
    $date = is_string($_POST['evDate'] ?? null) ? trim($_POST['evDate']) : '';
    $venue = is_string($_POST['evVenue'] ?? null) ? trim($_POST['evVenue']) : '';
    $fee = floatval($_POST['evRFee'] ?? 0);

    if ($name === '' || $date === '' || $venue === '') {
        $err = 'Please complete all required fields.';
    } else {
        $stmt = $conn->prepare("INSERT INTO events (evName, evDate, evVenue, evRFee) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssd", $name, $date, $venue, $fee);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Error creating event: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Event</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Create New Campus Event</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Event Title</label>
                    <input type="text" name="evName" class="form-control" required placeholder="e.g. CCS Tech Summit 2026">
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Event Date</label>
                        <input type="date" name="evDate" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Registration Fee (₱)</label>
                        <input type="number" step="0.01" name="evRFee" class="form-control" value="0.00" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Event Venue</label>
                    <input type="text" name="evVenue" class="form-control" required placeholder="e.g. UC-Main Auditorium">
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Save Event</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>