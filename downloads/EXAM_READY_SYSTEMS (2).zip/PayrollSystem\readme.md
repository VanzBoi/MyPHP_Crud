﻿# Payroll Management System

A simple PHP and MySQL web application for managing positions, employees, and payroll.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\PayrollSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/PayrollSystem/
4. The database `payroll_system` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Positions**: Add, view, edit, and delete positions records.
- **Employees**: Add, view, edit, and delete employees records.
- **Payroll**: Manage payroll transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
