CREATE DATABASE IF NOT EXISTS pharmacy_system_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pharmacy_system_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS medicines (
  medicineID INT AUTO_INCREMENT PRIMARY KEY,
  medicineName VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL,
  unitPrice DECIMAL(10,2) NOT NULL,
  stockQty INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
  customerID INT AUTO_INCREMENT PRIMARY KEY,
  customerName VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL,
  customerType VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS purchases (
  purchaseID INT AUTO_INCREMENT PRIMARY KEY,
  medicineID INT NOT NULL,
  customerID INT NOT NULL,
  purchaseDate DATE NOT NULL,
  quantity INT NOT NULL,
  totalAmount DECIMAL(10,2) NOT NULL,
  paymentMode VARCHAR(50) NOT NULL,
  FOREIGN KEY (medicineID) REFERENCES medicines(medicineID) ON DELETE CASCADE,
  FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO medicines (medicineName, category, unitPrice, stockQty) VALUES
('Amoxicillin 500mg', 'Antibiotic', 15.50, 250),
('Paracetamol 500mg', 'Analgesic', 5.00, 500),
('Vitamin C + Zinc', 'Vitamins', 12.00, 300),
('Losartan 50mg', 'Maintenance', 18.00, 200);

INSERT INTO customers (customerName, contactNumber, customerType) VALUES
('Ramon Bautista', '09178889900', 'Senior Citizen'),
('Lucia Mendoza', '09187778899', 'PWD'),
('Dante Morales', '09226667788', 'Regular');

INSERT INTO purchases (medicineID, customerID, purchaseDate, quantity, totalAmount, paymentMode) VALUES
(1, 1, '2026-10-25', 20, 310.00, 'Cash'),
(2, 2, '2026-10-26', 30, 150.00, 'Cash'),
(3, 3, '2026-10-27', 50, 600.00, 'GCash');

SET FOREIGN_KEY_CHECKS=1;