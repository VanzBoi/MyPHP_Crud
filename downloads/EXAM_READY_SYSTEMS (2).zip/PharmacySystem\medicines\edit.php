<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM medicines WHERE medicineID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medicineName = is_string($_POST['medicineName'] ?? null) ? trim($_POST['medicineName']) : '';
$category = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
$unitPrice = is_string($_POST['unitPrice'] ?? null) ? trim($_POST['unitPrice']) : '';
$stockQty = is_string($_POST['stockQty'] ?? null) ? trim($_POST['stockQty']) : '';

    $sql = "UPDATE medicines SET `medicineName` = '" . $conn->real_escape_string($medicineName) . "', `category` = '" . $conn->real_escape_string($category) . "', `unitPrice` = '" . $conn->real_escape_string($unitPrice) . "', `stockQty` = '" . $conn->real_escape_string($stockQty) . "' WHERE medicineID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Medicine #<?= $id ?> - Pharmacy Inventory and Sales System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Medicine #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Medicine Name</label>
                <input type="text" name="medicineName" class="form-control" value="<?= htmlspecialchars($row['medicineName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Category</label>
                <select name="category" class="form-select" required>
                    <option value="Antibiotic" <?= ($row['category'] ?? '') === 'Antibiotic' ? 'selected' : '' ?>>Antibiotic</option>
<option value="Analgesic" <?= ($row['category'] ?? '') === 'Analgesic' ? 'selected' : '' ?>>Analgesic</option>
<option value="Vitamins" <?= ($row['category'] ?? '') === 'Vitamins' ? 'selected' : '' ?>>Vitamins</option>
<option value="Maintenance" <?= ($row['category'] ?? '') === 'Maintenance' ? 'selected' : '' ?>>Maintenance</option>
<option value="Syrup" <?= ($row['category'] ?? '') === 'Syrup' ? 'selected' : '' ?>>Syrup</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Unit Price (₱)</label>
                <input type="number" step="0.01" name="unitPrice" class="form-control" value="<?= htmlspecialchars($row['unitPrice'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Stock Quantity</label>
                <input type="number"  name="stockQty" class="form-control" value="<?= htmlspecialchars($row['stockQty'] ?? '') ?>" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>