<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = is_string($_POST['fullName'] ?? null) ? trim($_POST['fullName']) : '';
    $birthDate = is_string($_POST['birthDate'] ?? null) ? trim($_POST['birthDate']) : '';
    $civilStatus = is_string($_POST['civilStatus'] ?? null) ? trim($_POST['civilStatus']) : '';
    $address = is_string($_POST['address'] ?? null) ? trim($_POST['address']) : '';
    $contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    if ($fullName === '' || $birthDate === '') {
        $error = "Please fill in all required fields.";
    } else {
        $sql = "INSERT INTO `residents` (`fullName`, `birthDate`, `civilStatus`, `address`, `contactNumber`) VALUES ('" . $conn->real_escape_string($fullName) . "', '" . $conn->real_escape_string($birthDate) . "', '" . $conn->real_escape_string($civilStatus) . "', '" . $conn->real_escape_string($address) . "', '" . $conn->real_escape_string($contactNumber) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to save record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Resident - Barangay Clearance & Certification System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Add New Resident</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4 border-0 shadow-sm bg-white">
            <form method="POST">
                
            <div class="mb-3">
                <label class="form-label fw-semibold">Full Name</label>
                <input type="text" name="fullName" class="form-control"  required value="<?= htmlspecialchars($fullName ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Birth Date</label>
                <input type="date" name="birthDate" class="form-control"  required value="<?= htmlspecialchars($birthDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Civil Status</label>
                <input type="text" name="civilStatus" class="form-control"  required value="<?= htmlspecialchars($civilStatus ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Purok / Address</label>
                <input type="text" name="address" class="form-control"  required value="<?= htmlspecialchars($address ?? '') ?>">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Contact Number</label>
                <input type="text" name="contactNumber" class="form-control"  required value="<?= htmlspecialchars($contactNumber ?? '') ?>">
            </div>

                <div class="d-flex gap-2 pt-2">
                    <button type="submit" class="btn btn-primary">Save Resident</button>
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>
