CREATE DATABASE IF NOT EXISTS `event_registration` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `event_registration`;

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `events` (
  `evCode` INT AUTO_INCREMENT PRIMARY KEY,
  `evName` VARCHAR(255) NOT NULL,
  `evDate` DATE NOT NULL,
  `evVenue` VARCHAR(255) NOT NULL,
  `evRFee` DECIMAL(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `participants` (
  `partID` INT AUTO_INCREMENT PRIMARY KEY,
  `partFName` VARCHAR(100) NOT NULL,
  `partLName` VARCHAR(100) NOT NULL,
  `contactNo` VARCHAR(50) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `organization` VARCHAR(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `registrations` (
  `regID` INT AUTO_INCREMENT PRIMARY KEY,
  `evCode` INT NOT NULL,
  `partID` INT NOT NULL,
  `regDate` DATE NOT NULL,
  `discountRate` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  `feePaid` DECIMAL(10,2) NOT NULL,
  `paymentMode` VARCHAR(50) NOT NULL,
  `status` VARCHAR(50) DEFAULT 'Confirmed',
  FOREIGN KEY (`evCode`) REFERENCES `events`(`evCode`) ON DELETE CASCADE,
  FOREIGN KEY (`partID`) REFERENCES `participants`(`partID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `events` (`evCode`, `evName`, `evDate`, `evVenue`, `evRFee`) VALUES
(1, 'CCS Tech Congress 2026', '2026-11-15', 'UC-Main Auditorium', 250.00),
(2, 'Full-Stack Web Development Bootcamp', '2026-11-20', 'CCS Computer Lab 3', 350.00),
(3, 'Cybersecurity & Ethical Hacking Summit', '2026-12-05', 'AVR 1, UC-Main', 300.00),
(4, 'AI and Machine Learning Seminar', '2026-12-12', 'Innovation Hall', 200.00);

INSERT INTO `participants` (`partID`, `partFName`, `partLName`, `contactNo`, `email`, `organization`) VALUES
(1, 'Alice', 'Garcia', '0917-111-2222', 'alice.garcia@gmail.com', 'UC Computer Society'),
(2, 'Bob', 'Santos', '0918-333-4444', 'bob.santos@yahoo.com', 'Junior Philippine Computer Society'),
(3, 'Carol', 'Reyes', '0922-555-6666', 'carol.reyes@uc.edu.ph', 'University Student Council'),
(4, 'David', 'Lim', '0919-777-8888', 'david.lim@outlook.com', 'Independent Tech Enthusiast');

INSERT INTO `registrations` (`evCode`, `partID`, `regDate`, `discountRate`, `feePaid`, `paymentMode`, `status`) VALUES
(1, 1, '2026-10-24', 10.00, 225.00, 'GCash', 'Confirmed'),
(2, 2, '2026-10-25', 0.00, 350.00, 'Cash', 'Confirmed'),
(3, 3, '2026-10-25', 20.00, 240.00, 'Bank Transfer', 'Confirmed'),
(1, 4, '2026-10-26', 0.00, 250.00, 'Cash', 'Pending');

SET FOREIGN_KEY_CHECKS=1;