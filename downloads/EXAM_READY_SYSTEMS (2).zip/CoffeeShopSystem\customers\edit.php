<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM customers WHERE customerID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$c = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = is_string($_POST['customerName'] ?? null) ? trim($_POST['customerName']) : '';
    $table = is_string($_POST['tableNumber'] ?? null) ? trim($_POST['tableNumber']) : '';
    $contact = is_string($_POST['customerContact'] ?? null) ? trim($_POST['customerContact']) : '';

    $stmt = $conn->prepare("UPDATE customers SET customerName=?, tableNumber=?, customerContact=? WHERE customerID=?");
    $stmt->bind_param("sssi", $name, $table, $contact, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Customer</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Edit Customer / Table</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Customer Name</label>
                    <input type="text" name="customerName" class="form-control" required value="<?php echo htmlspecialchars($c['customerName']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Table Number / Dining Mode</label>
                    <input type="text" name="tableNumber" class="form-control" required value="<?php echo htmlspecialchars($c['tableNumber']); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="customerContact" class="form-control" value="<?php echo htmlspecialchars($c['customerContact']); ?>">
                </div>
                <button type="submit" class="btn btn-warning w-100">Update Record</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>