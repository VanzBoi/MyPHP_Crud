<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo $baseUrl; ?>index.php">Event Registration System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'events') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>events/index.php">Events</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'participants') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>participants/index.php">Participants</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'registrations') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>registrations/index.php">Registrations</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>