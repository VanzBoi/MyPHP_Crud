<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName = is_string($_POST['productName'] ?? null) ? trim($_POST['productName']) : '';
$category = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
$unitPrice = is_string($_POST['unitPrice'] ?? null) ? trim($_POST['unitPrice']) : '';
$stockQty = is_string($_POST['stockQty'] ?? null) ? trim($_POST['stockQty']) : '';

    $sql = "INSERT INTO products (`productName`, `category`, `unitPrice`, `stockQty`) VALUES ('" . $conn->real_escape_string($productName) . "', '" . $conn->real_escape_string($category) . "', '" . $conn->real_escape_string($unitPrice) . "', '" . $conn->real_escape_string($stockQty) . "')";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to add record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product - Sales &amp; Order Management System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Add New Product</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Product Name</label>
                <input type="text" name="productName" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Category</label>
                <select name="category" class="form-select" required>
                    <option value="Electronics">Electronics</option>
<option value="Furniture">Furniture</option>
<option value="Lifestyle">Lifestyle</option>
<option value="Hardware">Hardware</option>
<option value="Accessories">Accessories</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Unit Price (₱)</label>
                <input type="number" step="0.01" name="unitPrice" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Stock Quantity</label>
                <input type="number"  name="stockQty" class="form-control" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Product</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>