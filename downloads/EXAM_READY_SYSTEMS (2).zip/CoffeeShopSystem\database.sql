CREATE DATABASE IF NOT EXISTS coffeeshop_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE coffeeshop_db;

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS menu_items (
  itemID INT AUTO_INCREMENT PRIMARY KEY,
  itemName VARCHAR(150) NOT NULL,
  itemCategory VARCHAR(50) NOT NULL,
  unitPrice DECIMAL(10,2) NOT NULL,
  status VARCHAR(20) DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
  customerID INT AUTO_INCREMENT PRIMARY KEY,
  customerName VARCHAR(100) NOT NULL,
  tableNumber VARCHAR(50) NOT NULL,
  customerContact VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  orderID INT AUTO_INCREMENT PRIMARY KEY,
  itemID INT NOT NULL,
  customerID INT NOT NULL,
  orderDate DATE NOT NULL,
  quantity INT NOT NULL,
  totalAmount DECIMAL(10,2) NOT NULL,
  paymentMode VARCHAR(50) NOT NULL,
  FOREIGN KEY (itemID) REFERENCES menu_items(itemID) ON DELETE CASCADE,
  FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO menu_items (itemName, itemCategory, unitPrice, status) VALUES
('Caramel Macchiato', 'Hot Coffee', 145.00, 'Available'),
('Spanish Latte (Iced)', 'Iced Drinks', 160.00, 'Available'),
('Matcha Green Tea Fusion', 'Iced Drinks', 170.00, 'Available'),
('Butter Croissant', 'Pastries', 95.00, 'Available'),
('Blueberry Cheesecake Slice', 'Pastries', 180.00, 'Available');

INSERT INTO customers (customerName, tableNumber, customerContact) VALUES
('Mark Anthony Reyes', 'Table 4', '0917-333-2211'),
('Sarah Mae Mendoza', 'Takeout', '0918-555-4433'),
('Janice Dizon', 'Table 12', '0922-888-7766');

INSERT INTO orders (itemID, customerID, orderDate, quantity, totalAmount, paymentMode) VALUES
(1, 1, '2026-10-25', 2, 290.00, 'Cash'),
(2, 2, '2026-10-25', 1, 160.00, 'GCash'),
(4, 1, '2026-10-26', 2, 190.00, 'Cash'),
(5, 3, '2026-10-26', 1, 180.00, 'Card');

SET FOREIGN_KEY_CHECKS=1;