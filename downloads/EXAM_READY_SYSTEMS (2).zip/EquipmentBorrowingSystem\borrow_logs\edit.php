<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM borrow_logs WHERE logID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$e1List = $conn->query("SELECT equipmentID, equipmentName FROM equipment ORDER BY equipmentName ASC");
$e2List = $conn->query("SELECT borrowerID, borrowerName FROM borrowers ORDER BY borrowerName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $equipmentID = (int)($_POST['equipmentID'] ?? 0);
    $borrowerID = (int)($_POST['borrowerID'] ?? 0);
    $borrowDate = is_string($_POST['borrowDate'] ?? null) ? trim($_POST['borrowDate']) : '';
    $returnDueDate = is_string($_POST['returnDueDate'] ?? null) ? trim($_POST['returnDueDate']) : '';
    $penaltyFee = is_string($_POST['penaltyFee'] ?? null) ? trim($_POST['penaltyFee']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($equipmentID <= 0 || $borrowerID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "UPDATE borrow_logs SET `equipmentID` = '" . $conn->real_escape_string($equipmentID) . "', `borrowerID` = '" . $conn->real_escape_string($borrowerID) . "', `borrowDate` = '" . $conn->real_escape_string($borrowDate) . "', `returnDueDate` = '" . $conn->real_escape_string($returnDueDate) . "', `penaltyFee` = '" . $conn->real_escape_string($penaltyFee) . "', `status` = '" . $conn->real_escape_string($status) . "' WHERE logID = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Borrow Log #<?= $id ?> - Equipment Borrowing &amp; Tracking System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Borrow Log #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Equipment <span class="text-danger">*</span></label>
            <select name="equipmentID" class="form-select" required>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['equipmentID'] ?>" <?= ($row['equipmentID'] == $e1Row['equipmentID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e1Row['equipmentName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Borrower <span class="text-danger">*</span></label>
            <select name="borrowerID" class="form-select" required>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['borrowerID'] ?>" <?= ($row['borrowerID'] == $e2Row['borrowerID']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($e2Row['borrowerName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Borrow Date</label>
                <input type="date" name="borrowDate" class="form-control" value="<?= htmlspecialchars($row['borrowDate'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Due Date</label>
                <input type="date" name="returnDueDate" class="form-control" value="<?= htmlspecialchars($row['returnDueDate'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Penalty Fee (₱)</label>
                <input type="number" step="0.01" name="penaltyFee" class="form-control" value="<?= htmlspecialchars($row['penaltyFee'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Status</label>
                <select name="status" class="form-select" required>
                    <option value="Borrowed" <?= ($row['status'] ?? '') === 'Borrowed' ? 'selected' : '' ?>>Borrowed</option>
<option value="Returned" <?= ($row['status'] ?? '') === 'Returned' ? 'selected' : '' ?>>Returned</option>
<option value="Returned (Overdue)" <?= ($row['status'] ?? '') === 'Returned (Overdue)' ? 'selected' : '' ?>>Returned (Overdue)</option>
<option value="Lost" <?= ($row['status'] ?? '') === 'Lost' ? 'selected' : '' ?>>Lost</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>