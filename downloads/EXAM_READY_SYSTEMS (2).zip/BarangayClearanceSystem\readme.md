# Barangay Clearance & Certification System

An academic, student-level PHP & MySQL web application implementing a complete 4-module architecture:
1. **Residents Module**: Master Entity 1 management (CRUD).
2. **Clearance Types Module**: Master Entity 2 management (CRUD).
3. **Clearance Issuances Module**: Relational transaction linking with foreign key constraints.
4. **Monitoring Report Module**: Real-time analytical dashboard with dynamic filters and aggregate functions (`COUNT`, `SUM`).

## Database Configuration
- **Database Name**: `barangay_clearance_db`
- **Database Connection**: `database.php`
- **Initial Schema & Seed Data**: `database.sql`
