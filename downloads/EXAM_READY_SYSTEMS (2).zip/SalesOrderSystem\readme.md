﻿# Sales & Order Management System

A simple PHP and MySQL web application for managing products, customers, and orders.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\SalesOrderSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/SalesOrderSystem/
4. The database `sales_order_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Products**: Add, view, edit, and delete products records.
- **Customers**: Add, view, edit, and delete customers records.
- **Orders**: Manage orders transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
