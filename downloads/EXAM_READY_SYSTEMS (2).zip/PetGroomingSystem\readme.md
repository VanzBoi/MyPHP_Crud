﻿# Pet Grooming Management System

A simple PHP and MySQL web application for managing services, pets, and bookings.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\PetGroomingSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/PetGroomingSystem/
4. The database `pet_grooming_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Services**: Add, view, edit, and delete services records.
- **Pets**: Add, view, edit, and delete pets records.
- **Bookings**: Manage bookings transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
