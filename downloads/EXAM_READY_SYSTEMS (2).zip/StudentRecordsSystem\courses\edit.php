<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM courses WHERE courseID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $courseCode = is_string($_POST['courseCode'] ?? null) ? trim($_POST['courseCode']) : '';
$courseTitle = is_string($_POST['courseTitle'] ?? null) ? trim($_POST['courseTitle']) : '';
$units = is_string($_POST['units'] ?? null) ? trim($_POST['units']) : '';
$department = is_string($_POST['department'] ?? null) ? trim($_POST['department']) : '';

    $sql = "UPDATE courses SET `courseCode` = '" . $conn->real_escape_string($courseCode) . "', `courseTitle` = '" . $conn->real_escape_string($courseTitle) . "', `units` = '" . $conn->real_escape_string($units) . "', `department` = '" . $conn->real_escape_string($department) . "' WHERE courseID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course / Subject #<?= $id ?> - Student Academic Records &amp; Grading System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Course / Subject #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Course Code</label>
                <input type="text" name="courseCode" class="form-control" value="<?= htmlspecialchars($row['courseCode'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Course Title</label>
                <input type="text" name="courseTitle" class="form-control" value="<?= htmlspecialchars($row['courseTitle'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Units</label>
                <input type="number"  name="units" class="form-control" value="<?= htmlspecialchars($row['units'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Department</label>
                <select name="department" class="form-select" required>
                    <option value="CCS" <?= ($row['department'] ?? '') === 'CCS' ? 'selected' : '' ?>>CCS</option>
<option value="COE" <?= ($row['department'] ?? '') === 'COE' ? 'selected' : '' ?>>COE</option>
<option value="CBA" <?= ($row['department'] ?? '') === 'CBA' ? 'selected' : '' ?>>CBA</option>
<option value="CAS" <?= ($row['department'] ?? '') === 'CAS' ? 'selected' : '' ?>>CAS</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>