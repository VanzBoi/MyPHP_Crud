<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $serviceName = is_string($_POST['serviceName'] ?? null) ? trim($_POST['serviceName']) : '';
$category = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
$durationMin = is_string($_POST['durationMin'] ?? null) ? trim($_POST['durationMin']) : '';
$serviceFee = is_string($_POST['serviceFee'] ?? null) ? trim($_POST['serviceFee']) : '';

    $sql = "INSERT INTO services (`serviceName`, `category`, `durationMin`, `serviceFee`) VALUES ('" . $conn->real_escape_string($serviceName) . "', '" . $conn->real_escape_string($category) . "', '" . $conn->real_escape_string($durationMin) . "', '" . $conn->real_escape_string($serviceFee) . "')";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to add record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Service - Professional Service Appointment System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Add New Service</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Service Name</label>
                <input type="text" name="serviceName" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Category</label>
                <select name="category" class="form-select" required>
                    <option value="Legal">Legal</option>
<option value="Financial">Financial</option>
<option value="Coaching">Coaching</option>
<option value="Corporate">Corporate</option>
<option value="Consulting">Consulting</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Duration (Mins)</label>
                <input type="number"  name="durationMin" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Fee (₱)</label>
                <input type="number" step="0.01" name="serviceFee" class="form-control" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Service</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>