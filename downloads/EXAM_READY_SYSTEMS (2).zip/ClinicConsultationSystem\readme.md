﻿# Clinic Consultation Management System

A simple PHP and MySQL web application for managing doctors, patients, and consultations.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\ClinicConsultationSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/ClinicConsultationSystem/
4. The database `clinicdb` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Doctors**: Add, view, edit, and delete doctors records.
- **Patients**: Add, view, edit, and delete patients records.
- **Consultations**: Manage consultations transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
