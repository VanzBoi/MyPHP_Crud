<?php
// Global navigation bar
$cur = $_SERVER['REQUEST_URI'];
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= $baseUrl ?>index.php">ICT Congress &amp; Workshop Registration System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= (strpos($cur, '/index.php') !== false && strpos($cur, '/workshops') === false && strpos($cur, '/participants') === false && strpos($cur, '/registrations') === false && strpos($cur, '/monitoring') === false) ? 'active' : '' ?>" href="<?= $baseUrl ?>index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/workshops/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>workshops/index.php">Workshop</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/participants/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>participants/index.php">Participant</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/registrations/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>registrations/index.php">Registration</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= strpos($cur, '/monitoring/') !== false ? 'active' : '' ?>" href="<?= $baseUrl ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>