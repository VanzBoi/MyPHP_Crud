CREATE DATABASE IF NOT EXISTS equipment_borrow_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE equipment_borrow_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS equipment (
  equipmentID INT AUTO_INCREMENT PRIMARY KEY,
  equipmentName VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL,
  serialNumber VARCHAR(50) NOT NULL UNIQUE,
  conditionStatus VARCHAR(50) DEFAULT 'Good'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS borrowers (
  borrowerID INT AUTO_INCREMENT PRIMARY KEY,
  borrowerName VARCHAR(100) NOT NULL,
  idNumber VARCHAR(50) NOT NULL,
  department VARCHAR(50) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS borrow_logs (
  logID INT AUTO_INCREMENT PRIMARY KEY,
  equipmentID INT NOT NULL,
  borrowerID INT NOT NULL,
  borrowDate DATE NOT NULL,
  returnDueDate DATE NOT NULL,
  penaltyFee DECIMAL(10,2) DEFAULT 0.00,
  status VARCHAR(50) DEFAULT 'Borrowed',
  FOREIGN KEY (equipmentID) REFERENCES equipment(equipmentID) ON DELETE CASCADE,
  FOREIGN KEY (borrowerID) REFERENCES borrowers(borrowerID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO equipment (equipmentName, category, serialNumber, conditionStatus) VALUES
('Epson Projector EB-X06', 'Multimedia', 'EPS-PRJ-001', 'Good'),
('Dell Latitude 3420 Laptop', 'IT Hardware', 'DEL-LAP-882', 'Good'),
('Sony Wireless Microphone', 'Audio Gear', 'SNY-MIC-331', 'Good'),
('Yamaha Portable PA Speaker', 'Audio Gear', 'YAM-SPK-990', 'Good');

INSERT INTO borrowers (borrowerName, idNumber, department, contactNumber) VALUES
('Prof. Albert Santos', 'FAC-2018-091', 'CCS', '09171112299'),
('Engr. Ronald Vega', 'FAC-2019-102', 'COE', '09182223388'),
('Maria Leonora Teresa', 'STU-2023-441', 'CBA', '09223334477');

INSERT INTO borrow_logs (equipmentID, borrowerID, borrowDate, returnDueDate, penaltyFee, status) VALUES
(1, 1, '2026-10-24', '2026-10-25', 0.00, 'Returned'),
(2, 2, '2026-10-25', '2026-10-26', 150.00, 'Returned (Overdue)'),
(3, 3, '2026-10-27', '2026-10-28', 0.00, 'Borrowed');

SET FOREIGN_KEY_CHECKS=1;