<?php
require_once __DIR__ . '/../database.php';

$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM services WHERE serviceID = $id LIMIT 1");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$row = $res->fetch_assoc();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $serviceName = is_string($_POST['serviceName'] ?? null) ? trim($_POST['serviceName']) : '';
$category = is_string($_POST['category'] ?? null) ? trim($_POST['category']) : '';
$durationMin = is_string($_POST['durationMin'] ?? null) ? trim($_POST['durationMin']) : '';
$serviceFee = is_string($_POST['serviceFee'] ?? null) ? trim($_POST['serviceFee']) : '';

    $sql = "UPDATE services SET `serviceName` = '" . $conn->real_escape_string($serviceName) . "', `category` = '" . $conn->real_escape_string($category) . "', `durationMin` = '" . $conn->real_escape_string($durationMin) . "', `serviceFee` = '" . $conn->real_escape_string($serviceFee) . "' WHERE serviceID = $id";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to update record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Service #<?= $id ?> - Professional Service Appointment System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Edit Service #<?= $id ?></h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Service Name</label>
                <input type="text" name="serviceName" class="form-control" value="<?= htmlspecialchars($row['serviceName'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Category</label>
                <select name="category" class="form-select" required>
                    <option value="Legal" <?= ($row['category'] ?? '') === 'Legal' ? 'selected' : '' ?>>Legal</option>
<option value="Financial" <?= ($row['category'] ?? '') === 'Financial' ? 'selected' : '' ?>>Financial</option>
<option value="Coaching" <?= ($row['category'] ?? '') === 'Coaching' ? 'selected' : '' ?>>Coaching</option>
<option value="Corporate" <?= ($row['category'] ?? '') === 'Corporate' ? 'selected' : '' ?>>Corporate</option>
<option value="Consulting" <?= ($row['category'] ?? '') === 'Consulting' ? 'selected' : '' ?>>Consulting</option>

                </select>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Duration (Mins)</label>
                <input type="number"  name="durationMin" class="form-control" value="<?= htmlspecialchars($row['durationMin'] ?? '') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Fee (₱)</label>
                <input type="number" step="0.01" name="serviceFee" class="form-control" value="<?= htmlspecialchars($row['serviceFee'] ?? '') ?>" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>