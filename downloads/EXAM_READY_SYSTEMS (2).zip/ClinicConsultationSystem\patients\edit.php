<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    redirect('index.php');
}
$stmt = $mysqli->prepare("SELECT * FROM patients WHERE patID = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
if (!$row) redirect('index.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = is_string($_POST['patFName'] ?? null) ? trim($_POST['patFName']) : '';
    $l = is_string($_POST['patLName'] ?? null) ? trim($_POST['patLName']) : '';
    $b = is_string($_POST['patBDate'] ?? null) ? trim($_POST['patBDate']) : '';
    $t = is_string($_POST['patTelNo'] ?? null) ? trim($_POST['patTelNo']) : '';
    $up = $mysqli->prepare("UPDATE patients SET patFName=?, patLName=?, patBDate=?, patTelNo=? WHERE patID=?");
    $up->bind_param('ssssi', $f, $l, $b, $t, $id);
    $up->execute();
    flash('success','Patient updated.');
    redirect('index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Patient - Clinic Consultation</title>
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
  <h2>Edit Patient</h2>
  <form method="post">
    <div class="mb-2"><label>First Name</label><input class="form-control" name="patFName" value="<?php echo e($row['patFName']); ?>" required></div>
    <div class="mb-2"><label>Last Name</label><input class="form-control" name="patLName" value="<?php echo e($row['patLName']); ?>" required></div>
    <div class="mb-2"><label>Birth Date</label><input type="date" class="form-control" name="patBDate" value="<?php echo e($row['patBDate']); ?>"></div>
    <div class="mb-2"><label>Tel No</label><input class="form-control" name="patTelNo" value="<?php echo e($row['patTelNo']); ?>"></div>
    <button class="btn btn-primary">Update</button>
  </form>
</div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
