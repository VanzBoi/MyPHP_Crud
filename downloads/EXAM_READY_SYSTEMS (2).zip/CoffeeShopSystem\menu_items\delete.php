<?php
require_once '../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    $conn->query("DELETE FROM menu_items WHERE itemID = $id");
}

header("Location: index.php");
exit;
?>
