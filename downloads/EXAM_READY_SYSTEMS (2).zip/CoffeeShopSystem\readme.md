﻿# Coffee Shop Management System

A simple PHP and MySQL web application for managing menu items, customers, and orders.

## Requirements
- XAMPP (Apache and MySQL)
- PHP 8.x
- MariaDB / MySQL

## Setup Instructions
1. Copy or extract this project folder into C:\xampp\htdocs\CoffeeShopSystem\.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open your browser and navigate to:
   http://localhost/CoffeeShopSystem/
4. The database `coffeeshop_db` and initial sample data will automatically load on first visit via database.sql.

## Features
- **Menu Items**: Add, view, edit, and delete menu items records.
- **Customers**: Add, view, edit, and delete customers records.
- **Orders**: Manage orders transaction records with calculations.
- **Monitoring**: Filter transaction records and view summary metrics and totals.
