﻿<?php
require_once __DIR__ . '/database.php';

$c1 = $conn->query("SELECT COUNT(*) AS total FROM services")->fetch_assoc()['total'] ?? 0;
$c2 = $conn->query("SELECT COUNT(*) AS total FROM pets")->fetch_assoc()['total'] ?? 0;
$c3 = $conn->query("SELECT COUNT(*) AS total FROM bookings")->fetch_assoc()['total'] ?? 0;
$sumVal = $conn->query("SELECT IFNULL(SUM(totalPrice), 0) AS total FROM bookings")->fetch_assoc()['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Grooming Management System - Dashboard</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/navbar.php'; ?>

    <div class="container my-4">
        <div class="p-4 mb-4 rounded bg-white border" class="p-4 mb-4 rounded bg-light border text-dark">
            <div class="col-md-9 px-0">
                <h1 class="display-5 fw-bold">Pet Grooming Management System</h1>
                <p class="lead my-3">Professional pet styling, wellness treatments, customer bookings, and revenue tracking.</p>
                <div class="d-flex gap-2 flex-wrap">
                    <a href="<?= $baseUrl ?>bookings/add.php" class="btn btn-warning fw-semibold">+ New Booking</a>
                    <a href="<?= $baseUrl ?>monitoring/index.php" class="btn btn-light fw-semibold">View Monitoring Report</a>
                </div>
            </div>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Service</div>
                    <div class="fs-3 fw-bold text-dark"><?= $c1 ?></div>
                    <a href="<?= $baseUrl ?>services/index.php" class="small text-decoration-none mt-2">Manage Service &rarr;</a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Pet</div>
                    <div class="fs-3 fw-bold text-dark"><?= $c2 ?></div>
                    <a href="<?= $baseUrl ?>pets/index.php" class="small text-decoration-none mt-2">Manage Pet &rarr;</a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Total Booking</div>
                    <div class="fs-3 fw-bold text-dark"><?= $c3 ?></div>
                    <a href="<?= $baseUrl ?>bookings/index.php" class="small text-decoration-none mt-2">View Booking &rarr;</a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Total Volume / Value</div>
                    <div class="fs-3 fw-bold text-success">₱<?= number_format($sumVal, 2) ?></div>
                    <a href="<?= $baseUrl ?>monitoring/index.php" class="small text-decoration-none mt-2">Analytics &rarr;</a>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Quick Links</span>
                <span class="badge bg-primary">System Menu</span>
            </div>
            <div class="card-body">
                <div class="row g-3 text-center">
                    <div class="col-md-3">
                        <div class="p-3 border rounded bg-white">
                            <h6 class="fw-bold">Service CRUD</h6>
                            <p class="small text-muted mb-2">Primary Records</p>
                            <a href="<?= $baseUrl ?>services/index.php" class="btn btn-outline-primary btn-sm w-100">Open</a>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="p-3 border rounded bg-white">
                            <h6 class="fw-bold">Pet CRUD</h6>
                            <p class="small text-muted mb-2">Secondary Records</p>
                            <a href="<?= $baseUrl ?>pets/index.php" class="btn btn-outline-primary btn-sm w-100">Open</a>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="p-3 border rounded bg-white">
                            <h6 class="fw-bold">Bookings</h6>
                            <p class="small text-muted mb-2">Transaction Records</p>
                            <a href="<?= $baseUrl ?>bookings/index.php" class="btn btn-outline-primary btn-sm w-100">Open</a>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="p-3 border rounded bg-white">
                            <h6 class="fw-bold">Monitoring Report</h6>
                            <p class="small text-muted mb-2">Summary Report</p>
                            <a href="<?= $baseUrl ?>monitoring/index.php" class="btn btn-outline-primary btn-sm w-100">Open</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="text-center">
        <div class="container">
            <p class="mb-0">&copy; <?= date('Y') ?> Pet Grooming Management System</p>
        </div>
    </footer>
    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>