﻿<?php
require_once __DIR__ . '/../database.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$where = "1=1";
if ($search !== '') {
    $s = $conn->real_escape_string($search);
    $where .= " AND (e1.equipmentName LIKE '%$s%' OR e2.borrowerName LIKE '%$s%')";
}

$sql = "SELECT t.*, e1.equipmentName AS e1_title, e2.borrowerName AS e2_title 
        FROM borrow_logs t
        JOIN equipment e1 ON t.equipmentID = e1.equipmentID
        JOIN borrowers e2 ON t.borrowerID = e2.borrowerID
        WHERE $where
        ORDER BY t.logID DESC";
$res = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrow Log List - Equipment Borrowing &amp; Tracking System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="fw-bold mb-0">Borrow Log Records</h3>
                <small class="text-muted">Transaction Management</small>
            </div>
            <a href="add.php" class="btn btn-warning fw-semibold btn-sm">+ New Borrow Log</a>
        </div>

        <div class="card mb-4">
            <div class="card-body p-3">
                <form method="GET" class="row g-2">
                    <div class="col-md-10">
                        <input type="text" name="search" class="form-control form-control-sm" placeholder="Search by Equipment or Borrower..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-2 d-flex gap-2">
                        <button type="submit" class="btn btn-dark btn-sm w-100">Search</button>
                        <?php if ($search !== ''): ?>
                            <a href="index.php" class="btn btn-outline-secondary btn-sm">Reset</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="table table-striped table-bordered align-middle mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Equipment</th>
<th>Borrower</th>
<th>Borrow Date</th>
<th>Due Date</th>
<th>Penalty Fee (₱)</th>
<th>Status</th>

                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($res && $res->num_rows > 0): ?>
                            <?php while ($r = $res->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['logID'] ?></td>
                                    <td><?= htmlspecialchars($r['e1_title'] ?? '') ?></td>
<td><?= htmlspecialchars($r['e2_title'] ?? '') ?></td>
<td><?= htmlspecialchars($r['borrowDate']) ?></td>
<td><?= htmlspecialchars($r['returnDueDate']) ?></td>
<td>₱<?= number_format($r['penaltyFee'], 2) ?></td>
<td><?= htmlspecialchars($r['status']) ?></td>

                                    <td class="text-end">
                                        <a href="edit.php?id=<?= $r['logID'] ?>" class="btn btn-outline-primary btn-sm py-0 px-2">Edit</a>
                                        <a href="delete.php?id=<?= $r['logID'] ?>" class="btn btn-outline-danger btn-sm py-0 px-2" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="12" class="text-center py-4 text-muted">No transactions recorded yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer class="text-center">
        <div class="container">
            <p class="mb-0">&copy; <?= date('Y') ?> Equipment Borrowing &amp; Tracking System</p>
        </div>
    </footer>
    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>