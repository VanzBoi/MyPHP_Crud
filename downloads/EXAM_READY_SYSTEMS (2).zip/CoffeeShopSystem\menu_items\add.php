<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = is_string($_POST['itemName'] ?? null) ? trim($_POST['itemName']) : '';
    $cat = is_string($_POST['itemCategory'] ?? null) ? trim($_POST['itemCategory']) : '';
    $price = floatval($_POST['unitPrice'] ?? 0);
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($name && $price > 0) {
        $stmt = $conn->prepare("INSERT INTO menu_items (itemName, itemCategory, unitPrice, status) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssds", $name, $cat, $price, $status);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Menu Item</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Add New Menu Item</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Item Name</label>
                    <input type="text" name="itemName" class="form-control" required placeholder="e.g. Vanilla Cold Brew">
                </div>
                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <select name="itemCategory" class="form-select" required>
                        <option value="Hot Coffee">Hot Coffee</option>
                        <option value="Iced Drinks">Iced Drinks</option>
                        <option value="Pastries">Pastries</option>
                        <option value="Sandwiches & Snacks">Sandwiches & Snacks</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Retail Unit Price (₱)</label>
                    <input type="number" step="0.01" name="unitPrice" class="form-control" required placeholder="140.00">
                </div>
                <div class="mb-3">
                    <label class="form-label">Availability Status</label>
                    <select name="status" class="form-select">
                        <option value="Available">Available</option>
                        <option value="Out of Stock">Out of Stock</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100">Save Item</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>