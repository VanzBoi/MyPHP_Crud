<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT itemID, itemName FROM menu_items ORDER BY itemName ASC");
$e2List = $conn->query("SELECT customerID, customerName FROM customers ORDER BY customerName ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemID = (int)($_POST['itemID'] ?? 0);
    $customerID = (int)($_POST['customerID'] ?? 0);
    $orderDate = is_string($_POST['orderDate'] ?? null) ? trim($_POST['orderDate']) : '';
    $quantity = is_string($_POST['quantity'] ?? null) ? trim($_POST['quantity']) : '';
    $totalAmount = is_string($_POST['totalAmount'] ?? null) ? trim($_POST['totalAmount']) : '';
    $paymentStatus = is_string($_POST['paymentStatus'] ?? null) ? trim($_POST['paymentStatus']) : '';

    if ($itemID <= 0 || $customerID <= 0) {
        $error = "Please select valid options.";
    } else {
        $sql = "INSERT INTO orders (`itemID`, `customerID`, `orderDate`, `quantity`, `totalAmount`, `paymentStatus`) VALUES ('" . $conn->real_escape_string($itemID) . "', '" . $conn->real_escape_string($customerID) . "', '" . $conn->real_escape_string($orderDate) . "', '" . $conn->real_escape_string($quantity) . "', '" . $conn->real_escape_string($totalAmount) . "', '" . $conn->real_escape_string($paymentStatus) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Order - Restaurant Ordering &amp; POS System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 800px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Record New Order</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Menu Item <span class="text-danger">*</span></label>
            <select name="itemID" class="form-select" required>
                <option value="">-- Select Menu Item --</option>
                <?php while ($e1Row = $e1List->fetch_assoc()): ?>
                    <option value="<?= $e1Row['itemID'] ?>"><?= htmlspecialchars($e1Row['itemName']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label fw-semibold">Customer / Table <span class="text-danger">*</span></label>
            <select name="customerID" class="form-select" required>
                <option value="">-- Select Customer / Table --</option>
                <?php while ($e2Row = $e2List->fetch_assoc()): ?>
                    <option value="<?= $e2Row['customerID'] ?>"><?= htmlspecialchars($e2Row['customerName']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Date</label>
                <input type="date" name="orderDate" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Quantity</label>
                <input type="number"  name="quantity" class="form-control" value="1" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Total Amount (₱)</label>
                <input type="number" step="0.01" name="totalAmount" class="form-control" value="0" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Payment Status</label>
                <select name="paymentStatus" class="form-select" required>
                    <option value="Paid">Paid</option>
<option value="Unpaid">Unpaid</option>
<option value="Refunded">Refunded</option>

                </select>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Submit Order</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>