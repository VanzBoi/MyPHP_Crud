<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM veterinarians WHERE vetID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$vet = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = is_string($_POST['vetFName'] ?? null) ? trim($_POST['vetFName']) : '';
    $lname = is_string($_POST['vetLName'] ?? null) ? trim($_POST['vetLName']) : '';
    $spec = is_string($_POST['specialization'] ?? null) ? trim($_POST['specialization']) : '';
    $contact = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    $stmt = $conn->prepare("UPDATE veterinarians SET vetFName=?, vetLName=?, specialization=?, contactNumber=? WHERE vetID=?");
    $stmt->bind_param("ssssi", $fname, $lname, $spec, $contact, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Veterinarian</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Edit Veterinarian</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">First Name</label>
                        <input type="text" name="vetFName" class="form-control" required value="<?php echo htmlspecialchars($vet['vetFName']); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="vetLName" class="form-control" required value="<?php echo htmlspecialchars($vet['vetLName']); ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Specialization</label>
                    <select name="specialization" class="form-select" required>
                        <?php foreach(['General Veterinary Medicine', 'Surgery & Trauma', 'Canine & Feline Medicine', 'Dermatology & Allergy', 'Dentistry'] as $opt): ?>
                        <option value="<?php echo $opt; ?>" <?php echo $vet['specialization'] === $opt ? 'selected' : ''; ?>><?php echo $opt; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="contactNumber" class="form-control" required value="<?php echo htmlspecialchars($vet['contactNumber']); ?>">
                </div>
                <button type="submit" class="btn btn-warning w-100">Update Doctor Record</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>