<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = is_string($_POST['custFName'] ?? null) ? trim($_POST['custFName']) : '';
    $lname = is_string($_POST['custLName'] ?? null) ? trim($_POST['custLName']) : '';
    $type = is_string($_POST['customerType'] ?? null) ? trim($_POST['customerType']) : '';
    $contact = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    if ($fname && $lname) {
        $stmt = $conn->prepare("INSERT INTO customers (custFName, custLName, customerType, contactNumber) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fname, $lname, $type, $contact);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Moviegoer</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4 mb-3">
            <h4>Add New Moviegoer</h4>
            <?php echo $msg; ?>
            <form method="POST">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">First Name</label>
                        <input type="text" name="custFName" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="custLName" class="form-control" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Customer Classification</label>
                    <select name="customerType" class="form-select">
                        <option value="Regular">Regular (Standard Price)</option>
                        <option value="Student">Student (20% Discount)</option>
                        <option value="Senior">Senior / PWD (20% Discount)</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="contactNumber" class="form-control" placeholder="0917-000-0000">
                </div>
                <button type="submit" class="btn btn-primary w-100">Save Moviegoer</button>
                <a href="index.php" class="btn btn-link w-100 text-muted mt-2">Back to List</a>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>