CREATE DATABASE IF NOT EXISTS repair_service_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE repair_service_db;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS technicians (
  techID INT AUTO_INCREMENT PRIMARY KEY,
  techName VARCHAR(100) NOT NULL,
  specialty VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL,
  laborRate DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS appliances (
  applianceID INT AUTO_INCREMENT PRIMARY KEY,
  customerName VARCHAR(100) NOT NULL,
  deviceType VARCHAR(50) NOT NULL,
  brandModel VARCHAR(100) NOT NULL,
  contactNumber VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS repairs (
  repairID INT AUTO_INCREMENT PRIMARY KEY,
  techID INT NOT NULL,
  applianceID INT NOT NULL,
  repairDate DATE NOT NULL,
  issueReported VARCHAR(150) NOT NULL,
  totalCost DECIMAL(10,2) NOT NULL,
  status VARCHAR(50) DEFAULT 'Diagnostic',
  FOREIGN KEY (techID) REFERENCES technicians(techID) ON DELETE CASCADE,
  FOREIGN KEY (applianceID) REFERENCES appliances(applianceID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO technicians (techName, specialty, contactNumber, laborRate) VALUES
('Joel Alcantara', 'Laptop & PC Repair', '09171122334', 800.00),
('Nestor Dizon', 'Smartphone & Tablet', '09182233445', 600.00),
('Vicente Morales', 'TV & Audio System', '09223344556', 950.00);

INSERT INTO appliances (customerName, deviceType, brandModel, contactNumber) VALUES
('Grace Lim', 'Laptop', 'Asus ZenBook 14', '09179988776'),
('Bryan Santos', 'Smartphone', 'Samsung Galaxy S22', '09188877665'),
('Clara Delgado', 'Television', 'LG OLED 55 Inch', '09227766554');

INSERT INTO repairs (techID, applianceID, repairDate, issueReported, totalCost, status) VALUES
(1, 1, '2026-10-25', 'No Display / Broken Screen', 3500.00, 'Repaired'),
(2, 2, '2026-10-26', 'Battery Swelling Replacement', 1800.00, 'Repaired'),
(3, 3, '2026-10-27', 'Power Board Blown Capacitor', 2200.00, 'Diagnostic');

SET FOREIGN_KEY_CHECKS=1;