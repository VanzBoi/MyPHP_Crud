<?php
require_once '../database.php';
$depts = $conn->query("SELECT * FROM departments ORDER BY deptCode ASC");
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sID = is_string($_POST['studentID'] ?? null) ? trim($_POST['studentID']) : '';
    $name = is_string($_POST['fullName'] ?? null) ? trim($_POST['fullName']) : '';
    $deptID = intval($_POST['deptID'] ?? 0);
    $year = is_string($_POST['yearLevel'] ?? null) ? trim($_POST['yearLevel']) : '';
    $gender = is_string($_POST['gender'] ?? null) ? trim($_POST['gender']) : '';
    $contact = is_string($_POST['contactNo'] ?? null) ? trim($_POST['contactNo']) : '';

    if ($sID === '' || $name === '' || $deptID <= 0) {
        $err = 'Please complete all required fields.';
    } else {
        $stmt = $conn->prepare("INSERT INTO athletes (studentID, fullName, deptID, yearLevel, gender, contactNo) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisss", $sID, $name, $deptID, $year, $gender, $contact);
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $err = 'Student ID already registered or database error: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Athlete</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container" style="max-width: 600px;">
        <div class="card p-4">
            <h4 class="mb-3">Register New Student Athlete</h4>
            <?php if ($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">University Student ID</label>
                    <input type="text" name="studentID" class="form-control" required placeholder="e.g. 21-12345">
                </div>
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="fullName" class="form-control" required placeholder="e.g. John Cedrick Libradilla">
                </div>
                <div class="mb-3">
                    <label class="form-label">College Department</label>
                    <select name="deptID" class="form-select" required>
                        <option value="">-- Choose College --</option>
                        <?php while($d = $depts->fetch_assoc()): ?>
                            <option value="<?php echo $d['deptID']; ?>"><?php echo htmlspecialchars($d['deptCode'] . ' - ' . $d['deptName']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Year Level</label>
                        <select name="yearLevel" class="form-select" required>
                            <option value="1st Year">1st Year</option>
                            <option value="2nd Year">2nd Year</option>
                            <option value="3rd Year">3rd Year</option>
                            <option value="4th Year">4th Year</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Gender</label>
                        <select name="gender" class="form-select" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="contactNo" class="form-control" placeholder="e.g. 0917-123-4567" required>
                </div>
                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Save Athlete</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>