<?php
require_once '../database.php';
require_once '../helpers.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$sql = 'SELECT * FROM scholarships';
$params = [];
if ($search !== '') {
    $sql .= ' WHERE scholName LIKE ? OR description LIKE ?';
    $params = ['%' . $search . '%', '%' . $search . '%'];
}
$stmt = $mysqli->prepare($sql);
if ($params) {
    $stmt->bind_param('ss', $params[0], $params[1]);
}
$stmt->execute();
$result = $stmt->get_result();
$scholarships = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Scholarships</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
<div class="container mt-4">
    <?php include '../navbar.php'; ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Scholarships</h2>
        <a href="add.php" class="btn btn-success">Add Scholarship</a>
    </div>
    <?php flash(); ?>
    <form class="row g-2 mb-3" method="get" action="index.php">
        <div class="col-md-10">
            <input type="text" name="search" class="form-control" placeholder="Search scholarships..." value="<?= escape($search) ?>">
        </div>
        <div class="col-md-2">
            <button class="btn btn-secondary w-100" type="submit">Search</button>
        </div>
    </form>
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Discount Rate</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($scholarships as $index => $scholarship): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= escape($scholarship['scholID']) ?></td>
                        <td><?= escape($scholarship['scholName']) ?></td>
                        <td><?= number_format($scholarship['discountRate'] * 100, 0) ?>%</td>
                        <td><?= escape($scholarship['description']) ?></td>
                        <td>
                            <a href="edit.php?id=<?= escape($scholarship['scholID']) ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="delete.php?id=<?= escape($scholarship['scholID']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this scholarship?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($scholarships)): ?>
                    <tr><td colspan="6" class="text-center">No scholarships found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
  <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>
