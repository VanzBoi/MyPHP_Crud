﻿<?php
require_once 'database.php';

$totalVets = $conn->query("SELECT COUNT(*) FROM veterinarians")->fetch_row()[0];
$totalPets = $conn->query("SELECT COUNT(*) FROM pets")->fetch_row()[0];
$totalTreatments = $conn->query("SELECT COUNT(*) FROM treatments")->fetch_row()[0];
$totalRevenue = $conn->query("SELECT IFNULL(SUM(treatmentFee), 0) FROM treatments")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Veterinary Clinic System - Dashboard</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container">
        <div class="p-4 mb-4 bg-white rounded-3 border">
            <h1 class="display-6 fw-bold">Veterinary Clinic Portal</h1>
            <p class="lead text-muted mb-0">Animal Health & Treatment Records</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Registered Doctors</span>
                    <h3 class="mb-0 text-primary"><?php echo $totalVets; ?> Vets</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Registered Pets</span>
                    <h3 class="mb-0 text-success"><?php echo $totalPets; ?> Patients</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Total Treatments</span>
                    <h3 class="mb-0 text-warning"><?php echo $totalTreatments; ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 mb-3">
                    <span class="text-muted small">Total Consultation Fees</span>
                    <h3 class="mb-0 text-success">₱<?php echo number_format($totalRevenue, 2); ?></h3>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Veterinarians</h5>
                    <p class="text-muted small">Manage licensed doctors, specializations, and contact numbers.</p>
                    <a href="<?php echo $baseUrl; ?>veterinarians/index.php" class="btn btn-outline-primary mt-auto">Open Veterinarians &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Pets & Patients</h5>
                    <p class="text-muted small">Maintain pet profiles, species, breeds, and owner contact details.</p>
                    <a href="<?php echo $baseUrl; ?>pets/index.php" class="btn btn-outline-success mt-auto">Open Pets Registry &rarr;</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h5>Monitoring & Statistics</h5>
                    <p class="text-muted small">View doctor consultation history and earnings summary report.</p>
                    <a href="<?php echo $baseUrl; ?>monitoring/index.php" class="btn btn-outline-dark mt-auto">Open Monitoring &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>