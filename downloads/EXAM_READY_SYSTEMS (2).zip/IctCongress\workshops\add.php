<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $workshopTitle = is_string($_POST['workshopTitle'] ?? null) ? trim($_POST['workshopTitle']) : '';
$speakerName = is_string($_POST['speakerName'] ?? null) ? trim($_POST['speakerName']) : '';
$venueRoom = is_string($_POST['venueRoom'] ?? null) ? trim($_POST['venueRoom']) : '';
$registrationFee = is_string($_POST['registrationFee'] ?? null) ? trim($_POST['registrationFee']) : '';

    $sql = "INSERT INTO workshops (`workshopTitle`, `speakerName`, `venueRoom`, `registrationFee`) VALUES ('" . $conn->real_escape_string($workshopTitle) . "', '" . $conn->real_escape_string($speakerName) . "', '" . $conn->real_escape_string($venueRoom) . "', '" . $conn->real_escape_string($registrationFee) . "')";
    if ($conn->query($sql)) {
        header("Location: index.php");
        exit;
    } else {
        $error = "Failed to add record: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Workshop - ICT Congress &amp; Workshop Registration System</title>
    <link rel="stylesheet" href="<?= $baseUrl ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>style.css">
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 750px;">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">Add New Workshop</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">&larr; Back to List</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <form method="POST">
                    <div class="row">
                                    <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Workshop Title</label>
                <input type="text" name="workshopTitle" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Resource Speaker</label>
                <input type="text" name="speakerName" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Room / Venue</label>
                <input type="text" name="venueRoom" class="form-control" required>
            </div>            <div class="col-md-6 mb-3">
                <label class="form-label fw-semibold">Fee (₱)</label>
                <input type="number" step="0.01" name="registrationFee" class="form-control" required>
            </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex justify-content-end gap-2">
                        <a href="index.php" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">Save Workshop</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?= $baseUrl ?>bootstrap.bundle.min.js"></script>
</body>
</html>