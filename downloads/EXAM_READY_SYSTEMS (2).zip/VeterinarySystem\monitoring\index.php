﻿<?php
require_once '../database.php';

$vetsList = $conn->query("SELECT * FROM veterinarians ORDER BY vetLName ASC");
$filterVetID = intval($_GET['vetID'] ?? 0);

if ($filterVetID > 0) {
    $stmt = $conn->prepare("SELECT t.*, v.vetFName, v.vetLName, v.specialization, p.petName, p.speciesBreed, p.ownerName 
                            FROM treatments t
                            JOIN veterinarians v ON t.vetID = v.vetID
                            JOIN pets p ON t.petID = p.petID
                            WHERE t.vetID = ?
                            ORDER BY t.treatmentDate DESC");
    $stmt->bind_param("i", $filterVetID);
    $stmt->execute();
    $records = $stmt->get_result();

    $aggStmt = $conn->prepare("SELECT COUNT(*) AS total_treatments, IFNULL(SUM(treatmentFee), 0) AS total_revenue, COUNT(DISTINCT petID) AS unique_pets 
                               FROM treatments 
                               WHERE vetID = ?");
    $aggStmt->bind_param("i", $filterVetID);
    $aggStmt->execute();
    $agg = $aggStmt->get_result()->fetch_assoc();

    $vetInfo = $conn->query("SELECT * FROM veterinarians WHERE vetID = $filterVetID")->fetch_assoc();
    $filterLabel = "Dr. " . $vetInfo['vetFName'] . " " . $vetInfo['vetLName'] . " (" . $vetInfo['specialization'] . ")";
} else {
    $records = $conn->query("SELECT t.*, v.vetFName, v.vetLName, v.specialization, p.petName, p.speciesBreed, p.ownerName 
                             FROM treatments t
                             JOIN veterinarians v ON t.vetID = v.vetID
                             JOIN pets p ON t.petID = p.petID
                             ORDER BY t.treatmentDate DESC");
    $agg = $conn->query("SELECT COUNT(*) AS total_treatments, IFNULL(SUM(treatmentFee), 0) AS total_revenue, COUNT(DISTINCT petID) AS unique_pets FROM treatments")->fetch_assoc();
    $filterLabel = "All Veterinarians";
}

$count = $agg['total_treatments'] ?? 0;
$sumFee = $agg['total_revenue'] ?? 0.00;
$uniquePatients = $agg['unique_pets'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Veterinary Monitoring Report</title>
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $baseUrl; ?>style.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h3 class="mb-0">Veterinary Monitoring Report</h3>
            </div>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">Reset Filter</a>
        </div>

        <!-- Filter Card -->
        <div class="card p-3 mb-4">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-auto">
                    <label class="form-label mb-0 fw-semibold">Filter by Veterinarian:</label>
                </div>
                <div class="col-md-5">
                    <select name="vetID" class="form-select" onchange="this.form.submit()">
                        <option value="">-- All Veterinarians --</option>
                        <?php while($v = $vetsList->fetch_assoc()): ?>
                        <option value="<?php echo $v['vetID']; ?>" <?php echo $filterVetID === intval($v['vetID']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars('Dr. ' . $v['vetFName'] . ' ' . $v['vetLName'] . ' - ' . $v['specialization']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
            </form>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="card p-3 mb-3">
                    <span class="text-muted small fw-semibold">Total Treatments</span>
                    <h2 class="text-primary mb-0"><?php echo $count; ?> <small class="text-muted fs-6">Sessions</small></h2>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 mb-3">
                    <span class="text-muted small fw-semibold">Total Consultation Revenue</span>
                    <h2 class="text-success mb-0">₱<?php echo number_format($sumFee, 2); ?></h2>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 mb-3">
                    <span class="text-muted small fw-semibold">Unique Pet Patients</span>
                    <h2 class="text-warning mb-0"><?php echo $uniquePatients; ?> <small class="text-muted fs-6">Unique Pets</small></h2>
                </div>
            </div>
        </div>

        <!-- Table -->
        <div class="card mb-3">
            <div class="card-header fw-bold bg-white py-3">
                <h5 class="mb-0">Consultations Filtered by: <span class="badge bg-primary"><?php echo htmlspecialchars($filterLabel); ?></span></h5>
            </div>
            <table class="table table-striped table-bordered mb-0">
                <thead>
                    <tr>
                        <th>Pet Patient</th>
                        <th>Species & Breed</th>
                        <th>Owner Name</th>
                        <th>Attending Vet</th>
                        <th>Date</th>
                        <th>Diagnosis</th>
                        <th>Treatment Fee</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($records && $records->num_rows > 0): ?>
                        <?php while($row = $records->fetch_assoc()): ?>
                        <tr>
                            <td><strong> <?php echo htmlspecialchars($row['petName']); ?></strong></td>
                            <td><?php echo htmlspecialchars($row['speciesBreed']); ?></td>
                            <td><?php echo htmlspecialchars($row['ownerName']); ?></td>
                            <td>Dr. <?php echo htmlspecialchars($row['vetFName'] . ' ' . $row['vetLName']); ?></td>
                            <td><?php echo $row['treatmentDate']; ?></td>
                            <td><?php echo htmlspecialchars($row['diagnosis']); ?></td>
                            <td><strong class="text-success">₱<?php echo number_format($row['treatmentFee'], 2); ?></strong></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">No treatment records found for this doctor.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo $baseUrl; ?>bootstrap.bundle.min.js"></script>
</body>
</html>